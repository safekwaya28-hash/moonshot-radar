#!/usr/bin/env python3
"""
Tests de token_forensics.py con un RPC FALSO que sirve transacciones jsonParsed con verdad conocida.
  python test_forensics.py
"""
import os
import random
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import token_forensics as tf  # noqa: E402

MINT = "LATEmint1111111111111111111111111111111111"
CREATOR = "CREATOR11111111111111111111111111111111111"
BC = "BondingCurvePDA1111111111111111111111111111"
POOL = "PumpSwapPoolPDA111111111111111111111111111"
DEC = 6
FAILS = []


def check(name, cond, got=None):
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + ("" if cond else f"   (obtenido: {got})"))
    if not cond:
        FAILS.append(name)


class Chain:
    """Simula la cadena: balances de token por owner, construye txs jsonParsed."""
    def __init__(self, seed=3):
        self.rng = random.Random(seed)
        self.tok = {}            # owner -> tokens (float)
        self.txs = []            # (sig, tx)
        self.slot = 300_000_000
        self.t = 1_758_600_000
        self.wallet_hist = {}    # wallet -> [(sig, blockTime, keys)]
        self.truth = {"buys": 0, "sells": 0, "sol": {}, "snipers": 0}

    def _tb(self, idx, owner, amount, mint=MINT, dec=DEC):
        return {"accountIndex": idx, "mint": mint, "owner": owner,
                "uiTokenAmount": {"amount": str(int(round(amount * 10 ** dec))), "decimals": dec,
                                  "uiAmount": amount}}

    def tx(self, signer, deltas: dict, sol_delta_lamports: int, logs=(), err=False, fee=5000,
           wsol_pre=None, wsol_post=None, v0=False, dslot=1, dt=2, extra_keys=()):
        self.slot += dslot
        self.t += dt
        owners = [signer] + [o for o in deltas if o != signer]
        keys = owners + list(extra_keys) + ["TokenProgram", "PumpProgram"]
        pre_t, post_t = [], []
        for i, o in enumerate(owners):
            if o in deltas:
                before = self.tok.get(o)
                after = (before or 0.0) + deltas[o]
                if before is not None:
                    pre_t.append(self._tb(i + 10, o, before))
                if after > 1e-12:
                    post_t.append(self._tb(i + 10, o, after))
                if not err:
                    if after > 1e-12:
                        self.tok[o] = after
                    else:
                        self.tok.pop(o, None)
        if wsol_pre is not None:
            pre_t.append(self._tb(50, signer, wsol_pre / 1e9, mint=tf.WSOL, dec=9))
            post_t.append(self._tb(50, signer, wsol_post / 1e9, mint=tf.WSOL, dec=9))
        bal0 = 10 * 10 ** 9
        pre_b = [bal0] + [1] * (len(keys) - 1)
        post_b = [bal0 + sol_delta_lamports - fee] + [1] * (len(keys) - 1)
        sig = f"sig{len(self.txs):06d}"
        if v0:
            msg_keys = keys[:1]
            loaded = {"writable": keys[1:], "readonly": []}
        else:
            msg_keys = [{"pubkey": k, "signer": k == signer, "writable": True, "source": "transaction"} for k in keys]
            loaded = None
        meta = {"err": {"InstructionError": [0, "Custom"]} if err else None, "fee": fee,
                "preBalances": pre_b, "postBalances": post_b, "preTokenBalances": pre_t,
                "postTokenBalances": post_t, "logMessages": list(logs)}
        if loaded:
            meta["loadedAddresses"] = loaded
        tx = {"slot": self.slot, "blockTime": self.t, "meta": meta,
              "transaction": {"signatures": [sig], "message": {"accountKeys": msg_keys}}}
        self.txs.append((sig, tx))
        self.wallet_hist.setdefault(signer, []).append((sig, self.t, keys))
        return sig

    def buy(self, w, tokens, sol, first_account=None, **kw):
        new_acct = self.tok.get(w) is None if first_account is None else first_account
        rent = tf.TOKEN_ACCOUNT_RENT if new_acct else 0
        curve = POOL if POOL in self.tok else BC
        s = self.tx(w, {w: tokens, curve: -tokens}, -int(sol * 1e9) - rent, logs=["Program log: Instruction: Buy"], **kw)
        if not kw.get("err"):
            self.truth["buys"] += 1
            self.truth["sol"][s] = sol
        return s

    def sell(self, w, tokens, sol, close=False, **kw):
        rent = tf.TOKEN_ACCOUNT_RENT if close else 0
        curve = POOL if POOL in self.tok else BC
        s = self.tx(w, {w: -tokens, curve: tokens}, int(sol * 1e9) + rent, logs=["Program log: Instruction: Sell"], **kw)
        self.truth["sells"] += 1
        self.truth["sol"][s] = sol
        return s


class FakeRPC:
    def __init__(self, chain: Chain):
        self.c = chain
        self.by_sig = dict(chain.txs)
        self.calls = 0

    def call(self, method, params):
        self.calls += 1
        if method == "getSignaturesForAddress":
            addr, opt = params
            if addr == MINT:
                lst = [(s, tx["blockTime"], tx["slot"], tx["meta"]["err"]) for s, tx in self.c.txs]
            else:
                lst = [(s, bt, None, None) for s, bt, _ in self.c.wallet_hist.get(addr, [])]
            lst = list(reversed(lst))  # más reciente primero, como el RPC real
            if opt.get("before"):
                i = [x[0] for x in lst].index(opt["before"])
                lst = lst[i + 1:]
            return [{"signature": s, "blockTime": bt, "slot": sl, "err": e} for s, bt, sl, e in lst[:opt["limit"]]]
        if method == "getTransaction":
            sig = params[0]
            if sig in self.by_sig:
                return self.by_sig[sig]
            for w, hist in self.c.wallet_hist.items():
                for s, bt, keys in hist:
                    if s == sig:
                        return {"slot": 1, "blockTime": bt, "meta": {"err": None},
                                "transaction": {"message": {"accountKeys": keys}}}
            return None
        raise ValueError(method)


def scenario(creator_buys=False, linked_funding=False):
    c = Chain()
    # historial previo de wallets: algunas antiguas, algunas frescas; una financiada por el creador
    c.t -= 400 * 86400
    for i in range(40):
        c.tx(f"OLDW{i:02d}" + "o" * 36, {}, 0, dt=3600)
    c.t += 400 * 86400
    if linked_funding:
        c.tx(CREATOR, {}, -int(0.5e9), extra_keys=["LINKED" + "l" * 37])
        c.wallet_hist.setdefault("LINKED" + "l" * 37, []).append(
            ("sig_fund", c.t, [CREATOR, "LINKED" + "l" * 37]))
    base = len(c.txs)
    # creación: 1.000M al bonding curve
    c.tx(CREATOR, {BC: 1_000_000_000.0}, -int(0.02e9), logs=["Program log: Instruction: Create"], dslot=5, dt=10)
    create_slot = c.slot
    if creator_buys:
        c.slot -= 1; c.t -= 1
        c.buy(CREATOR, 30_000_000, 1.0, dslot=1, dt=1)
    # snipers: mismo slot de creación y +1
    c.slot -= 1
    c.buy("SNIPER1" + "s" * 36, 20_000_000, 0.8, dslot=1, dt=0)          # slot+0
    c.slot -= 1
    c.buy("SNIPER2" + "s" * 36, 15_000_000, 0.6, dslot=1, dt=0)          # slot+0
    c.buy("SNIPER3" + "s" * 36, 10_000_000, 0.45, dslot=1, dt=1)         # slot+1
    c.truth["snipers"] = 3
    # fallida (no cuenta)
    c.buy("FAILW" + "f" * 38, 5_000_000, 0.2, err=True)
    # compra con wSOL: el SOL sale de la cuenta wSOL, no de lamports
    c.tx("WSOLBUYER" + "w" * 34, {"WSOLBUYER" + "w" * 34: 4_000_000, BC: -4_000_000}, -tf.TOKEN_ACCOUNT_RENT,
         logs=["Program log: Instruction: Buy"], wsol_pre=int(1e9), wsol_post=int(1e9 - 0.15e9))
    c.truth["buys"] += 1
    c.truth["sol"][c.txs[-1][0]] = 0.15
    # flujo normal: 1.150 compradores/vendedores mezclando wallets antiguas y nuevas, v0 a veces
    wallets = [f"OLDW{i:02d}" + "o" * 36 for i in range(40)] + [f"NEWW{i:04d}" + "n" * 34 for i in range(700)]
    rng = random.Random(9)
    holding = {}
    for k in range(1150):
        w = rng.choice(wallets)
        if w in holding and rng.random() < 0.3:
            amt = holding[w] * rng.choice([0.5, 1.0])
            close = abs(amt - holding[w]) < 1e-9
            c.sell(w, amt, round(amt * 4e-8, 9), close=close, v0=(k % 7 == 0), dt=rng.randint(1, 20))
            holding[w] -= amt
            if holding[w] <= 1e-9:
                holding.pop(w)
        else:
            amt = rng.uniform(100_000, 2_000_000)
            c.buy(w, amt, round(amt * 4e-8, 9), v0=(k % 5 == 0), dt=rng.randint(1, 20))
            holding[w] = holding.get(w, 0) + amt
    # transferencia entre dos wallets (no es trade)
    src = next(iter(holding))
    c.tx(src, {src: -holding[src] / 2, "RECEIVER" + "r" * 35: holding[src] / 2}, 0,
         logs=["Program log: Instruction: Transfer"])
    # migración: el resto de la curva pasa al pool
    rest = c.tok[BC]
    c.tx("MIGRATOR" + "m" * 35, {BC: -rest, POOL: rest}, 0, logs=["Program log: Instruction: Migrate"])
    for k in range(30):
        w = rng.choice(wallets)
        amt = rng.uniform(100_000, 900_000)
        c.buy(w, amt, round(amt * 9e-8, 9), dt=30)
    # la cadena del mint son solo las txs desde la creación
    c.txs = c.txs[base:]
    return c, create_slot


def main():
    print("\n== limpio (creador no compra)")
    c, create_slot = scenario()
    out = tempfile.mkdtemp()
    rpc = FakeRPC(c)
    r = tf.run(rpc, MINT, out, fee_mode="holder_rewards", wallet_age=60, wallet_age_pages=3, declare_no_buys=True)
    m, info = r["metrics"], r["info"]
    import pandas as pd
    tr = pd.read_csv(os.path.join(out, "trades.csv"))
    check(">1000 firmas: paginación completa", info["n_tx_ok"] + info["n_tx_failed"] == len(c.txs),
          (info["n_tx_ok"], info["n_tx_failed"], len(c.txs)))
    check("1 tx fallida detectada y excluida", info["n_tx_failed"] == 1, info["n_tx_failed"])
    check("creador identificado", info["creator"] == CREATOR, info["creator"])
    check("slot de creación", info["create_slot"] == create_slot, info["create_slot"])
    check("cuentas de sistema = curva + pool", set(info["system_accounts"]) == {BC, POOL}, info["system_accounts"])
    check("migración detectada", info["migration_signature"] is not None)
    check("nº compras = verdad", int((tr.side == "buy").sum()) == c.truth["buys"], (int((tr.side == 'buy').sum()), c.truth["buys"]))
    check("nº ventas = verdad", int((tr.side == "sell").sum()) == c.truth["sells"], (int((tr.side == 'sell').sum()), c.truth["sells"]))
    err = max(abs(row.sol_amount - c.truth["sol"][row.signature]) for row in tr.itertuples())
    check("SOL por trade exacto (alquiler y wSOL corregidos, error < 1e-9)", err < 1e-9, err)
    check("transferencia entre wallets no es trade y se cuenta", info["transfers_between_wallets"] == 1,
          info["transfers_between_wallets"])
    true_holders = sum(1 for o, b in c.tok.items() if o not in (BC, POOL) and b > 1e-9)
    check("holders finales = verdad (incluye receptor de transferencia)", m["final_holders"] == true_holders,
          (m["final_holders"], true_holders))
    check("snipers en 2 slots = 3", m["sniper_buys_first_2_slots"] == 3, m["sniper_buys_first_2_slots"])
    check("compras de terceros en slot de creación = 2", m["buys_in_creation_slot_non_creator"] == 2,
          m["buys_in_creation_slot_non_creator"])
    check("creador sin trades", m["creator_trades"] == 0, m["creator_trades"])
    check("control negativo: sin vínculo creador→compradores",
          r["control_negative"]["verdict"].startswith("Sin vínculos"), r["control_negative"]["verdict"])
    check("parseo coherente (signo SOL)", m["parse_sol_sign_inconsistent_rate"] == 0, m["parse_sol_sign_inconsistent_rate"])
    wa = pd.read_csv(os.path.join(out, "wallet_age.csv"))
    old = wa[wa.wallet.str.startswith("OLDW") & wa.history_exhausted]
    check("wallets con historial de 400 días NO fresh", len(old) > 0 and not old.fresh.any(), old.fresh.tolist()[:5])
    check("salidas phase0 escritas", all(os.path.exists(os.path.join(out, f)) for f in
                                         ("p0_tokens.parquet", "p0_trades.parquet", "p0_migrations.parquet", "p0_config.json")))
    # reanudación: segunda ejecución no vuelve a descargar transacciones
    rpc2 = FakeRPC(c)
    tf.run(rpc2, MINT, out, fee_mode="holder_rewards")
    check("reanudación usa la caché (solo llamadas de firmas)", rpc2.calls <= 3, rpc2.calls)
    # compatibilidad con phase0_audit
    import subprocess
    p = subprocess.run([sys.executable, os.path.join(HERE, "phase0_audit.py"), "--config",
                        os.path.join(out, "p0_config.json"), "--out", os.path.join(out, "p0")],
                       capture_output=True, text=True)
    check("phase0_audit lee la salida sin errores", p.returncode == 0, p.stderr[-400:])
    shutil.rmtree(out)

    print("\n== creador compra (declarado limpio: el informe debe cazarlo)")
    c, _ = scenario(creator_buys=True)
    out = tempfile.mkdtemp()
    r = tf.run(FakeRPC(c), MINT, out, declare_no_buys=True)
    chk = r["control_negative"]["checks"][0]
    check("compra del creador detectada", r["metrics"]["creator_buys"] == 1, r["metrics"]["creator_buys"])
    check("check 'creador sin trades' FALLA", chk["pass"] is False, chk)
    shutil.rmtree(out)

    print("\n== comprador financiado por el creador (vínculo creator-linked)")
    c, _ = scenario(linked_funding=True)
    c.buy("LINKED" + "l" * 37, 1_000_000, 0.05, dt=5)
    out = tempfile.mkdtemp()
    r = tf.run(FakeRPC(c), MINT, out, wallet_age=2000, declare_no_buys=True)
    check("vínculo creador→comprador detectado", any("involucra al creador" in f for f in r["control_negative"]["detector_flags"]),
          r["control_negative"]["detector_flags"])
    shutil.rmtree(out)

    print(f"\n{'TODO OK' if not FAILS else f'{len(FAILS)} FALLOS: {FAILS}'}")
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()

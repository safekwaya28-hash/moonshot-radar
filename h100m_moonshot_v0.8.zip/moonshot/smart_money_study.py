#!/usr/bin/env python3
from __future__ import annotations

"""H-100M Smart Money Flat-Base Study v0.2.

CURRENT STRATEGY (the active hypothesis; NOT breakout):
    1) Token previously reached >= $500k market cap.
    2) At signal time it is down >= 70% from its historical peak and has been flat
       for the previous 48-72h (configurable; default 72h, +/-25% around the median).
    3) Historical *peak 24h volume* observed up to signal >= $500k (configurable window).
    4) A pre-selected Pump.fun smart wallet buys >= $5k while the token is in the base.
    5) Our simulated entry occurs after a realistic delay, and is rejected if price/MC
       is >30% above the smart-wallet execution level or is no longer in the base.
    6) Strategy exits: 50% at 2x when hit; runner exits when that wallet has sold >=50%
       of its signal-time position; hard stop at the base floor; otherwise mark at 7d.

Smart wallets are selected ONLY in period A from realized PnL and evaluated ONLY in B.
The code intentionally uses point-in-time data for token qualification. It also emits
same-time matched controls so smart-base observations can be compared with flat bases
without a qualifying smart-wallet buy.
"""

import argparse
import json
from collections import deque
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd

DEFAULT_CONFIG = {
    "preregistration_id": "smart_money_flat_v0.2_candidate",
    "smart_wallet_selection": {
        "period_a_start": None,
        "period_a_end": None,
        "min_realized_pnl_usd": 1_000_000.0,
        "min_closed_trades": 20,
        "min_distinct_tokens": 5,
        "max_positive_pnl_share_one_token": 0.50,
    },
    "evaluation": {
        "period_b_start": None,
        "period_b_end": None,
        "trade_delays_seconds": [60, 300],
        "control_exclusion_minutes": 5,
    },
    "base": {
        "peak_mc_min_usd": 500_000.0,
        "drawdown_min": 0.70,
        "flat_window_hours": 72.0,
        "flat_band_pct": 0.25,
        "min_flat_points": 5,
        "min_episode_hours": 0.0,
        "max_entry_premium_vs_trader": 0.30,
        "min_trader_buy_usd": 5_000.0,
        "min_historical_volume_usd": 500_000.0,
        "volume_window_hours": 24.0,
    },
    "exit": {
        "trader_sell_fraction": 0.50,
        "take_profit_multiple": 2.0,
        "take_profit_fraction": 0.50,
        "horizon_hours": 168.0,
        "stop_buffer_pct": 0.0,
    },
    "data": {
        "timestamp_unit": "auto",
        "max_price_staleness_seconds": 7200,
    },
}

ALIASES = {
    "mint": ["mint", "token", "token_address", "token_mint", "address"],
    "ts": ["ts", "timestamp", "time", "block_time", "created_at", "datetime"],
    "mc_usd": ["mc_usd", "market_cap", "marketcap", "usd_market_cap", "mcap"],
    "holders": ["holders", "holder_count", "holders_count"],
    "wallet": ["wallet", "trader", "signer", "user"],
    "side": ["side", "direction", "type", "is_buy"],
    "quote_amount": ["quote_amount", "usd_amount", "sol_amount", "lamports"],
    "token_amount": ["token_amount", "amount", "token_amount_raw"],
    "price_usd": ["price_usd", "usd_price", "price"],
    "volume_usd": ["volume_usd", "volume", "volume_24h_usd"],
    "signature": ["signature", "tx", "tx_hash"],
}
BUY = {"buy", "b", "bid", "1", "true", "1.0"}
SELL = {"sell", "s", "ask", "-1", "false", "0"}


def deep_merge(base: dict, update: dict) -> dict:
    out = {**base}
    for k, v in update.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def read_table(path: str) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() == ".csv":
        return pd.read_csv(p)
    if p.suffix.lower() == ".jsonl":
        return pd.read_json(p, lines=True)
    if p.suffix.lower() == ".json":
        return pd.read_json(p)
    if p.suffix.lower() in {".parquet", ".pq"}:
        return pd.read_parquet(p)
    raise ValueError(f"Formato no soportado: {p}")


def rename_aliases(df: pd.DataFrame, required: Iterable[str], name: str) -> pd.DataFrame:
    out = df.copy()
    cols = set(map(str, out.columns))
    ren = {}
    for canon, names in ALIASES.items():
        if canon not in out.columns:
            found = next((n for n in names if n in cols), None)
            if found:
                ren[found] = canon
    out = out.rename(columns=ren)
    miss = [c for c in required if c not in out.columns]
    if miss:
        raise ValueError(f"{name}: faltan {miss}; disponibles={list(out.columns)}")
    return out


def parse_ts(s: pd.Series, unit: str) -> pd.Series:
    if pd.api.types.is_datetime64_any_dtype(s):
        return pd.to_datetime(s, utc=True)
    if pd.api.types.is_numeric_dtype(s):
        v = pd.to_numeric(s, errors="coerce")
        med = float(v.dropna().median()) if not v.dropna().empty else 0.0
        use = "ms" if unit == "ms" or (unit == "auto" and med > 1e11) else "s"
        return pd.to_datetime(v, unit=use, utc=True)
    return pd.to_datetime(s, utc=True, errors="coerce")


def load_snapshots(path: str, cfg: dict) -> pd.DataFrame:
    x = rename_aliases(read_table(path), ["mint", "ts", "mc_usd"], "snapshots")
    x["ts"] = parse_ts(x.ts, cfg["data"]["timestamp_unit"])
    for c in ["mc_usd", "holders", "volume_usd"]:
        if c in x.columns:
            x[c] = pd.to_numeric(x[c], errors="coerce")
    x = x.dropna(subset=["mint", "ts", "mc_usd"]).copy()
    x = x[x.mc_usd > 0].sort_values(["mint", "ts"]).drop_duplicates(["mint", "ts"], keep="last")
    return x.reset_index(drop=True)


def load_trades(path: str, cfg: dict) -> pd.DataFrame:
    x = rename_aliases(read_table(path), ["mint", "ts", "wallet", "side"], "trades")
    x["ts"] = parse_ts(x.ts, cfg["data"]["timestamp_unit"])
    x["wallet"] = x.wallet.astype(str)
    x["side"] = x.side.astype(str).str.lower()
    for c in ["quote_amount", "token_amount", "price_usd", "volume_usd"]:
        if c in x.columns:
            x[c] = pd.to_numeric(x[c], errors="coerce")
    return x.dropna(subset=["mint", "ts", "wallet"]).sort_values(["mint", "ts"]).reset_index(drop=True)


def load_sol_price(path: Optional[str], cfg: dict) -> Optional[pd.DataFrame]:
    if not path:
        return None
    x = rename_aliases(read_table(path), ["ts", "price_usd"], "sol_price")
    x["ts"] = parse_ts(x.ts, cfg["data"]["timestamp_unit"])
    x["price_usd"] = pd.to_numeric(x.price_usd, errors="coerce")
    return x.dropna(subset=["ts", "price_usd"]).sort_values("ts")


def side_kind(v) -> Optional[str]:
    if isinstance(v, (bool, np.bool_)):
        return "buy" if bool(v) else "sell"
    s = str(v).strip().lower()
    if s in BUY:
        return "buy"
    if s in SELL:
        return "sell"
    return None


def trade_usd_values(trades: pd.DataFrame, sol_px: Optional[pd.DataFrame]) -> pd.Series:
    if "volume_usd" in trades.columns and trades["volume_usd"].notna().any():
        return pd.to_numeric(trades["volume_usd"], errors="coerce").abs().fillna(0.0)
    if "price_usd" in trades.columns and "token_amount" in trades.columns:
        v = pd.to_numeric(trades["price_usd"], errors="coerce").abs() * pd.to_numeric(trades["token_amount"], errors="coerce").abs()
        if v.notna().any():
            return v.fillna(0.0)
    if "quote_amount" not in trades.columns:
        return pd.Series(np.zeros(len(trades)), index=trades.index, dtype=float)
    q = pd.to_numeric(trades["quote_amount"], errors="coerce").abs().fillna(0.0)
    if sol_px is None:
        return q
    p = sol_px.sort_values("ts")[["ts", "price_usd"]]
    x = trades[["ts"]].copy()
    x["q"] = q.to_numpy()
    y = pd.merge_asof(x.sort_values("ts"), p, on="ts", direction="backward", tolerance=pd.Timedelta(seconds=cfg_staleness_placeholder()))
    raw = q.to_numpy(float)
    px = y["price_usd"].fillna(0).to_numpy(float)
    out = np.zeros(len(raw), dtype=float)
    lamports = raw > 1e6
    out[lamports] = raw[lamports] / 1e9 * px[lamports]
    out[~lamports] = raw[~lamports] * px[~lamports]
    return pd.Series(out, index=trades.index)


def cfg_staleness_placeholder() -> int:
    # Kept as a small helper to make the conversion function independent from global config.
    return 7200


def token_qty_values(trades: pd.DataFrame) -> pd.Series:
    if "token_amount" in trades.columns:
        q = pd.to_numeric(trades["token_amount"], errors="coerce").abs()
        if q.notna().any():
            return q.fillna(0.0)
    if "price_usd" in trades.columns and "quote_amount" in trades.columns:
        px = pd.to_numeric(trades["price_usd"], errors="coerce").abs()
        qa = pd.to_numeric(trades["quote_amount"], errors="coerce").abs()
        out = np.divide(qa.to_numpy(float), px.to_numpy(float), out=np.zeros(len(trades)), where=px.to_numpy(float) > 0)
        return pd.Series(out, index=trades.index)
    return pd.Series(np.zeros(len(trades)), index=trades.index)


def fifo_realized_pnl(trades: pd.DataFrame) -> pd.DataFrame:
    """FIFO realized PnL for matched sells only; opening inventory is not guessed."""
    x = trades.copy()
    x["_kind"] = x.side.map(side_kind)
    x["_usd"] = pd.to_numeric(x["_trade_usd"], errors="coerce").fillna(0.0)
    x["_qty"] = pd.to_numeric(x["_qty"], errors="coerce").fillna(0.0)
    rows = []
    for (wallet, mint), g in x.sort_values("ts").groupby(["wallet", "mint"], sort=False):
        lots = deque()
        for _, r in g.iterrows():
            qty = float(r["_qty"]); usd = float(r["_usd"]); kind = r["_kind"]
            if qty <= 0 or usd < 0:
                continue
            if kind == "buy":
                lots.append([qty, usd / qty if qty else 0.0])
            elif kind == "sell":
                remaining = qty; realized = 0.0; matched_qty = 0.0
                proceeds_per_unit = usd / qty if qty else 0.0
                while remaining > 1e-12 and lots:
                    lq, cpu = lots[0]
                    take = min(remaining, lq)
                    realized += take * (proceeds_per_unit - cpu)
                    matched_qty += take; remaining -= take; lq -= take
                    if lq <= 1e-12:
                        lots.popleft()
                    else:
                        lots[0][0] = lq
                if matched_qty > 0:
                    rows.append({
                        "wallet": wallet, "mint": mint, "ts": r["ts"], "signature": r.get("signature"),
                        "realized_pnl_usd": realized,
                        "matched_qty": matched_qty,
                        "sell_usd": usd * (matched_qty / qty),
                    })
    return pd.DataFrame(rows)


def select_smart_wallets(trades: pd.DataFrame, cfg: dict):
    sel = cfg["smart_wallet_selection"]
    a0 = pd.Timestamp(sel["period_a_start"], tz="UTC")
    a1 = pd.Timestamp(sel["period_a_end"], tz="UTC")
    x = trades[(trades.ts >= a0) & (trades.ts <= a1)].copy()
    realized = fifo_realized_pnl(x)
    if realized.empty:
        return pd.DataFrame(), realized
    g = realized.groupby("wallet", as_index=False).agg(
        realized_pnl_usd=("realized_pnl_usd", "sum"),
        closed_trades=("mint", "size"),
        distinct_tokens=("mint", "nunique"),
    )
    pos = realized[realized.realized_pnl_usd > 0].groupby(["wallet", "mint"], as_index=False).realized_pnl_usd.sum()
    if pos.empty:
        g["positive_pnl_usd"] = 0.0; g["max_positive_pnl_share_one_token"] = np.nan
    else:
        tot = pos.groupby("wallet").realized_pnl_usd.sum().rename("positive_pnl_usd")
        mx = pos.groupby("wallet").realized_pnl_usd.max().rename("max_token_positive_pnl_usd")
        g = g.merge(tot, on="wallet", how="left").merge(mx, on="wallet", how="left")
        g["max_positive_pnl_share_one_token"] = g.max_token_positive_pnl_usd / g.positive_pnl_usd.replace(0, np.nan)
    keep = (
        (g.realized_pnl_usd >= float(sel["min_realized_pnl_usd"])) &
        (g.closed_trades >= int(sel["min_closed_trades"])) &
        (g.distinct_tokens >= int(sel["min_distinct_tokens"])) &
        (g.max_positive_pnl_share_one_token.fillna(1.0) <= float(sel["max_positive_pnl_share_one_token"]))
    )
    return g[keep].sort_values("realized_pnl_usd", ascending=False).reset_index(drop=True), realized


def rolling_volume_at(times: np.ndarray, trade_ts: np.ndarray, trade_values: np.ndarray, window_hours: float) -> np.ndarray:
    out = np.zeros(len(times), dtype=float)
    if len(trade_ts) == 0:
        return out
    pref = np.r_[0.0, np.cumsum(trade_values)]
    td = np.timedelta64(int(window_hours * 3600), "s")
    for i, ti in enumerate(times):
        hi = int(np.searchsorted(trade_ts, ti, side="right"))
        lo = int(np.searchsorted(trade_ts, ti - td, side="right"))
        out[i] = pref[hi] - pref[lo]
    return out


def base_state_at(token_snaps: pd.DataFrame, token_trades: pd.DataFrame, t: pd.Timestamp, cfg: dict) -> Optional[dict]:
    b = cfg["base"]
    hist = token_snaps[token_snaps.ts <= t].sort_values("ts").reset_index(drop=True)
    if hist.empty:
        return None
    now = hist.iloc[-1]
    mc = hist.mc_usd.to_numpy(float)
    peak = float(np.max(mc))
    dd = 1.0 - float(now.mc_usd) / peak if peak > 0 else np.nan
    win = hist[hist.ts >= t - pd.Timedelta(hours=float(b["flat_window_hours"]))]
    if len(win) < int(b["min_flat_points"]):
        return None
    lo = float(win.mc_usd.min()); hi = float(win.mc_usd.max()); center = float(win.mc_usd.median())
    band = float(b["flat_band_pct"])
    flat = lo >= center * (1 - band) and hi <= center * (1 + band)
    tv = token_trades[token_trades.ts <= t].sort_values("ts") if token_trades is not None and len(token_trades) else pd.DataFrame()
    if not tv.empty:
        # v0.3 FIX: "volumen histórico" = MÁXIMO del volumen móvil de 24h observado hasta t.
        # (v0.2 usaba el volumen de las últimas 24h, que en una base dormida es bajo por definición
        #  y rechazaba justo los tokens buscados.)
        tts = tv.ts.to_numpy(dtype="datetime64[ns]")
        vals = tv._trade_usd.to_numpy(float)
        roll = rolling_volume_at(tts, tts, vals, float(b["volume_window_hours"]))
        vol = float(roll.max())
        vol_now = float(rolling_volume_at(np.array([np.datetime64(t.to_datetime64())]), tts, vals,
                                          float(b["volume_window_hours"]))[0])
    else:
        vol = 0.0
        vol_now = 0.0
    eligible = bool(peak >= float(b["peak_mc_min_usd"]) and dd >= float(b["drawdown_min"]) and flat and vol >= float(b["min_historical_volume_usd"]))
    return {
        "state_time": now.ts,
        "current_mc_usd": float(now.mc_usd),
        "peak_mc_usd": peak,
        "drawdown_from_peak": dd,
        "flat_floor_mc_usd": lo,
        "flat_ceiling_mc_usd": hi,
        "flat_center_mc_usd": center,
        "flat_points": int(len(win)),
        "historical_peak_volume_usd": float(vol),
        "current_24h_volume_usd": vol_now,
        "eligible": eligible,
    }


def build_flat_base_episodes(snapshots: pd.DataFrame, trades: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    rows = []
    b = cfg["base"]
    for mint, g in snapshots.groupby("mint", sort=False):
        s = g.sort_values("ts").reset_index(drop=True)
        if len(s) < int(b["min_flat_points"]):
            continue
        tg = trades[trades.mint.astype(str) == str(mint)] if not trades.empty else pd.DataFrame()
        # Point-in-time series for eligibility.
        states = [base_state_at(s, tg, t, cfg) for t in s.ts]
        ok = np.array([st is not None and st["eligible"] for st in states], dtype=bool)
        idx = np.where(ok)[0]
        if not len(idx):
            continue
        start = prev = int(idx[0]); spans=[]
        for i in idx[1:]:
            i=int(i)
            if i != prev+1:
                spans.append((start, prev)); start=i
            prev=i
        spans.append((start, prev))
        for a,z in spans:
            dur=(s.ts.iloc[z]-s.ts.iloc[a]).total_seconds()/3600
            if dur + 1e-9 < float(b["min_episode_hours"]):
                continue
            st=states[z]
            rows.append({
                "mint": str(mint),
                "episode_id": f"{mint}:{s.ts.iloc[a].isoformat()}",
                "base_start": s.ts.iloc[a], "base_end": s.ts.iloc[z],
                "base_duration_hours": dur,
                "peak_mc_usd": float(st["peak_mc_usd"]),
                "base_floor_mc_usd_at_episode_end": float(st["flat_floor_mc_usd"]),
                "historical_peak_volume_usd_at_episode_end": float(st["historical_peak_volume_usd"]),
            })
    return pd.DataFrame(rows)


def snapshot_at_or_before(s: pd.DataFrame, t: pd.Timestamp) -> Optional[pd.Series]:
    z=s[s.ts<=t]
    return None if z.empty else z.iloc[-1]


def snapshot_at_or_after(s: pd.DataFrame, t: pd.Timestamp) -> Optional[pd.Series]:
    z=s[s.ts>=t]
    return None if z.empty else z.iloc[0]


def position_path(wallet_trades: pd.DataFrame) -> pd.DataFrame:
    x=wallet_trades.sort_values("ts").copy(); x["_kind"]=x.side.map(side_kind); x["_qty"]=token_qty_values(x)
    pos=0.0; rows=[]
    for _,r in x.iterrows():
        q=float(r["_qty"]); k=r["_kind"]
        if k=="buy": pos+=q
        elif k=="sell": pos=max(0.0,pos-q)
        rows.append((r["ts"],pos,k,q,r.get("signature")))
    return pd.DataFrame(rows,columns=["ts","position_qty","kind","qty","signature"])


def price_only_outcomes(token_snaps: pd.DataFrame, entry_time: pd.Timestamp, entry_mc: float, horizon_h: float) -> dict:
    path=token_snaps[(token_snaps.ts>=entry_time) & (token_snaps.ts<=entry_time+pd.Timedelta(hours=horizon_h))].sort_values("ts")
    if path.empty or entry_mc<=0:
        return {"mfe_24h_multiple":None,"mfe_7d_multiple":None,"hit_2x":False,"hit_10x":False,"horizon_multiple":None}
    p24=path[path.ts<=entry_time+pd.Timedelta(hours=24)]
    return {
        "mfe_24h_multiple": float(p24.mc_usd.max()/entry_mc) if not p24.empty else None,
        "mfe_7d_multiple": float(path.mc_usd.max()/entry_mc),
        "hit_2x": bool((path.mc_usd>=entry_mc*2).any()),
        "hit_10x": bool((path.mc_usd>=entry_mc*10).any()),
        "horizon_multiple": float(path.mc_usd.iloc[-1]/entry_mc),
    }


def exit_simulation(path: pd.DataFrame, entry_time, entry_mc: float, stop_mc: float, trader_exit, cfg: dict) -> dict:
    """Mismas reglas de salida para señales y controles (comparación homogénea)."""
    ex = cfg["exit"]
    tp_target = entry_mc * float(ex["take_profit_multiple"])
    tp = path[path.mc_usd >= tp_target]
    tp_time = tp.iloc[0].ts if not tp.empty else None
    stop = path[path.mc_usd <= stop_mc]
    stop_time = stop.iloc[0].ts if not stop.empty else None
    cands = [x for x in [("STOP", stop_time), ("TRADER_SELL", trader_exit)] if x[1] is not None]
    terminal_kind, terminal_t = min(cands, key=lambda x: x[1]) if cands else ("HORIZON", path.ts.iloc[-1])
    terminal_mc = float(path[path.ts >= terminal_t].iloc[0].mc_usd) if (path.ts >= terminal_t).any() else float(path.mc_usd.iloc[-1])
    tp_frac = float(ex["take_profit_fraction"])
    if tp_time is not None and pd.Timestamp(tp_time) < pd.Timestamp(terminal_t):
        gross = tp_frac * float(ex["take_profit_multiple"]) + (1 - tp_frac) * (terminal_mc / entry_mc)
        tp_realized = tp_frac
    else:
        gross = terminal_mc / entry_mc
        tp_realized = 0.0
    return {"tp_time": tp_time, "stop_time": stop_time, "terminal_event": terminal_kind, "terminal_time": terminal_t,
            "terminal_mc_usd": terminal_mc, "take_profit_fraction_realized": tp_realized,
            "gross_multiple": gross, "gross_return_pct": gross - 1}


def simulate_entry_exit(signal: dict, token_snaps: pd.DataFrame, token_trades: pd.DataFrame,
                        wallet_token_trades: pd.DataFrame, cfg: dict, delay_s: int) -> dict:
    """v0.3 FIX: token_trades (TODOS) -> estado de la base; wallet_token_trades (solo el trader) -> su posición.
    v0.2 usaba todos los trades del token como 'posición del trader', así que la regla de salida
    por venta del trader no podía activarse nunca."""
    b=cfg["base"]; ex=cfg["exit"]
    target=signal["trader_buy_time"]+pd.Timedelta(seconds=int(delay_s))
    row=snapshot_at_or_after(token_snaps,target)
    if row is None:
        return {**signal,"delay_seconds":delay_s,"status":"NO_ENTRY_DATA"}
    entry_time=row.ts; entry_mc=float(row.mc_usd); trader_mc=float(signal["trader_buy_mc_usd"])
    if entry_mc > trader_mc*(1+float(b["max_entry_premium_vs_trader"])):
        return {**signal,"delay_seconds":delay_s,"status":"NO_ENTRY_CHASE","entry_time":entry_time,"entry_mc_usd":entry_mc}
    entry_state=base_state_at(token_snaps, token_trades, entry_time, cfg)
    if entry_state is None or not entry_state["eligible"]:
        return {**signal,"delay_seconds":delay_s,"status":"NO_ENTRY_NOT_FLAT","entry_time":entry_time,"entry_mc_usd":entry_mc}

    pth=position_path(wallet_token_trades)
    before=pth[pth.ts<=signal["trader_buy_time"]]
    pos=float(before.iloc[-1].position_qty) if not before.empty else 0.0
    if pos<=0:
        after=pth[pth.ts>=signal["trader_buy_time"]]
        pos=float(after.iloc[0].position_qty) if not after.empty else 0.0
    if pos<=0:
        return {**signal,"delay_seconds":delay_s,"status":"NO_ENTRY_NO_POSITION"}
    threshold=pos*(1-float(ex["trader_sell_fraction"]))
    stop_mc=float(signal["base_floor_mc_usd_at_signal"])*(1-float(ex["stop_buffer_pct"]))
    horizon=entry_time+pd.Timedelta(hours=float(ex["horizon_hours"]))
    path=token_snaps[(token_snaps.ts>=entry_time)&(token_snaps.ts<=horizon)].sort_values("ts")
    if path.empty:
        return {**signal,"delay_seconds":delay_s,"status":"NO_FORWARD_DATA","entry_time":entry_time,"entry_mc_usd":entry_mc}

    later=pth[pth.ts>entry_time]
    trader_exit=None
    if not later.empty:
        q=later[later.position_qty<=threshold]
        if not q.empty: trader_exit=q.iloc[0].ts
    sim=exit_simulation(path, entry_time, entry_mc, stop_mc, trader_exit, cfg)
    po=price_only_outcomes(token_snaps,entry_time,entry_mc,float(ex["horizon_hours"]))
    return {**signal,"delay_seconds":delay_s,"status":"ENTERED","entry_time":entry_time,"entry_mc_usd":entry_mc,
            "entry_multiple_vs_trader":entry_mc/trader_mc if trader_mc else None,
            "entry_advantage_pct":1-entry_mc/trader_mc if trader_mc else None,
            "entry_flat_floor_mc_usd":float(entry_state["flat_floor_mc_usd"]),
            "entry_flat_center_mc_usd":float(entry_state["flat_center_mc_usd"]),
            "trader_position_at_signal":pos,"trader_exit_time":trader_exit,
            **sim, **po}


def build_signals(smart: pd.DataFrame, snapshots: pd.DataFrame, trades: pd.DataFrame, bases: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    if smart.empty or bases.empty:
        return pd.DataFrame()
    b=cfg["base"]; B0=pd.Timestamp(cfg["evaluation"]["period_b_start"],tz="UTC"); B1=pd.Timestamp(cfg["evaluation"]["period_b_end"],tz="UTC")
    smart_set=set(smart.wallet.astype(str))
    buys=trades[(trades.wallet.astype(str).isin(smart_set))&(trades.ts>=B0)&(trades.ts<=B1)&(trades._kind=="buy")&(trades._trade_usd>=float(b["min_trader_buy_usd"]))].copy()
    signals=[]
    for mint,g in buys.groupby("mint",sort=False):
        g=g.sort_values("ts")
        tok=snapshots[snapshots.mint.astype(str)==str(mint)].sort_values("ts").reset_index(drop=True)
        if tok.empty: continue
        for _,r in g.iterrows():
            tt=r["ts"]; pre=snapshot_at_or_before(tok,tt)
            if pre is None: continue
            state=base_state_at(tok,trades[trades.mint.astype(str)==str(mint)],pre.ts,cfg)
            if state is None or not state["eligible"]: continue
            ep=bases[(bases.mint==str(mint))&(bases.base_start<=pre.ts)&(bases.base_end>=pre.ts)]
            if ep.empty: continue
            e=ep.iloc[0].to_dict()
            signals.append({**e,"trader_wallet":str(r["wallet"]),"trader_buy_time":tt,"signal_snapshot_time":pre.ts,
                            "trader_buy_usd":float(r["_trade_usd"]),"trader_buy_mc_usd":float(state["current_mc_usd"]),
                            "base_floor_mc_usd_at_signal":float(state["flat_floor_mc_usd"]),
                            "base_center_mc_usd_at_signal":float(state["flat_center_mc_usd"]),
                            "drawdown_from_peak_at_signal":float(state["drawdown_from_peak"]),
                            "historical_peak_volume_usd_at_signal":float(state["historical_peak_volume_usd"]),
                            "signal_signature":r.get("signature")})
            # v0.3: una señal (la primera compra) por episodio de base, no una por token
    if not signals: return pd.DataFrame()
    s=pd.DataFrame(signals).drop_duplicates("episode_id", keep="first").reset_index(drop=True)
    # Add convergence: unique smart wallets that qualify in the same token episode.
    qualifying=[]
    for _,sig in s.iterrows():
        q=buys[(buys.mint.astype(str)==sig.mint)&(buys.ts>=sig.base_start)&(buys.ts<=sig.base_end)]
        qualifying.append(q.wallet.astype(str).nunique())
    s["smart_wallet_count"]=qualifying
    return s


def build_controls(signals: pd.DataFrame, snapshots: pd.DataFrame, trades: pd.DataFrame, smart_set: set[str], cfg: dict) -> pd.DataFrame:
    if signals.empty: return pd.DataFrame()
    excl=pd.Timedelta(minutes=int(cfg["evaluation"]["control_exclusion_minutes"]))
    rows=[]
    for _,sig in signals.iterrows():
        t=sig["signal_snapshot_time"]
        candidates=[]
        for mint,g in snapshots.groupby("mint",sort=False):
            if str(mint)==str(sig["mint"]): continue
            tok=g.sort_values("ts").reset_index(drop=True)
            state=base_state_at(tok,trades[trades.mint.astype(str)==str(mint)],t,cfg)
            if state is None or not state["eligible"]: continue
            # Exclude tokens with any qualifying smart-wallet buy around the treatment time.
            q=trades[(trades.mint.astype(str)==str(mint))&(trades.ts>=t-excl)&(trades.ts<=t+excl)&(trades.wallet.astype(str).isin(smart_set))&(trades._kind=="buy")&(trades._trade_usd>=float(cfg["base"]["min_trader_buy_usd"]))]
            if not q.empty: continue
            # Deterministic nearest-match on log MC and drawdown.
            dist=abs(np.log(max(state["current_mc_usd"],1)/max(float(sig["trader_buy_mc_usd"]),1)))+abs(state["drawdown_from_peak"]-float(sig["drawdown_from_peak_at_signal"]))
            candidates.append((dist,str(mint),state))
        if not candidates: continue
        _,cm,state=min(candidates,key=lambda x:(x[0],x[1]))
        rows.append({
            "control_for_signal_episode":sig["episode_id"],"mint":cm,"control_time":t,
            "current_mc_usd":state["current_mc_usd"],"peak_mc_usd":state["peak_mc_usd"],
            "drawdown_from_peak":state["drawdown_from_peak"],"flat_floor_mc_usd":state["flat_floor_mc_usd"],
            "historical_peak_volume_usd":state["historical_peak_volume_usd"],
        })
    return pd.DataFrame(rows)


def evaluate_controls(controls: pd.DataFrame, snapshots: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    if controls.empty: return pd.DataFrame()
    rows=[]
    for _,r in controls.iterrows():
        tok=snapshots[snapshots.mint.astype(str)==str(r.mint)].sort_values("ts").reset_index(drop=True)
        for d in [int(x) for x in cfg["evaluation"]["trade_delays_seconds"]]:
            row=snapshot_at_or_after(tok,r.control_time+pd.Timedelta(seconds=d))
            if row is None: continue
            po=price_only_outcomes(tok,row.ts,float(row.mc_usd),float(cfg["exit"]["horizon_hours"]))
            path=tok[(tok.ts>=row.ts)&(tok.ts<=row.ts+pd.Timedelta(hours=float(cfg["exit"]["horizon_hours"])))]
            stop_mc=float(r.flat_floor_mc_usd)*(1-float(cfg["exit"]["stop_buffer_pct"]))
            sim=exit_simulation(path,row.ts,float(row.mc_usd),stop_mc,None,cfg) if not path.empty else {}
            rows.append({**r.to_dict(),"delay_seconds":d,"entry_time":row.ts,"entry_mc_usd":float(row.mc_usd),**po,**sim})
    return pd.DataFrame(rows)


def _boot_diff(a: np.ndarray, b: np.ndarray, n: int = 2000, seed: int = 7):
    if len(a) < 2 or len(b) < 2:
        return None
    rng = np.random.default_rng(seed)
    d = [rng.choice(a, len(a)).mean() - rng.choice(b, len(b)).mean() for _ in range(n)]
    return [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))]


def summarize_groups(results: pd.DataFrame, controls: pd.DataFrame) -> pd.DataFrame:
    """v0.3: por retraso; ambos grupos con la MISMA métrica (gross_multiple con idénticas reglas de salida,
    salvo la venta del trader, que el control no tiene) + IC bootstrap de la diferencia."""
    rows = []
    delays = sorted(set(results.delay_seconds) if not results.empty else set())
    for d in delays:
        r = results[(results.delay_seconds == d) & (results.status == "ENTERED")]
        c = controls[controls.delay_seconds == d] if not controls.empty else pd.DataFrame()
        c = c[c.get("gross_multiple").notna()] if len(c) and "gross_multiple" in c else pd.DataFrame()
        for name, g in (("SMART_BASE", r), ("CONTROL_BASE", c)):
            if g.empty:
                rows.append({"delay_seconds": d, "group": name, "n": 0}); continue
            rows.append({"delay_seconds": d, "group": name, "n": len(g),
                         "p_2x": float(g.hit_2x.mean()), "p_10x": float(g.hit_10x.mean()),
                         "median_mfe_7d": float(g.mfe_7d_multiple.median()),
                         "mean_strategy_multiple": float(g.gross_multiple.mean()),
                         "median_strategy_multiple": float(g.gross_multiple.median())})
        if len(r) and len(c):
            rows.append({"delay_seconds": d, "group": "DIFF_SMART_MINUS_CONTROL", "n": min(len(r), len(c)),
                         "p_2x": float(r.hit_2x.mean() - c.hit_2x.mean()),
                         "mean_strategy_multiple": float(r.gross_multiple.mean() - c.gross_multiple.mean()),
                         "ci95_mean_multiple_diff": _boot_diff(r.gross_multiple.to_numpy(float), c.gross_multiple.to_numpy(float)),
                         "ci95_p2x_diff": _boot_diff(r.hit_2x.to_numpy(float), c.hit_2x.to_numpy(float))})
    return pd.DataFrame(rows)


def study(snapshots: pd.DataFrame, trades: pd.DataFrame, sol_price: Optional[pd.DataFrame], cfg: dict) -> dict:
    t=trades.copy(); t["_trade_usd"]=trade_usd_values(t,sol_price); t["_qty"]=token_qty_values(t); t["_kind"]=t.side.map(side_kind)
    smart,realized=select_smart_wallets(t,cfg)
    # v0.3: prefiltro (no cambia resultados): un token que nunca llegó al pico mínimo no puede calificar.
    peak_ok=snapshots.groupby("mint").mc_usd.max()
    keep=set(peak_ok[peak_ok>=float(cfg["base"]["peak_mc_min_usd"])].index.astype(str))
    snapshots=snapshots[snapshots.mint.astype(str).isin(keep)]
    bases=build_flat_base_episodes(snapshots,t,cfg)
    signals=build_signals(smart,snapshots,t,bases,cfg)
    if signals.empty:
        return {"smart_wallets":smart,"smart_wallet_realized":realized,"base_episodes":bases,"signals":signals,"results":pd.DataFrame(),"controls":pd.DataFrame(),"control_results":pd.DataFrame(),"summary":pd.DataFrame()}
    delays=[int(x) for x in cfg["evaluation"]["trade_delays_seconds"]]
    rows=[]
    for _,sig in signals.iterrows():
        mint=str(sig.mint); tok=snapshots[snapshots.mint.astype(str)==mint].sort_values("ts").reset_index(drop=True)
        wallet_tok=t[(t.wallet.astype(str)==str(sig.trader_wallet))&(t.mint.astype(str)==mint)].copy()
        # simulate_entry_exit needs all token trades for point-in-time state; attach it to the wallet frame for API compatibility.
        token_all=t[t.mint.astype(str)==mint].copy()
        for d in delays:
            res=simulate_entry_exit(sig.to_dict(),tok,token_all,wallet_tok,cfg,d)
            rows.append(res)
    results=pd.DataFrame(rows)
    smart_set=set(smart.wallet.astype(str))
    controls=build_controls(signals,snapshots,t,smart_set,cfg)
    control_results=evaluate_controls(controls,snapshots,cfg)
    summary=summarize_groups(results,control_results)
    return {"smart_wallets":smart,"smart_wallet_realized":realized,"base_episodes":bases,"signals":signals,"results":results,"controls":controls,"control_results":control_results,"summary":summary}


def write_outputs(outdir: str,result: dict):
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True)
    files={
        "smart_wallets":"smart_wallets.csv",
        "smart_wallet_realized":"smart_wallet_realized_sales.csv",
        "base_episodes":"flat_base_episodes.csv",
        "signals":"smart_money_signals.csv",
        "results":"smart_money_results.csv",
        "controls":"matched_control_bases.csv",
        "control_results":"matched_control_results.csv",
        "summary":"smart_vs_control_summary.csv",
    }
    for key,fn in files.items(): result[key].to_csv(out/fn,index=False)
    meta={"study":"smart_money_flat_v0.3","point_in_time":True,"strategy":"top-smart-wallet buy inside deep flat base","breakout_required":False,
          "smart_wallets_selected_only_in_period_A":True,"evaluation_only_in_period_B":True}
    (out/"study_metadata.json").write_text(json.dumps(meta,indent=2,default=str),encoding="utf-8")


def main():
    ap=argparse.ArgumentParser(description="Smart Money Flat Base study")
    ap.add_argument("--snapshots",required=True); ap.add_argument("--trades",required=True); ap.add_argument("--sol-price")
    ap.add_argument("--config",required=True); ap.add_argument("--out",required=True)
    a=ap.parse_args(); cfg=deep_merge(DEFAULT_CONFIG,json.loads(Path(a.config).read_text(encoding="utf-8")))
    s=study(load_snapshots(a.snapshots,cfg),load_trades(a.trades,cfg),load_sol_price(a.sol_price,cfg),cfg); write_outputs(a.out,s)
    print(json.dumps({k:len(s[k]) for k in ["smart_wallets","base_episodes","signals","results","controls","control_results"]},indent=2))


if __name__=="__main__": main()

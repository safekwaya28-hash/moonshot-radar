#!/usr/bin/env python3
import sys
from pathlib import Path
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import smart_money_study as sm


def check(name, cond, got=None):
    ok=bool(cond); print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  (obtenido={got})" if not ok and got is not None else ""))
    if not ok: raise AssertionError(name)


def main():
    t0=pd.Timestamp('2026-01-01T00:00:00Z')
    rows=[]; sig=0
    # Smart wallet period A: 24 matched profitable sells across 6 tokens, >$1M realized PnL.
    for i in range(6):
        mint=f'TRAIN{i}'
        for j in range(4):
            tt=t0+pd.Timedelta(days=i,minutes=j*2)
            rows.append({'mint':mint,'ts':tt,'wallet':'SMART','side':'buy','quote_amount':100000.0,'token_amount':100000.0,'price_usd':1.0,'signature':f'b{sig}'}); sig+=1
            rows.append({'mint':mint,'ts':tt+pd.Timedelta(minutes=1),'wallet':'SMART','side':'sell','quote_amount':160000.0,'token_amount':100000.0,'price_usd':1.6,'signature':f's{sig}'}); sig+=1
    # B: token peaked at 600k, fell >70%, then stayed flat. Keep a future dip LOWER than signal floor to catch look-ahead.
    bt=t0+pd.Timedelta(days=100)
    hs=[0,6,12,18,24,30,36,42,48,54,60,66,72,78,84,90,96,102,108,114,120,126,132,138,144,150,156]
    mcs=[600000,180000,100000,80000,76000,75000,74000,76000,75000,75500,74500,75200,74800,75000,76000,77000,76500,75800,75200,76000,75500,74800,75200,75000,75500,74000,30000]
    snaps=[{'mint':'TOKENX','ts':bt+pd.Timedelta(hours=h),'mc_usd':m} for h,m in zip(hs,mcs)]
    # Same-time eligible control base: similar MC/DD/volume, no smart-wallet buy.
    cmcs=[550000,170000,95000,79000,75500,74500,73500,75500,74500,75200,74000,75000,74200,74800,75400,76000,75500,75000,74600,75200,74800,74200,75000,74800,75200,74000,73500]
    snaps += [{'mint':'CONTROL','ts':bt+pd.Timedelta(hours=h),'mc_usd':m} for h,m in zip(hs,cmcs)]
    tr2=[]
    # >=500k rolling 24h volume for TOKENX and CONTROL before the signal.
    for k in range(20):
        tr2.append({'mint':'CONTROL','ts':bt+pd.Timedelta(hours=70+k*0.2),'wallet':'CONTROL_USER','side':'buy','quote_amount':30000.0,'token_amount':30000.0,'price_usd':1.0,'signature':f'cv{k}'})
    # TOKENX volume below.
    for k in range(20):
        tr2.append({'mint':'TOKENX','ts':bt+pd.Timedelta(hours=70+k*0.2),'wallet':'OTHER','side':'buy','quote_amount':30000.0,'token_amount':30000.0,'price_usd':1.0,'signature':f'v{k}'})
    sigtime=bt+pd.Timedelta(hours=90)
    tr2 += [
        {'mint':'TOKENX','ts':sigtime,'wallet':'SMART','side':'buy','quote_amount':10000.0,'token_amount':133.3333,'price_usd':75.0,'signature':'qualbuy'},
        {'mint':'TOKENX','ts':bt+pd.Timedelta(hours=108),'wallet':'SMART','side':'sell','quote_amount':20000.0,'token_amount':266.6666,'price_usd':75.0,'signature':'sellhalf'}
    ]
    trades=pd.DataFrame(rows+tr2)
    snapshots=pd.DataFrame(snaps)
    cfg=sm.deep_merge(sm.DEFAULT_CONFIG,{
        'smart_wallet_selection':{'period_a_start':'2026-01-01T00:00:00Z','period_a_end':'2026-04-10T23:59:59Z','min_realized_pnl_usd':1_000_000,'min_closed_trades':20,'min_distinct_tokens':5,'max_positive_pnl_share_one_token':0.75},
        'evaluation':{'period_b_start':'2026-04-11T00:00:00Z','period_b_end':'2026-12-31T00:00:00Z','trade_delays_seconds':[60,300],'control_exclusion_minutes':5},
        'base':{'peak_mc_min_usd':500000,'drawdown_min':0.70,'flat_window_hours':72,'flat_band_pct':0.25,'min_flat_points':5,'min_episode_hours':0,'max_entry_premium_vs_trader':0.30,'min_trader_buy_usd':5000,'min_historical_volume_usd':500000,'volume_window_hours':24}
    })
    r=sm.study(snapshots,trades,None,cfg)
    check('smart wallet seleccionado solo en periodo A',len(r['smart_wallets'])==1 and r['smart_wallets'].iloc[0].wallet=='SMART')
    check('base válida detectada',len(r['base_episodes'])>=1)
    check('compra SMART detectada dentro de base',len(r['signals'])==1)
    sigrow=r['signals'].iloc[0]
    expected_floor=min(mcs[3:16])  # window around signal, no future 150h/156h dip
    check('suelo de señal es point-in-time',abs(float(sigrow.base_floor_mc_usd_at_signal)-expected_floor)<1e-9,(sigrow.base_floor_mc_usd_at_signal,expected_floor))
    check('no requiere breakout',all(x is not None for x in ['signals']))
    check('resultados con los dos retrasos',set(r['results'].delay_seconds)=={60,300})
    check('controles emparejados',len(r['control_results'])>=1,len(r['control_results']))
    # ---- v0.3: tests que detectan los fallos de v0.2
    res=r['results']
    check('v0.3 la señal SÍ produce entradas simuladas (v0.2: 0)',(res.status=='ENTERED').sum()==2,res.status.tolist())
    e=res[res.status=='ENTERED'].iloc[0]
    check('v0.3 posición = solo la del trader (133), no la de todo el token',abs(float(e.trader_position_at_signal)-133.3333)<1e-3,e.trader_position_at_signal)
    check('v0.3 sale cuando el TRADER vende (h108)',e.terminal_event=='TRADER_SELL' and pd.Timestamp(e.terminal_time)==bt+pd.Timedelta(hours=108),(e.terminal_event,e.terminal_time))
    check('v0.3 múltiplo = MC salida / MC entrada',abs(float(e.gross_multiple)-75200/76500)<1e-9,e.gross_multiple)
    summ=r['summary']
    check('v0.3 resumen por retraso con fila de diferencia',{'SMART_BASE','CONTROL_BASE','DIFF_SMART_MINUS_CONTROL'}<=set(summ.group),summ.group.tolist())
    check('v0.3 control evaluado con la misma métrica (gross_multiple)',r['control_results'].gross_multiple.notna().all())
    tr=trades.copy(); m=(tr.mint=='TOKENX')&(tr.wallet=='OTHER')
    tr.loc[m,'ts']=[bt+pd.Timedelta(hours=1+k*0.2) for k in range(int(m.sum()))]
    r2=sm.study(snapshots,tr,None,cfg)
    check('v0.3 volumen del pico inicial cuenta como histórico (base dormida sigue calificando)',len(r2['signals'])==1,len(r2['signals']))
    print('ALL SMART MONEY v0.3 TESTS PASS')

if __name__=='__main__': main()

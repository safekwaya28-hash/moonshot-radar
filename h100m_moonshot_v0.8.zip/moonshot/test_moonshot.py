#!/usr/bin/env python3
"""Tests del radar (moonshot.py) con el mundo simulado de moonshot_demo.py.   python test_moonshot.py"""
import sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import moonshot as ms
import moonshot_demo as d

FAILS = []
def check(name, cond, got=None):
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + ("" if cond else f"   (obtenido: {got})"))
    if not cond: FAILS.append(name)

print("\n== radar")
cards, T = d.run_demo()
by = {c["symbol"]: c for c in cards}
check("7 tokens (la compra de $1k se ignora)", set(by) == {"FLATCAT","PUMPER","SOLDOUT","LATE","SMALLPK","MINTABLE","NOGECKO"}, sorted(by))
check("FLATCAT → 🟢", by["FLATCAT"]["label"] == "ENTRY", by["FLATCAT"]["reasons"])
check("FLATCAT: 2 smart wallets convergen", by["FLATCAT"]["n_smart"] == 2, by["FLATCAT"]["n_smart"])
check("FLATCAT: pico ≈ $800k, caída ≈ 89%", 760e3 < by["FLATCAT"]["peak_mc"] < 850e3 and 0.85 < by["FLATCAT"]["drawdown_now"] < 0.92,
      (by["FLATCAT"]["peak_mc"], by["FLATCAT"]["drawdown_now"]))
check("FLATCAT: el trader sigue 100% dentro", abs(by["FLATCAT"]["trader_held_frac"] - 1.0) < 1e-6, by["FLATCAT"]["trader_held_frac"])
check("FLATCAT: compra del trader = $8k (SOL→USD)", abs(by["FLATCAT"]["trader_buy_usd"] - 8000) < 1, by["FLATCAT"]["trader_buy_usd"])
check("PUMPER → 🔴 (no es base)", by["PUMPER"]["label"] == "NO" and any("plano" in r for r in by["PUMPER"]["reasons"]), by["PUMPER"]["reasons"])
check("PUMPER: no muestra 'horas en base'", by["PUMPER"]["base_hours"] is None, by["PUMPER"]["base_hours"])
check("SOLDOUT → 🔴 (trader vendió 80%)", by["SOLDOUT"]["label"] == "NO" and abs(by["SOLDOUT"]["trader_held_frac"] - 0.2) < 1e-6,
      (by["SOLDOUT"]["label"], by["SOLDOUT"]["trader_held_frac"]))
check("LATE → 🟡 (+40% sobre el trader)", by["LATE"]["label"] == "WATCH" and 0.3 < by["LATE"]["premium"] < 0.6, (by["LATE"]["label"], by["LATE"]["premium"]))
check("SMALLPK → 🔴 (pico < $500k)", by["SMALLPK"]["label"] == "NO" and any("pico" in r for r in by["SMALLPK"]["reasons"]), by["SMALLPK"]["reasons"])
check("MINTABLE → 🔴 HARD", by["MINTABLE"]["label"] == "NO" and by["MINTABLE"]["reasons"][0].startswith("HARD"), by["MINTABLE"]["reasons"])
check("NOGECKO → ⚫", by["NOGECKO"]["label"] == "NODATA", by["NOGECKO"]["label"])
check("orden: 🟢 primero, ⚫ último", cards[0]["label"] == "ENTRY" and cards[-1]["label"] == "NODATA")

print("\n== point-in-time: el mismo radar 6 h antes")
w, series = d.build()
import numpy as np
cut = {m: v[:-6] for m, v in series.items()}
class G(d.FakeGecko):
    def ohlcv_hour(self, pool, mint, limit=1000):
        df = super().ohlcv_hour(pool, mint, limit); df["ts"] -= 6 * 3600; return df
cards2 = ms.run_radar(d.FakeRPC(w), G(cut), {"rules": dict(ms.DEFAULT_RULES)}, T=d.T_NOW - 6 * 3600, sol_usd=d.SOL_USD,
                      wallets=d.WALLETS, log=False, state_dir=tempfile.mkdtemp(), log_file=None)
syms = {c["symbol"] for c in cards2}
check("6 h antes no existen las compras posteriores (FLATCAT, PUMPER, LATE, SMALLPK)", not ({"FLATCAT","PUMPER","LATE","SMALLPK"} & syms), sorted(syms))

print("\n== verificación de wallets (add-wallet)")
R = dict(ms.DEFAULT_RULES)
st = ms.TxStore(tempfile.mkdtemp())
v1 = ms.verify_wallet(d.FakeRPC(w), st, d.W1, R, d.SOL_USD, log=False)
check("W1: PnL realizado = 25 × 400 SOL × $150 = $1.5M", abs(v1["verified_pnl_usd"] - 1_500_000) < 1_000, v1["verified_pnl_usd"])
check("W1: 25 cierres, 6 tokens, top 20% → CUMPLE", v1["closed_positions"] == 25 and v1["distinct_tokens"] == 6
      and abs(v1["top_token_share"] - 0.2) < 0.01 and v1["meets_criteria"], v1)
v3 = ms.verify_wallet(d.FakeRPC(w), st, d.W3, R, d.SOL_USD, log=False)
check("W3: pocas operaciones → NO cumple", not v3["meets_criteria"], v3)

print("\n== parseo de swaps: alquiler de cuenta y cierre")
t = ms.parse_wallet_trade(w.txs["demo000000"], d.W1, "demo000000")
check("compra con apertura de cuenta: 100 SOL exactos", t and t["side"] == "buy" and abs(t["sol"] - 100) < 1e-9, t)
t = ms.parse_wallet_trade(w.txs["demo000001"], d.W1, "demo000001")
check("venta con cierre de cuenta: 500 SOL exactos", t and t["side"] == "sell" and abs(t["sol"] - 500) < 1e-9, t)

print("\n== informe HTML")
p = ms.html_report(cards, T, Path(tempfile.mkdtemp()) / "r.html")
h = Path(p).read_text(encoding="utf-8")
check("HTML con las 7 tarjetas y enlaces", h.count('class="card ') == 7 and "dexscreener.com/solana/" in h)

print("\n== línea de comandos: add-wallet -> radar (red simulada)")
import os, io, contextlib
os.environ["MOONSHOT_NO_BROWSER"] = "1"
tmpd = Path(tempfile.mkdtemp())
ms.CONFIG_FILE, ms.WALLETS_FILE, ms.STATE_DIR, ms.HERE = tmpd / "cfg.json", tmpd / "w.csv", tmpd / ".st", tmpd
ms.CONFIG_FILE.write_text('{"rpc_url": "http://fake", "sol_usd": 150}')
w2, series2 = d.build()
ms.tf.RPC = lambda url, min_interval=0.1: d.FakeRPC(w2)
ms.Gecko = lambda *a, **k: d.FakeGecko(series2)
real_time = ms.time.time
ms.time.time = lambda: d.T_NOW
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    ms.main(["add-wallet", d.W1, "Top1"])
    ms.main(["add-wallet", d.W3, "Mid"])
    ms.main(["add-wallet", d.W2, "Whale", "--force"])
out = buf.getvalue()
wl = ms.load_wallets()
check("add-wallet: W1 añadida (cumple), W3 rechazada, W2 forzada", [x["label"] for x in wl] == ["Top1", "Whale"], [x["label"] for x in wl])
check("add-wallet explica por qué rechaza", "NO cumple tus criterios" in out)
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    ms.main(["radar"])
out = buf.getvalue()
check("radar: FLATCAT 🟢 con las wallets de la lista", "🟢 ZONA DE ENTRADA  $FLATCAT" in out, out[:400])
check("radar: SOLDOUT no aparece (su trader, W3, no está en la lista)", "SOLDOUT" not in out)
check("radar escribe informe y registro", (tmpd / "moonshot_report.html").exists() and (tmpd / "radar_log.jsonl").exists())
ms.time.time = real_time

print(f"\n{'TODO OK' if not FAILS else f'{len(FAILS)} FALLOS: {FAILS}'}")
sys.exit(1 if FAILS else 0)

#!/usr/bin/env python3
"""Simula una ejecución de GitHub Actions con la red simulada (sin internet).
Ejecutar en una COPIA de la carpeta:  python test_github_flow.py"""
import contextlib
import io
import json
import os
import sys

sys.path.insert(0, ".")
os.environ.update({"GITHUB_ACTIONS": "true", "CI": "true", "SOLANA_RPC": "https://fake", "MOONSHOT_NO_BROWSER": "1"})
import moonshot as ms  # noqa: E402
import moonshot_demo as d  # noqa: E402
import scan  # noqa: E402

w, series = d.build()
ms.tf.RPC = lambda url, min_interval=0.1: d.FakeRPC(w)
ms.Gecko = lambda *a, **k: d.FakeGecko(series)
scan.sol_price = lambda x: (d.SOL_USD, "fake")
ms.time.time = lambda: d.T_NOW
FAILS = []


def check(n, c, g=None):
    print(f"  [{'PASS' if c else 'FAIL'}] {n}" + ("" if c else f"  ({g})"))
    if not c:
        FAILS.append(n)


check("lista de wallets vacía al empezar (sin datos de pruebas)", ms.load_wallets() == [], ms.load_wallets())
with open("wallets_to_add.txt", "a", encoding="utf-8") as fh:
    fh.write(f"{d.W1},Solstice\n{d.W3},Mid\n{d.W2},Whale,force\n")
with contextlib.redirect_stdout(io.StringIO()):
    ms.main(["add-wallets-file", "wallets_to_add.txt"])
wl = ms.load_wallets()
check("W1 añadida, W3 rechazada, W2 forzada", [x["label"] for x in wl] == ["Solstice", "Whale"], [x["label"] for x in wl])
check("wallets_to_add.txt queda vacío", all(l.startswith("#") for l in open("wallets_to_add.txt", encoding="utf-8").read().splitlines() if l.strip()))
wc = open("report/wallet_checks.md", encoding="utf-8").read()
check("informe de verificación con resultado de cada una", "❌ no cumple" in wc and "✅ añadida" in wc and "(forzada)" in wc, wc)
with contextlib.redirect_stdout(io.StringIO()):
    ms.main(["radar", "--publish", "report"])
rep = json.load(open("report/report.json", encoding="utf-8"))
check("report.json: FLATCAT 🟢 arriba", rep["cards"][0]["symbol"] == "FLATCAT" and rep["cards"][0]["label"] == "ENTRY", rep["cards"][0].get("symbol"))
check("report.json: 2 wallets vigiladas", rep["n_wallets"] == 2, rep["n_wallets"])
md = open("report/SCAN.md", encoding="utf-8").read()
check("SCAN.md con tablas", "## 🟢 ZONA DE ENTRADA · $FLATCAT" in md and "| MC ahora |" in md)
check("index.html generado", os.path.exists("report/index.html"))
check("radar_log.jsonl (una línea por señal)", len(open("radar_log.jsonl").read().splitlines()) == len(rep["cards"]))
n_cache = sum(1 for _ in open(".moonshot/tx_cache.jsonl"))
check("caché podada (sin el historial de 30 días)", 0 < n_cache < 20, n_cache)
os.environ.pop("SOLANA_RPC")
ms.CONFIG_FILE.write_text('{"rpc_url": null, "rules": {}}')
try:
    ms.load_config()
    check("sin secreto SOLANA_RPC: error claro", False)
except SystemExit as e:
    check("sin secreto SOLANA_RPC: error claro", "SOLANA_RPC" in str(e), str(e))
print("TODO OK" if not FAILS else f"{len(FAILS)} FALLOS: {FAILS}")
sys.exit(1 if FAILS else 0)

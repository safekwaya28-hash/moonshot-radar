#!/bin/bash
# Doble clic (Mac): instala lo necesario (solo la primera vez tarda) y ejecuta el radar.
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "Necesitas Python 3: https://www.python.org/downloads/"; read -p "Enter para cerrar"; exit 1; }
python3 -m pip install -q -r requirements.txt 2>/dev/null || python3 -m pip install -q --user -r requirements.txt
python3 moonshot.py "$@"
echo
read -p "Pulsa Enter para cerrar"

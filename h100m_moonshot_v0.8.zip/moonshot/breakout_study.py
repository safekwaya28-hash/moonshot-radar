#!/usr/bin/env python3
from __future__ import annotations

"""H-100M Breakout/Base Study v0.2.

Five cumulative point-in-time levels:
  N0 base plana
  N1 + suelo estable
  N2 + volumen reactivándose
  N3 + holders/compradores acelerando
  N4 + ruptura del ATH

Important: thresholds are explicit configuration. The example values shipped with this file
are a CANDIDATE preregistration and must be frozen before a real corpus run.
"""
import argparse, json, math
from collections import Counter, deque
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

DEFAULT_CONFIG={
 "preregistration_id":"breakout_v0.2_candidate",
 "base":{"min_drawdown":0.80,"min_duration_hours":24.0,"flat_band_pct":0.50,"min_points":6},
 "floor":{"stable_window_hours":12.0,"max_range_pct":0.20,"min_points":6},
 "reactivation":{"window_hours":6.0,"volume_ratio":2.0,"min_volume":0.0},
 "acceleration":{"window_hours":6.0,"holder_slope_ratio":1.50,"buyer_rate_ratio":1.50,"min_buyers_recent":2},
 "breakout":{"epsilon":0.0},
 "outcomes":{"horizons_hours":[24.0,168.0],"targets":[2.0,10.0],"failed_breakout_drawdown":0.50,"failure_requires_no_2x":True},
 "data":{"timestamp_unit":"auto","resample":"1min","min_points":6},
}
ALIASES={
 "mint":["mint","token","token_address","token_mint","address"],
 "ts":["ts","timestamp","time","block_time","created_at","datetime"],
 "mc_usd":["mc_usd","market_cap","marketcap","usd_market_cap","mcap"],
 "holders":["holders","holder_count","holders_count"],
 "wallet":["wallet","trader","signer"],
 "side":["side","direction","type"],
 "quote_amount":["quote_amount","sol_amount","usd_amount","quote_amount_raw"],
 "token_amount":["token_amount","amount","token_amount_raw"],
 "price_usd":["price_usd","usd_price"],
}
BUY={"buy","b","bid","1"}

def read_table(path:str)->pd.DataFrame:
 p=Path(path)
 if p.suffix.lower()=='.csv': return pd.read_csv(p)
 if p.suffix.lower()=='.jsonl': return pd.read_json(p,lines=True)
 if p.suffix.lower()=='.json': return pd.read_json(p)
 if p.suffix.lower() in {'.parquet','.pq'}: return pd.read_parquet(p)
 raise ValueError(f"Formato no soportado: {p}")

def rename_aliases(df:pd.DataFrame, required:list[str], name:str)->pd.DataFrame:
 out=df.copy(); cols=set(map(str,out.columns)); ren={}
 for canon,names in ALIASES.items():
  if canon not in out.columns:
   found=next((n for n in names if n in cols),None)
   if found: ren[found]=canon
 out=out.rename(columns=ren)
 miss=[c for c in required if c not in out.columns]
 if miss: raise ValueError(f"{name}: faltan {miss}; disponibles={list(out.columns)}")
 return out

def parse_ts(s:pd.Series, unit:str)->pd.Series:
 if pd.api.types.is_datetime64_any_dtype(s): return pd.to_datetime(s,utc=True)
 if pd.api.types.is_numeric_dtype(s):
  v=pd.to_numeric(s,errors='coerce')
  use='ms' if unit=='ms' or (unit=='auto' and not v.dropna().empty and float(v.dropna().median())>1e11) else 's'
  return pd.to_datetime(v,unit=use,utc=True)
 return pd.to_datetime(s,utc=True,errors='coerce')

def load_snapshots(path,cfg):
 x=rename_aliases(read_table(path),['mint','ts','mc_usd'],'snapshots')
 x['ts']=parse_ts(x.ts,cfg['data']['timestamp_unit'])
 for c in ['mc_usd','holders']: 
  if c in x.columns: x[c]=pd.to_numeric(x[c],errors='coerce')
 x=x.dropna(subset=['mint','ts','mc_usd']); x=x[x.mc_usd>0].copy()
 return x.sort_values(['mint','ts']).drop_duplicates(['mint','ts'],keep='last')

def load_trades(path,cfg):
 if not path: return None
 x=rename_aliases(read_table(path),['mint','ts'],'trades')
 x['ts']=parse_ts(x.ts,cfg['data']['timestamp_unit'])
 if 'side' in x: x.side=x.side.astype(str).str.lower()
 if 'wallet' in x: x.wallet=x.wallet.astype(str)
 for c in ['quote_amount','token_amount','price_usd']: 
  if c in x: x[c]=pd.to_numeric(x[c],errors='coerce')
 return x.dropna(subset=['mint','ts']).sort_values(['mint','ts'])

def resample_token(raw,freq):
 x=raw.set_index('ts').sort_index()
 agg={'mc_usd':'last'}
 if 'holders' in x: agg['holders']='last'
 y=x.resample(freq).agg(agg)
 y.mc_usd=y.mc_usd.ffill()
 if 'holders' in y: y.holders=y.holders.ffill()
 return y.dropna(subset=['mc_usd']).reset_index()

def trade_value(df):
 if 'price_usd' in df.columns and 'token_amount' in df.columns:
  v=df.price_usd.abs()*df.token_amount.abs()
  if v.notna().any(): return v.fillna(0.0).to_numpy(float)
 if 'quote_amount' in df.columns: return df.quote_amount.fillna(0.0).abs().to_numpy(float)
 return np.zeros(len(df),dtype=float)

def precompute_trade_windows(trades,mint,times,w_hours):
 """Recent/previous volume and exact unique buyers for adjacent windows. O(N+T)."""
 z=trades[trades.mint.astype(str)==str(mint)] if trades is not None else pd.DataFrame()
 n=len(times)
 if z.empty:
  return np.zeros(n),np.zeros(n),np.zeros(n,dtype=int),np.zeros(n,dtype=int)
 z=z.sort_values('ts').copy(); z['_v']=trade_value(z)
 wt=pd.Timedelta(hours=w_hours)
 tt=times.to_numpy(dtype='datetime64[ns]'); tz=z.ts.to_numpy(dtype='datetime64[ns]')
 vals=z['_v'].to_numpy(float)
 buyers=z.wallet.to_numpy(str) if 'wallet' in z.columns else np.arange(len(z)).astype(str)
 pref=np.concatenate([[0.0],np.cumsum(vals)])
 vol_r=np.zeros(n); vol_p=np.zeros(n); ub_r=np.zeros(n,dtype=int); ub_p=np.zeros(n,dtype=int)
 cr,cp=Counter(),Counter(); lr,rr,lp,rp=0,0,0,0
 for i,t in enumerate(tt):
  cut1=t-np.timedelta64(int(w_hours*3600),'s'); cut2=t-np.timedelta64(int(2*w_hours*3600),'s')
  hr=int(np.searchsorted(tz,t,side='right'))
  rlow=int(np.searchsorted(tz,cut1,side='right'))
  phigh=rlow
  plow=int(np.searchsorted(tz,cut2,side='right'))
  while rr<hr:
   cr[buyers[rr]]+=1; rr+=1
  while lr<rlow:
   bb=buyers[lr]; cr[bb]-=1
   if cr[bb]==0: del cr[bb]
   lr+=1
  while rp<phigh:
   cp[buyers[rp]]+=1; rp+=1
  while lp<plow:
   bb=buyers[lp]; cp[bb]-=1
   if cp[bb]==0: del cp[bb]
   lp+=1
  vol_r[i]=pref[hr]-pref[rlow]
  vol_p[i]=pref[phigh]-pref[plow]
  ub_r[i]=len(cr); ub_p[i]=len(cp)
 return vol_r,vol_p,ub_r,ub_p

def rolling_slope_fixed(y,window):
 """Slope on regular 1-step grid for every endpoint, using rolling sums."""
 a=np.asarray(y,dtype=float); n=len(a); out=np.full(n,np.nan)
 if window<2 or n<window: return out
 x=np.arange(n,dtype=float)
 sx=pd.Series(x); sy=pd.Series(a); sxy=pd.Series(x*a); sx2=pd.Series(x*x)
 Sx=sx.rolling(window).sum().to_numpy(); Sy=sy.rolling(window).sum().to_numpy(); Sxy=sxy.rolling(window).sum().to_numpy(); Sx2=sx2.rolling(window).sum().to_numpy()
 den=window*Sx2-Sx*Sx; good=den!=0
 out[good]=(window*Sxy[good]-Sx[good]*Sy[good])/den[good]
 return out

def find_n0(s,cfg):
 b=cfg['base']; mc=s.mc_usd.to_numpy(float); times=s.ts
 prior_ath=np.maximum.accumulate(np.r_[mc[0],mc[:-1]])
 dd=1-mc/prior_ath
 w=pd.Series(mc,index=times)
 roll_min=w.rolling(f"{b['min_duration_hours']}h",min_periods=b['min_points']).min()
 roll_max=w.rolling(f"{b['min_duration_hours']}h",min_periods=b['min_points']).max()
 ok=((roll_max/roll_min-1)<=b['flat_band_pct']).to_numpy().copy()  # copia: pandas puede devolver array de solo lectura
 ok &= (dd>=b['min_drawdown'])
 dur_ok=(times-times.iloc[0]).dt.total_seconds()/3600>=b['min_duration_hours']
 ok &= dur_ok.to_numpy()
 idx=np.where(ok)[0]
 if len(idx)==0: return None
 j=int(idx[0])
 # Use actual window represented by the last min_duration window.
 t0=times.iloc[j]-pd.Timedelta(hours=b['min_duration_hours'])
 win=s[(times>=t0)&(times<=times.iloc[j])]
 ath_i=int(np.argmax(mc[:j+1]))
 low=float(win.mc_usd.min()) if len(win) else float(mc[j])
 return {'mint':str(s.mint.iloc[0]),'n0_index':j,'n0_time':times.iloc[j],
         'ath_before_base_usd':float(mc[ath_i]),'ath_before_base_time':times.iloc[ath_i],
         'base_low_usd':low,'base_max_drawdown':float(1-low/mc[ath_i]),
         'base_duration_hours':float(b['min_duration_hours']),'base_points':int(len(win))}

def add_levels(e,s,trades,cfg):
 o=dict(e); x=s.reset_index(drop=True); times=x.ts; mc=x.mc_usd.to_numpy(float)
 for k in ['n1_time','n2_time','n3_time','n4_time']: o[k]=None
 n0=int(e['n0_index'])
 # N1 stable floor: rolling 12h range <= threshold, evaluated only after N0.
 fw=cfg['floor']; w=f"{fw['stable_window_hours']}h"; ser=pd.Series(mc,index=times)
 rmin=ser.rolling(w,min_periods=fw['min_points']).min(); rmax=ser.rolling(w,min_periods=fw['min_points']).max()
 cond=((rmax/rmin-1)<=fw['max_range_pct']).fillna(False).to_numpy().copy(); cond[:n0]=False
 ii=np.where(cond)[0]
 if len(ii): o['n1_time']=times.iloc[int(ii[0])]
 # N2 volume reactivation.
 start_idx=n0 if o['n1_time'] is None else int(x.index[x.ts==o['n1_time']][0])
 if o['n1_time'] is not None:
  wh=cfg['reactivation']['window_hours']; vr,vp,_,_=precompute_trade_windows(trades,str(e['mint']),times,wh)
  ratio=np.divide(vr,vp,out=np.full(len(vr),np.nan),where=vp>0)
  c=((vr>=cfg['reactivation']['min_volume']) & ((vp==0)&(vr>0) | (ratio>=cfg['reactivation']['volume_ratio']))); c[:start_idx]=False
  ii=np.where(c)[0]
  if len(ii):
   i=int(ii[0]); o['n2_time']=times.iloc[i]; o['n2_volume_recent']=float(vr[i]); o['n2_volume_prev']=float(vp[i]); o['n2_volume_ratio']=float(ratio[i]) if np.isfinite(ratio[i]) else None
 # N3 holders + buyers accelerate together.
 if o['n2_time'] is not None and 'holders' in x:
  w_h=cfg['acceleration']['window_hours']; ws=max(2,int(round(w_h*60)))
  sr=rolling_slope_fixed(x.holders.to_numpy(float),ws); prev_shift=np.r_[np.full(ws,np.nan),sr[:-ws]]
  vr,vp,ubr,ubp=precompute_trade_windows(trades,str(e['mint']),times,w_h)
  br=np.divide(ubr,ubp,out=np.full(len(ubr),np.nan),where=ubp>0)
  holder_ok=(sr>0)&((prev_shift<=0)| (sr>=prev_shift*cfg['acceleration']['holder_slope_ratio']))
  buyer_ok=(ubr>=cfg['acceleration']['min_buyers_recent']) & (np.isinf(br) | (br>=cfg['acceleration']['buyer_rate_ratio']))
  c=holder_ok & buyer_ok
  st=int(x.index[x.ts==o['n2_time']][0]); c[:st]=False
  ii=np.where(c)[0]
  if len(ii):
   i=int(ii[0]); o['n3_time']=times.iloc[i]; o['n3_holder_slope_recent']=float(sr[i]); o['n3_holder_slope_prev']=float(prev_shift[i]) if np.isfinite(prev_shift[i]) else None; o['n3_buyer_rate_ratio']=float(br[i]) if np.isfinite(br[i]) else None
 # N4 exact point-in-time ATH breakout.
 start_t=pd.Timestamp(o['n3_time'] or o['n2_time'] or o['n1_time'] or o['n0_time'])
 st=int(x.index[x.ts==start_t][0])
 if st+1<len(x):
  prior=np.maximum.accumulate(np.r_[mc[0],mc[:-1]])
  c=(mc>prior*(1+cfg['breakout']['epsilon'])); c[:st]=False
  ii=np.where(c)[0]
  if len(ii):
   i=int(ii[0]); hi=int(np.argmax(mc[:i])); H=float(mc[hi]); o['n4_time']=times.iloc[i]; o['breakout_mc_usd']=float(mc[i]); o['breakout_ath_usd']=H; o['breakout_ath_time']=times.iloc[hi]; o['breakout_multiple_over_ath']=float(mc[i]/H)
 return o

def outcomes(s,t,mc,cfg, failure_level=None, failure_only=False):
 if mc<=0: return {}
 ts=s.ts.to_numpy(dtype='datetime64[ns]'); vals=s.mc_usd.to_numpy(float)
 tpd=pd.Timestamp(t)
 if tpd.tzinfo is not None: tpd=tpd.tz_convert('UTC').tz_localize(None)
 tt=np.datetime64(tpd)
 out={}
 pos=int(np.searchsorted(ts,tt,side='right'))
 for h in cfg['outcomes']['horizons_hours']:
  end=tt+np.timedelta64(int(h*3600),'s'); j=int(np.searchsorted(ts,end,side='right'))
  out[f"mfe_{int(h)}h"]=float(vals[pos:j].max()/mc) if j>pos else np.nan
 for target in cfg['outcomes']['targets']:
  hit=np.where(vals[pos:]>=mc*target)[0]
  if len(hit): out[f"time_to_{target:g}x_hours"]=float((ts[pos+int(hit[0])]-tt)/np.timedelta64(1,'h'))
  else: out[f"time_to_{target:g}x_hours"]=np.nan
 if failure_only:
  H=float(failure_level if failure_level is not None else mc)
  t2=np.where(vals[pos:]>=mc*2)[0]
  lim=pos+int(t2[0]) if len(t2) else len(vals)
  # Failed breakout: price reaches <=50% of the pre-breakout ATH before 2x.
  out['failed_breakout']=bool(np.any(vals[pos:lim] <= H*(1-cfg['outcomes']['failed_breakout_drawdown'])) and not len(t2))
 else:
  out['failed_breakout']=np.nan
 return out

def level_rows(e,s,cfg):
 out=[]
 for n in range(5):
  t=e.get(f'n{n}_time')
  if t is None: continue
  t=pd.Timestamp(t); same=s[s.ts==t]
  if same.empty: continue
  mc=float(same.mc_usd.iloc[-1])
  r={'mint':e['mint'],'event_id':f"{e['mint']}|{t.isoformat()}",'level':f'N{n}','signal_time':t,'signal_mc_usd':mc,'base_max_drawdown':e['base_max_drawdown'],'base_duration_hours':e['base_duration_hours'],'base_low_usd':e['base_low_usd']}
  failure_only=(n==4)
  failure_level=e.get('breakout_ath_usd') if failure_only else None
  r.update(outcomes(s,t,mc,cfg,failure_level=failure_level,failure_only=failure_only))
  out.append(r)
 return out

def wilson(k,n,z=1.959963984540054):
 if n==0:return (np.nan,np.nan)
 p=k/n; den=1+z*z/n; cen=(p+z*z/(2*n))/den; half=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
 return cen-half,cen+half

def summary(ldf):
 if ldf.empty:return pd.DataFrame()
 rows=[]
 for level,g in ldf.groupby('level',sort=True):
  p2=float(g['time_to_2x_hours'].notna().mean()); p10=float(g['time_to_10x_hours'].notna().mean())
  lo2,hi2=wilson(int(g['time_to_2x_hours'].notna().sum()),len(g)); lo10,hi10=wilson(int(g['time_to_10x_hours'].notna().sum()),len(g))
  rows.append({'level':level,'N':len(g),'P_ge_2x':p2,'P_ge_2x_CI95_low':lo2,'P_ge_2x_CI95_high':hi2,'P_ge_10x':p10,'P_ge_10x_CI95_low':lo10,'P_ge_10x_CI95_high':hi10,'median_MFE_24h':float(g.mfe_24h.median()) if 'mfe_24h' in g and g.mfe_24h.notna().any() else np.nan,'median_MFE_168h':float(g.mfe_168h.median()) if 'mfe_168h' in g and g.mfe_168h.notna().any() else np.nan,'mean_MFE_168h':float(g.mfe_168h.mean()) if 'mfe_168h' in g and g.mfe_168h.notna().any() else np.nan,'failed_breakout_rate':float(g.failed_breakout.mean()) if level=='N4' else np.nan})
 return pd.DataFrame(rows)

def buckets(df,col,cuts,labels):
 if df.empty or col not in df:return pd.DataFrame()
 x=df.copy(); x['bucket']=pd.cut(x[col],cuts,labels=labels,include_lowest=True,right=False); rows=[]
 for b,g in x.groupby('bucket',observed=False):
  r={'bucket':str(b),'N':len(g),'P_ge_2x':float(g['time_to_2x_hours'].notna().mean()) if 'time_to_2x_hours' in g else np.nan,'P_ge_10x':float(g['time_to_10x_hours'].notna().mean()) if 'time_to_10x_hours' in g else np.nan}
  for c in [c for c in g.columns if c.startswith('mfe_')]: r[f'median_{c}']=float(g[c].median()) if len(g) and g[c].notna().any() else np.nan
  rows.append(r)
 return pd.DataFrame(rows)

def leakage_audit(levels,raw):
 bad=[]
 if not levels.empty:
  for _,r in levels.iterrows():
   same=raw[(raw.mint.astype(str)==str(r.mint))&(raw.ts==pd.Timestamp(r.signal_time))]
   if len(same) and not np.isclose(float(r.signal_mc_usd),float(same.mc_usd.iloc[-1])): bad.append(f"{r.event_id} signal MC mismatch")
 return {'status':'PASS' if not bad else 'FAIL','n_violations':len(bad),'violations':bad[:100]}

def write_parquet_or_csv(df,path):
 try: df.to_parquet(path,index=False); return str(path)
 except Exception:
  p=path.with_suffix('.csv'); df.to_csv(p,index=False); return str(p)

def baseline_drawdown(snapshots,cfg):
 """Baseline: all tokens that first reach the preregistered drawdown X, without requiring a flat base."""
 rows=[]
 thr=cfg['base']['min_drawdown']
 for mint,g in snapshots.groupby(snapshots.mint.astype(str),sort=False):
  s=g.sort_values('ts').reset_index(drop=True)
  if len(s)<2: continue
  mc=s.mc_usd.to_numpy(float); ath=np.maximum.accumulate(np.r_[mc[0],mc[:-1]]); dd=1-mc/ath
  hit=np.where(dd>=thr)[0]
  if len(hit)==0: continue
  i=int(hit[0]); t=s.ts.iloc[i]; H=float(ath[i]); out={'mint':str(mint),'signal_time':t,'signal_mc_usd':float(mc[i]),'drawdown':float(dd[i])}
  o=outcomes(s,t,float(mc[i]),cfg); out.update(o); rows.append(out)
 return pd.DataFrame(rows)

def run(snapshots,trades,outdir,cfg):
 out=Path(outdir); out.mkdir(parents=True,exist_ok=True)
 snaps=load_snapshots(snapshots,cfg); tr=load_trades(trades,cfg)
 events=[]; levels=[]
 for mint,raw in snaps.groupby(snaps.mint.astype(str),sort=False):
  s=resample_token(raw,cfg['data']['resample']); s['mint']=str(mint)
  if len(s)<cfg['data']['min_points']: continue
  e=find_n0(s,cfg)
  if e is None: continue
  e=add_levels(e,s,tr,cfg); events.append(e); levels.extend(level_rows(e,s,cfg))
 edf=pd.DataFrame(events); ldf=pd.DataFrame(levels)
 if not ldf.empty: ldf['signal_time']=pd.to_datetime(ldf.signal_time,utc=True)
 n4=ldf[ldf.level=='N4'].copy() if not ldf.empty else ldf
 summ=summary(ldf)
 base_df=baseline_drawdown(snaps,cfg)
 base_for_summary=base_df.copy()
 if not base_for_summary.empty: base_for_summary['level']='DRAWDDOWN_BASELINE'
 base_summ=summary(base_for_summary)
 if not base_summ.empty: base_summ.insert(0,'cohort','DRAWDDOWN_BASELINE')
 bydd=buckets(n4,'base_max_drawdown',[0,0.80,0.90,0.95,1.01],['<80%','80-90%','90-95%','≥95%'])
 bydur=buckets(n4,'base_duration_hours',[0,24,72,168,float('inf')],['<1d','1-3d','3-7d','≥7d'])
 fail=n4[n4.failed_breakout.astype('boolean').fillna(False)].copy() if not n4.empty else pd.DataFrame()
 meta={'version':'breakout_study_v0.2','config':cfg,'n_tokens_seen':int(snaps.mint.nunique()),'n_base_events':len(edf),'n_level_rows':len(ldf),'n_n4':len(n4),'n_drawdown_baseline':len(base_df),'leakage_audit':leakage_audit(ldf,snaps),'preregistration_note':'candidate thresholds must be frozen before real-corpus inference'}
 write_parquet_or_csv(edf,out/'breakout_events.parquet'); write_parquet_or_csv(ldf,out/'breakout_levels.parquet')
 summ.to_csv(out/'breakout_summary.csv',index=False); base_df.to_csv(out/'breakout_drawdown_baseline.csv',index=False); base_summ.to_csv(out/'breakout_baseline_summary.csv',index=False); bydd.to_csv(out/'breakout_by_drawdown.csv',index=False); bydur.to_csv(out/'breakout_by_duration.csv',index=False); fail.to_csv(out/'breakout_failures.csv',index=False)
 with open(out/'study_metadata.json','w',encoding='utf-8') as f: json.dump(meta,f,indent=2,default=str)
 return meta

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--snapshots',required=True); ap.add_argument('--trades'); ap.add_argument('--config'); ap.add_argument('--out',required=True); a=ap.parse_args()
 cfg=json.loads(json.dumps(DEFAULT_CONFIG))
 if a.config:
  u=json.load(open(a.config,encoding='utf-8'))
  for k,v in u.items(): cfg[k]={**cfg[k],**v} if isinstance(v,dict) and isinstance(cfg.get(k),dict) else v
 print(json.dumps(run(a.snapshots,a.trades,a.out,cfg),indent=2,default=str))
if __name__=='__main__': main()

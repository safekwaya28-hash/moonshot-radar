# MOONSHOT · radar + laboratorio (v0.7)

**Para usar el radar lee `LEEME_PRIMERO.txt`.** Doble clic en `MOONSHOT.bat` (Windows) o `MOONSHOT.command` (Mac).

## v0.7 · qué cambia respecto a v0.6

**Nuevo: `moonshot.py` (radar de un clic)**
- Tu estrategia: top trader verificado compra un token con pico ≥ $500k, caída ≥ 70% y 72 h plano → 🟢 si puedes entrar a ≤ +30% de su precio y él sigue dentro.
- Datos: RPC propio para ver qué compran tus wallets y si siguen dentro (`getTokenAccountsByOwner`); GeckoTerminal (pública) para el historial horario de precio y MC.
- `add-wallet`: verifica el PnL realizado de la wallet en sus últimas 3.000 tx y solo la añade si cumple tus criterios.
- Informe HTML (móvil y escritorio) + `radar_log.jsonl` con cada señal, para validar las reglas después.
- `demo`: informe de ejemplo sin internet.
- Tests (`test_moonshot.py`, 25 checks): 7 casos de verdad conocida, sin mirar el futuro (point-in-time), PnL exacto de wallets, SOL exacto con apertura y cierre de cuentas, y el flujo `add-wallet → radar` por línea de comandos.

**Corregido: `smart_money_study.py` v0.2 → v0.3** (los tests de v0.2 pasaban sin detectar estos fallos):
1. La posición del trader sumaba todos los wallets del token (600.133 frente a 133): la salida por "vende el trader" no podía activarse nunca.
2. El "volumen histórico ≥ $500k" era el volumen de las **últimas 24 h**, así que rechazaba justo las bases dormidas. Ahora es el máximo histórico de la ventana móvil.
3. En su propio test la señal nunca generaba una entrada (`NO_ENTRY_NOT_FLAT`), y el resumen solo tenía el grupo de control.
4. Los controles se medían con buy & hold y las señales con reglas de salida. Ahora ambos usan las mismas reglas, se resumen por retraso y la diferencia lleva IC bootstrap.
5. Una señal por episodio de base, no por token. Además, un prefiltro de coste (tokens con pico ≥ $500k).
Los tests nuevos **fallan** con v0.2 y pasan con v0.3.

**Corregido: `breakout_study.py`**: se rompía con "read-only array" en pandas reciente, y su test buscaba un CSV cuando se escribía parquet.

---

# H-100M · Fase 0.2 (auditoría) + Fase 0.3 (experimento natural del 12-sep)

Dos niveles:

- **Nivel A — `phase0_audit.py`:** ¿permite el corpus estudiar honestamente $1M → $10M → $50M → $100M? Ahora con **MC multi-par** (SOL, stablecoins, acciones tokenizadas).
- **Nivel B — `natural_experiment.py`:** ¿cambian Holder Rewards (vs Creator Fee) y el par RWA (vs SOL) la probabilidad de llegar a $1M, comparando tokens lanzados el mismo día? Ejecuta el Nivel A internamente.

Sin ML. Sin rankings de mecanismos. Sin seleccionar ganadores.

## Ficheros

| Fichero | Qué es |
|---|---|
| `phase0_audit.py` | Auditoría Fase 0.2, ahora consciente del activo del par (v0.3) |
| `natural_experiment.py` | Motor del experimento natural (Fase 0.3) |
| `config.example.json` | Plantilla: mapeo de tu esquema, catálogo de pares, fee modes y parámetros pre-registrados |
| `make_synthetic.py` / `test_phase0.py` | 30 checks de la auditoría |
| `make_synthetic_ne.py` / `test_ne.py` | 20 checks del experimento con efecto y autoselección plantados |

## Uso

```bash
pip install duckdb pyarrow pandas numpy
python phase0_audit.py --introspect --config mi_config.json       # ver columnas; ajustar mapeo
python natural_experiment.py --config mi_config.json --out ne_out --memory-limit 12GB
```

**Datos que necesita el Nivel B** (además de los del Nivel A):
- `tokens.quote_asset`: activo del par, en símbolo o mint (los mints se traducen con `quote.aliases`).
- `tokens.fee_mode`: creator fee / holder rewards / cashback, mapeado con `fee_mode_values`.
- `quote_prices`: serie en USD de cada activo de par que no sea SOL (NVDAX, TSLAX…).
- `pair_catalog`: tipo de cada activo (SOL / STABLE / RWA / CRYPTO). **Debe salir del catálogo histórico del proveedor.** Un activo sin catalogar queda `UNCLASSIFIED` y fuera de los contrastes RWA.

## Salidas (`ne_out/`)

| Fichero | Contenido |
|---|---|
| `natural_experiment.txt` | El informe humano (formato "MOONSHOT NATURAL EXPERIMENT") |
| `natural_experiment.json` | Todo: auditoría A–H, 4 grupos, hipótesis, event study, placebos, robustez, multiplicidad, veredictos, config usada |
| `natural_experiment.csv` | Una fila por contraste |
| `cohort_summary.csv` | Régimen × par × fee: N, graduados, 100k, 1M raw/validado, tasas con IC, medianas de tiempos |
| `event_study.csv` / `placebo_results.csv` | Tasa diaria relativa al corte / cortes falsos |
| `robustness.csv` | Variantes de H_FEE |
| `daily_coexistence.csv` | Cuántos tokens de cada grupo conviven cada día |
| `ne_tokens.parquet` | La unidad de análisis: un token con su estado al crear y sus outcomes |
| `phase0_report.json/.md` | Auditoría del Nivel A |

## Diseño pre-registrado (y en qué se aparta de la propuesta)

| Decisión | Por qué |
|---|---|
| **Outcome primario:** cruce *validado* de $1M ≤ 168 h desde la **creación**, sobre todos los lanzamientos elegibles | "P(1M \| graduado)" condiciona a una variable que el propio tratamiento puede cambiar (HR puede alterar la graduación). Se reporta aparte como descomposición: P(graduar) y P(1M \| graduado). |
| **Covariables de propensión:** solo del momento de creación (hora, día, dev buy, historial del creador *anterior*, socials, lanzamientos en las 24 h previas, retorno SOL 24 h) | Volumen, holders o "primeras operaciones" son **post-tratamiento**: si HR atrae compradores tempranos, ajustar por ellos borra el efecto. Quedan listadas en `covariates_rejected_post_treatment`. |
| **Elegibilidad:** precio del par disponible (ASOF, ≤ 2 h), fee conocido, Q ≥ 0,9, graduado con datos post, **seguimiento completo de 168 h** | Sin seguimiento completo, un negativo no es un negativo. |
| **Estimador principal:** Mantel-Haenszel estratificado por día × (par o fee) + **permutación exacta condicional** (hipergeométricas por estrato) | Compara solo tokens del mismo día; exacto con eventos raros; sin supuestos asintóticos. |
| **Ajuste:** IPTW (logística ridge, efectos fijos de día), IC bootstrap estratificado, balance SMD antes/después, ESS y solapamiento | Corrige la autoselección observable. El tratamiento nunca entra como covariable (hay una salvaguarda). |
| **Interacción:** OR_HR\|RWA / OR_HR\|SOL con permutación | Exige potencia en *ambas* subpoblaciones. |
| **Event study** ±1/3/7/14 d + **placebos** (cortes falsos con ventana entera en PRE) | Mide el cambio de *plataforma*, no el efecto del fee. Pasa si el corte real destaca sobre ≥19 placebos. |
| **Multiplicidad:** H_FEE primaria sin corrección; H_RWA, H_INT y placebo con Benjamini-Hochberg; robustez solo exploratoria | Registrado en `multiplicity`. |

### Veredicto de cada hipótesis

- **INSUFFICIENT_DATA** si la Fase 0.2 da DATA_FAIL o la post-migración no es usable, o si la potencia es insuficiente: <20 eventos, <5 por brazo u OR mínimo detectable >2.
- **SIGNAL** si se cumple todo lo siguiente:
  - p < α;
  - IC de MH sin el 1;
  - IC de IPTW sin el 1 y en el mismo sentido;
  - SMD tras IPTW ≤ 0,1;
  - robustez superada (solo para la primaria). Robustez significa: mismo signo en todas las variantes con suficientes eventos, ningún régimen SOL con efecto opuesto significativo, y sigue siendo significativo sin el top-5 de ganadores.
- **NO_SIGNAL** en cualquier otro caso.

## Validación (datos sintéticos con verdad conocida)

`test_ne.py` genera ~70k lanzamientos con MC real en SOL, USDC, NVDAX y TSLAX. Planta **autoselección**: los creadores hábiles eligen HR más a menudo y también tienen más éxito.

| Escenario | Resultado esperado y obtenido |
|---|---|
| Efecto real de HR (OR marginal verdadero 1,80) | Ingenuo **4,80** (sesgado) → IPTW **1,96 [1,61–2,43]** · SMD 0,78 → 0,004 · **SIGNAL**. RWA e interacción: NO_SIGNAL (verdad = 0) |
| Sin efecto, misma autoselección | El ingenuo sale significativo (falso positivo) → IPTW incluye 1 → **NO_SIGNAL** |
| Corpus hasta hoy (22-sep) | Solo 3 días POST con 168 h de seguimiento → OR ingenuo 6,9 con p = 0,0001, pero 9 eventos control y OR mínimo detectable 3,1 → **INSUFFICIENT_DATA** |
| RWA ≈1% de POST | H_RWA e H_INT → INSUFFICIENT_DATA; H_FEE sigue evaluable |

Además:
- el Y detectado coincide con la verdad en ≥99,5% de tokens, también en pares RWA;
- el ATH de los tokens NVDAX coincide con su pico real (±2%), lo que confirma que el MC en USD usa el precio del par y no el de SOL.

## Límites que hay que conocer antes de ejecutar

1. **Ventana POST.** Con 168 h de seguimiento, hoy solo son elegibles los lanzamientos del 12 al 15 de septiembre. O esperas (cada día añade uno) o usas 72 h como primario, **decidiéndolo antes de mirar**.
2. **Cobertura del corpus.** Si tu corpus es el de mayo–junio, no cubre el corte. Hace falta recoger agosto–septiembre, con fee mode y par por token.
3. **Autoselección no observable.** El IPTW solo corrige lo que miden las covariables. Si los mejores equipos eligen HR por razones que no se ven al crear el token (comunidad previa fuera de la cadena, por ejemplo), queda sesgo residual. Por eso SIGNAL exige además robustez.
4. **SIGNAL no significa "lanza".** Significa que existe una asociación robusta a nivel de población. Replicarla con un solo token sigue siendo N=1.

## Fase 0.2 (Nivel A), resumen

Cobertura medida con datos, ATH observable/reconstruido, cruces raw y validados, N_reach → N_observable → N_complete → N_effective, potencia de Precision@K con Bonferroni, calidad (Q), granularidad, social point-in-time, regímenes, false escalators y leave-big-winner-out. Decisión: `READY_STAGE_MODEL` / `POST_MIGRATION_REQUIRED` / `LIMITED_SAMPLE` / `DATA_FAIL`.

Cambios en la v0.3:
- MC = precio del token en el par × USD del par (ASOF ≤ t) × supply, con escalas por activo;
- cobertura de precio por activo;
- corregido un desbordamiento numérico con N grandes.

A escala real (800k tokens / 33M trades): ~4 min con 2 núcleos y 5 GB.

---

## Token forensics: un token concreto desde la cadena (`token_forensics.py`)

Reconstruye un token de Pump.fun a partir de su mint usando solo un RPC de Solana, sin APIs de terceros.

```bash
python token_forensics.py --mint <MINT> --rpc "https://mainnet.helius-rpc.com/?api-key=XXX" \
       --out late_out --fee-mode holder_rewards --declare-no-creator-buys --wallet-age 150
```

- **Descarga:** todas las transacciones del mint, con caché. Si lo interrumpes, se reanuda sin volver a descargar.
- **Reconstrucción:** trades (SOL corregido por el alquiler de cuentas y por wSOL) y holders a partir de los saldos de token, transferencias incluidas.
- **Métricas:**
  - holders a 1/3/5/10/15/30/60/180 min y a 24 h, y tiempo hasta 10/100/1.000 holders;
  - compradores y vendedores únicos, y ratio compra/venta;
  - top-1, top-10 y Gini;
  - snipers en los primeros 2 slots y compras de varias wallets en el mismo slot;
  - trades del creador.
- **`--wallet-age N`:** edad de las N primeras wallets compradoras (fresh si tienen menos de 24 h) y si su primera transacción involucra al creador.
- **Control negativo:** `--declare-no-creator-buys` y `--own-wallets` comparan lo que declaras con lo que se detecta. Si el detector marca un vínculo con el creador en un token limpio, has encontrado un falso positivo.
- **Salidas:**
  - `report.md`, `metrics.json`, `trades.csv`, `holders_timeseries.csv` y `wallet_age.csv`;
  - `p0_*.parquet` y `p0_config.json`, listos para `phase0_audit.py`.

**RPC:** el público (`api.mainnet-beta.solana.com`) limita mucho las peticiones. Un plan gratuito de Helius, QuickNode o similar basta. Coste aproximado: 1 llamada por transacción más 1 por cada 1.000 firmas.

**Validación:** `test_forensics.py` usa una cadena simulada (23 checks):
- snipers en el slot de creación, compra con wSOL, transferencia, transacción fallida, migración al pool, transacciones v0 y más de 1.000 firmas;
- un creador que compra (se detecta) y un comprador financiado por el creador (se detecta el vínculo).
El test encontró y corrigió dos fallos que habrían aparecido con datos reales: el pool no se reconocía como cuenta de sistema (recibe ~20% del supply) y las transferencias se contaban como ventas.

---

## SCAN: el scanner en tiempo real (`scan.py`)

```bash
export SOLANA_RPC="https://mainnet.helius-rpc.com/?api-key=XXX"
python scan.py --doctor        # PRIMERA VEZ: verifica direcciones y layout en red real. Si da ❌, no sigas.
python scan.py                 # scan: últimos 30 min, reconstruye los 25 con más MC
python scan.py --window 60 --top 40 --show-all
```

**Flujo:** Pump.fun (creaciones on-chain) → estado de curva y mint por lotes → HARD → presupuesto top-N por MC → `token_forensics` a T → `scam_filter` → score → tarjetas + `scans/scan_log.jsonl`.

| Pieza | Qué hace |
|---|---|
| `pump_discovery.py` | Creaciones vía la cuenta *mint authority* de Pump (solo aparece en creaciones); parsea mint, curva, creador, nombre y ticker; decodifica la curva (MC, progreso, graduado) y el mint (authorities, extensiones). |
| `token_forensics.py` | Reconstrucción **point-in-time** (`until_ts`) + financiador de cada wallet (quien firma su primera tx). |
| `scam_filter.py` | Features a T y etiqueta ⚫/🔴/🟡/🟢. Porcentajes sobre el supply total y **sin cuentas de sistema**. Cluster de insiders = creador + wallets financiadas por él + grupos de ≥2 compradores con el mismo financiador. |
| `scan.py` | Orquestación, tarjetas, registro, `--doctor`, `--now` (reproducir un scan pasado). |

**Reglas de etiqueta** (umbrales `PROVISIONAL`, preset MOONSHOT_SAFE_V1 **sin calibrar**):
- ⚫ INVALID: curva o mint ilegibles, historial incompleto, la creación no cuadra o el parseo es incoherente.
- 🔴 MANIPULATED: HARD (mint/freeze authority, extensión peligrosa), el creador vendió, ≥2 umbrales superados, o cluster de insiders > 2× su umbral.
- 🟡 WATCH: 1 umbral superado, actividad < 5 compras/ventas/compradores, o wallets sin financiador conocido.
- 🟢 CLEAN: nada de lo anterior.

**MOONSHOT SCORE:** percentil medio dentro del lote de compradores/min, holders/min, compra neta en SOL/min y MC. Es un **ranking relativo**, no una probabilidad.

**Presupuesto:** `top_n` limita el coste de RPC; no es un filtro de calidad. Los tokens no analizados se **registran igualmente** para que la calibración tenga el denominador completo.

**Límites conocidos:**
- Los financiadores masivos (hot wallets de exchanges) crean falsos clusters. Añádelos a `hubs` en la config cuando los veas.
- La edad y el financiador solo se miran para las 25 primeras wallets compradoras (`funder_top_k`).
- El MC de un token graduado usa el precio del último trade (aproximado).

**Validación:** `test_scan.py` usa una cadena simulada con 8 lanzamientos (24 checks):
- orgánico → CLEAN;
- bundle de 12 wallets → MANIPULATED (cluster de 12, insider 33%);
- mint authority → HARD sin gastar forensics;
- poca actividad → WATCH;
- curva ilegible → INVALID y el doctor no da luz verde;
- creador que vende → MANIPULATED;
- fuera de ventana → no aparece.

Además, el scan reproducido 16 min antes no ve las ventas futuras (point-in-time), y el límite de presupuesto registra los tokens no analizados.

**Siguiente paso (calibración):** con ~1–2 semanas de `scan_log.jsonl`, `outcomes.py` etiqueta cada token (¿$1M en 7 días?, ¿rug?) y `calibrate.py` elige y congela los umbrales en train y los evalúa en holdout.

## Breakout/Base Study v0.2

`breakout_study.py` implements the pre-registered cumulative ladder agreed for the base/ATH hypothesis:

- **N0**: caída desde ATH >= `min_drawdown` y base plana durante `min_duration_hours` dentro de `flat_band_pct`.
- **N1**: N0 + suelo estable (`stable_window_hours`, `max_range_pct`).
- **N2**: N1 + reactivación de volumen (`volume_ratio`).
- **N3**: N2 + aceleración simultánea de holders y compradores únicos.
- **N4**: N3 + primer nuevo ATH, definido exclusivamente con `max(mc)` observado **antes** del instante de ruptura.

Resultados desde cada nivel: MFE 24 h / 7 d, tiempo hasta 2x/10x y fallo del breakout para N4.

También calcula un **baseline de drawdown**: todos los tokens que alcanzan el drawdown X por primera vez, sin exigir base plana. Sirve para responder si N0 mejora respecto a la misma caída sin la condición de consolidación.

Salidas principales: `breakout_events`, `breakout_levels`, `breakout_summary.csv`, `breakout_drawdown_baseline.csv`, `breakout_baseline_summary.csv`, `breakout_by_drawdown.csv`, `breakout_by_duration.csv`, `breakout_failures.csv`, `study_metadata.json`.

`test_breakout_study.py` contiene una cadena sintética con ganador/muertos y prueba que las señales y outcomes no miran al futuro. Los umbrales de `breakout_config.example.json` son **candidatos de preregistro**, no deben ajustarse después de mirar el corpus real.

Ejemplo:

```bash
python breakout_study.py --snapshots snapshots.parquet --trades trades.parquet --config breakout_config.json --out breakout_out
```

## Active Strategy: Smart Money Flat Base v0.2

The active hypothesis for the H-100M scanner is now **Smart Money Flat Base**. The previous Breakout/Base study remains in the repository as a legacy research module and is **not** the current entry rule.

Strategy, pre-registered in `smart_money_config.example.json`:

1. Token previously reached **>= $500k MC**.
2. At the signal timestamp it is down **>=70% from its historical peak** and the previous **72h** remains inside a **+/-25% band around the median** (configurable).
3. Its **maximum 24h trading volume observed so far** is **>= $500k** (configurable). This is point-in-time; cumulative lifetime volume is not used.
4. A smart wallet selected **only from period A** buys **>= $5k** while the token is in the flat base.
5. The simulated user entry is delayed by +1 min and +5 min by default. If MC is >30% above the smart-wallet buy, or the token is no longer in the qualifying base, the entry is rejected.
6. Exits: 50% at 2x when hit; remaining position exits when the lead smart wallet has reduced its signal-time position by >=50%; stop at the signal-time base floor; otherwise mark at 7 days.

Smart-wallet selection requires, by default, **>= $1M realized PnL in period A**, **>=20 matched closed sells**, **>=5 distinct tokens**, and no more than **50% of positive PnL from one token**. Opening inventory is not guessed: realized PnL is FIFO on buys that can be matched inside period A.

The study also creates a same-timestamp matched control group: flat-base tokens that satisfy the same point-in-time token criteria but have no qualifying smart-wallet purchase around the treatment timestamp. Outputs include `smart_vs_control_summary.csv`.

Main files:
- `smart_money_study.py`
- `smart_money_config.example.json`
- `test_smart_money_study.py`

Example:

```bash
python smart_money_study.py --snapshots snapshots.parquet --trades trades.parquet --config smart_money_config.json --out smart_money_out
```

**Important:** do not tune these thresholds after looking at real-corpus outcomes. Use the A/B temporal split and freeze the selection rule before the B-period evaluation.

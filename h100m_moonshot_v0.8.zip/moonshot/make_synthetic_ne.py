#!/usr/bin/env python3
"""
Corpus sintético para el experimento natural (Fase 0.3) con VERDAD CONOCIDA.

Estructura plantada:
  - Lanzamientos 1-ago → fin (configurable); corte 12-sep.
  - PRE: pares SOL/USDC; fee creator/cashback. POST: SOL/USDC/NVDAX/TSLAX; fee creator/holder_rewards.
  - Autoselección: los creadores con más "skill" (latente) eligen Holder Rewards más a menudo,
    y skill también sube la probabilidad de éxito  -> el OR ingenuo está sesgado hacia arriba.
  - Proxies observables de skill en el momento de creación: dev buy, historial del creador, socials.
  - Efecto causal plantado de HR (escenarios effect_*): sobre graduación y sobre P(1M | graduado).
  - Multi-par: precios del token en el activo del par; NVDAX/TSLAX con su propia serie horaria.

Cada token guarda p1/p0 = P(1M) si fuera HR / si fuera CF -> OR marginal "oráculo" para validar IPTW.
"""
import argparse
import json
import math
import os

import numpy as np
import pandas as pd

START = pd.Timestamp("2026-08-01")
CUT = pd.Timestamp("2026-09-12")
SUPPLY = 1e9
GRAD_MC = 70_000.0
MINTS = {"SOL": "So11111111111111111111111111111111111111112",
         "USDC": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
         "NVDAX": "XsNVDAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
         "TSLAX": "XsTSLAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"}
SCALES = {"SOL": 1e-9, "USDC": 1e-6, "NVDAX": 1e-8, "TSLAX": 1e-8}
TRADE_Q = {"SOL": (0.1, 5.0), "USDC": (20, 700), "NVDAX": (0.1, 4.0), "TSLAX": (0.05, 2.0)}

SCENARIOS = {
    #            end          launches/day  g_hr  b_hr  b_rwa b_int  post_pair_probs (SOL, USDC, NVDAX, TSLAX)
    "effect_long": ("2026-10-20", 900, 0.30, 0.50, 0.0, 0.0, (0.70, 0.06, 0.14, 0.10)),
    "null_long":   ("2026-10-20", 900, 0.00, 0.00, 0.0, 0.0, (0.70, 0.06, 0.14, 0.10)),
    "today":       ("2026-09-22", 900, 0.30, 0.50, 0.0, 0.0, (0.70, 0.06, 0.14, 0.10)),
    "few_rwa":     ("2026-10-20", 900, 0.30, 0.50, 0.0, 0.0, (0.93, 0.06, 0.007, 0.003)),
}


def sig(x):
    return 1 / (1 + np.exp(-x))


def make(outdir, scenario="effect_long", seed=11):
    end_s, L, g_hr, b_hr, b_rwa, b_int, post_probs = SCENARIOS[scenario]
    END = pd.Timestamp(end_s)
    rng = np.random.default_rng(seed)
    hours = pd.date_range(START - pd.Timedelta(days=2), END + pd.Timedelta(days=5), freq="h")
    nh = len(hours)
    px = {"SOL": 150 * np.exp(np.cumsum(rng.normal(0, 0.004, nh))),
          "NVDAX": 180 * np.exp(np.cumsum(rng.normal(0, 0.003, nh))),
          "TSLAX": 400 * np.exp(np.cumsum(rng.normal(0, 0.005, nh))),
          "USDC": np.ones(nh)}
    h0 = hours[0]

    def qusd(asset, t):
        return float(px[asset][int((t - h0).total_seconds() // 3600)])

    days = (END - START).days
    n = L * days
    # creadores (algunos seriales) con skill latente
    n_cr = n // 4
    cr_skill = rng.normal(0, 1, n_cr)
    w = 1 / np.arange(1, n_cr + 1) ** 0.6
    creators = rng.choice(n_cr, size=n, p=w / w.sum())
    skill = cr_skill[creators]
    created = START + pd.to_timedelta(np.sort(rng.uniform(0, days * 86400, n)), unit="s")
    created = created.floor("s")
    post = created >= CUT
    pair = np.where(post, rng.choice(["SOL", "USDC", "NVDAX", "TSLAX"], size=n, p=post_probs),
                    rng.choice(["SOL", "USDC"], size=n, p=[0.97, 0.03]))
    hr_prob = sig(-0.4 + 0.9 * skill)
    fee = np.where(post, np.where(rng.random(n) < hr_prob, "holder_rewards", "creator_fee"),
                   np.where(rng.random(n) < 0.2, "cashback", "creator"))
    HR = (fee == "holder_rewards").astype(float)
    RWA = np.isin(pair, ["NVDAX", "TSLAX"]).astype(float)
    dev_buy = np.exp(2.5 + 0.9 * skill + rng.normal(0, 0.35, n))
    has_x = rng.random(n) < sig(-0.8 + 0.5 * skill)
    # probabilidades estructurales
    lg = -3.0 + 0.9 * skill
    lw = -2.2 + 0.9 * skill + b_rwa * RWA
    pg1, pg0 = sig(lg + g_hr), sig(lg)
    pw1, pw0 = sig(lw + b_hr + b_int * RWA), sig(lw)
    p1, p0 = pg1 * pw1, pg0 * pw0
    pg = np.where(HR == 1, pg1, pg0)
    pw = np.where(HR == 1, pw1, pw0)
    grad = rng.random(n) < pg
    win = grad & (rng.random(n) < pw)

    tok_rows, trades, migs, truth = [], [], [], []
    wal_i = [0]

    def wallet():
        wal_i[0] += 1
        return f"W{wal_i[0]:0>43d}"

    def add_trade(mint, a, t, mc, who=None, side=None, q_amt=None):
        t = t.floor("s")
        pu = mc / SUPPLY
        pq = pu / qusd(a, t)
        lo, hi = TRADE_Q[a]
        q = q_amt if q_amt is not None else rng.uniform(lo, hi)
        trades.append((mint, int(t.timestamp()), f"tx{len(trades)}", who or wallet(),
                       side or ("buy" if rng.random() < 0.7 else "sell"),
                       int(round(q / SCALES[a])), int(round(q / pq * 1e6))))

    for i in range(n):
        mint = f"M{i:07d}" + "p" * 36
        cr = f"C{creators[i]:0>43d}"
        a = pair[i]
        t0 = created[i]
        tok_rows.append((mint, t0, cr, f"Tok{i}", f"T{i}", "x.com/t" if has_x[i] else None,
                         MINTS[a], fee[i]))
        # dev buy en la creación
        add_trade(mint, a, t0, 4_000, who=cr, side="buy", q_amt=dev_buy[i] / qusd(a, t0))
        t_1m, peak, gts = None, None, None
        if not grad[i]:
            life = rng.uniform(5, 120)
            for k, frac in enumerate(np.sort(rng.uniform(0, 1, 2))):
                add_trade(mint, a, t0 + pd.Timedelta(minutes=life * frac), 4_000 + frac * rng.uniform(1_000, 50_000))
        else:
            g_min = rng.uniform(5, 180)
            gts = t0 + pd.Timedelta(minutes=g_min)
            for k in range(1, 6):
                add_trade(mint, a, t0 + pd.Timedelta(minutes=g_min * k / 6), 4_000 * (GRAD_MC / 4_000) ** (k / 6))
            migs.append((mint, gts))
            t = gts + pd.Timedelta(seconds=30)
            if win[i]:
                peak = 1e6 * math.exp(rng.uniform(0.25, 3.0))
                h1m = rng.uniform(1, 40)
                rise = h1m * math.log(peak / GRAD_MC) / math.log(1e6 / GRAD_MC)
                step = 240
            else:
                peak = rng.uniform(80_000, 900_000)
                rise = rng.uniform(0.5, 10)
                step = 900
            tp = t + pd.Timedelta(hours=rise)
            while t <= tp:
                fr = (t - gts).total_seconds() / (tp - gts).total_seconds()
                mc = GRAD_MC * (peak / GRAD_MC) ** fr * rng.uniform(0.997, 1.003)
                add_trade(mint, a, t, mc)
                if t_1m is None and mc >= 1e6:
                    t_1m = t
                t += pd.Timedelta(seconds=step)
            te = tp + pd.Timedelta(hours=12)
            while t < te:
                fr = (t - tp).total_seconds() / (te - tp).total_seconds()
                add_trade(mint, a, t, peak * 0.2 ** fr)
                t += pd.Timedelta(minutes=30)
        truth.append((mint, float(skill[i]), fee[i], a, bool(post[i]), bool(grad[i]), bool(win[i]),
                      peak, t_1m, float(p1[i]), float(p0[i])))

    os.makedirs(outdir, exist_ok=True)
    tokens = pd.DataFrame(tok_rows, columns=["mint", "created_at", "creator", "name", "symbol", "twitter",
                                             "quote_mint", "fee_config"])
    tokens.to_parquet(f"{outdir}/tokens.parquet", index=False)
    tr = pd.DataFrame(trades, columns=["mint", "block_time", "signature", "signer", "direction", "quote_amount_raw",
                                       "token_amount_raw"])
    tr[tr["block_time"] <= int(END.timestamp())].to_parquet(f"{outdir}/trades.parquet", index=False)
    mg = pd.DataFrame(migs, columns=["mint", "migrated_at"])
    mg[mg["migrated_at"] <= END].to_parquet(f"{outdir}/migrations.parquet", index=False)
    pd.DataFrame({"ts": hours, "price_usd": px["SOL"]}).to_parquet(f"{outdir}/sol_price.parquet", index=False)
    qp = pd.concat([pd.DataFrame({"asset": a, "ts": hours, "price_usd": px[a]}) for a in ("NVDAX", "TSLAX")])
    qp.to_parquet(f"{outdir}/quote_prices.parquet", index=False)
    pd.DataFrame(truth, columns=["mint", "skill", "fee", "pair", "post", "graduated", "winner", "peak", "t_1m",
                                 "p1", "p0"]).to_parquet(f"{outdir}/truth.parquet", index=False)
    cfg = {
        "tables": {
            "tokens": {"path": f"{outdir}/tokens.parquet",
                       "columns": {"mint": "mint", "created_at": "created_at", "creator": "creator", "name": "name",
                                   "symbol": "symbol", "twitter": "twitter", "quote_asset": "quote_mint",
                                   "fee_mode": "fee_config"}},
            "trades": {"path": f"{outdir}/trades.parquet",
                       "columns": {"mint": "mint", "ts": "block_time", "signature": "signature", "wallet": "signer",
                                   "side": "direction", "quote_amount": "quote_amount_raw",
                                   "token_amount": "token_amount_raw"}},
            "migrations": {"path": f"{outdir}/migrations.parquet", "columns": {"mint": "mint", "ts": "migrated_at"}},
            "sol_price": {"path": f"{outdir}/sol_price.parquet", "columns": {"ts": "ts", "price_usd": "price_usd"}},
            "quote_prices": {"path": f"{outdir}/quote_prices.parquet",
                             "columns": {"asset": "asset", "ts": "ts", "price_usd": "price_usd"}},
        },
        "timestamp_units": {"trades": "s"},
        "amount_scales": {"sol_amount": 1e-9, "token_amount": 1e-6},
        "quote": {"aliases": {v: k for k, v in MINTS.items()},
                  "amount_scales": SCALES},
        "pair_catalog": {"SOL": "SOL", "USDC": "STABLE", "NVDAX": "RWA", "TSLAX": "RWA"},
        "fee_mode_values": {"creator_fee": ["creator_fee", "creator"], "holder_rewards": ["holder_rewards"],
                            "cashback": ["cashback"]},
        "experiment": {"corpus_end_utc": str(END), "n_bootstrap": 200},
    }
    with open(f"{outdir}/config.json", "w") as f:
        json.dump(cfg, f, indent=2)
    return cfg


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--scenario", default="effect_long", choices=list(SCENARIOS))
    a = ap.parse_args()
    make(a.out, a.scenario)
    print("ok", a.out)

#!/usr/bin/env python3
"""
Tests de phase0_audit.py contra corpus sintéticos con verdad conocida.
Ejecutar:  python test_phase0.py [--workdir DIR]
Tarda ~4-5 min (genera 5 corpus).
"""
import argparse
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_synthetic  # noqa: E402

FAILS = []


def check(name, cond, got=None):
    status = "PASS" if cond else "FAIL"
    print(f"  [{status}] {name}" + ("" if cond else f"   (obtenido: {got})"))
    if not cond:
        FAILS.append(name)


def run(workdir, scenario):
    data = os.path.join(workdir, f"syn_{scenario}")
    out = os.path.join(workdir, f"out_{scenario}")
    if not os.path.exists(os.path.join(data, "config.json")):
        make_synthetic.make(data, scenario)
    subprocess.run([sys.executable, os.path.join(HERE, "phase0_audit.py"), "--config",
                    os.path.join(data, "config.json"), "--out", out],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    with open(os.path.join(out, "phase0_report.json")) as f:
        return json.load(f)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workdir", default=os.path.join(HERE, "_test_data"))
    a = ap.parse_args()
    os.makedirs(a.workdir, exist_ok=True)

    print("\n== base")
    r = run(a.workdir, "base")
    s1, s2, s3 = r["stages"]["1M->10M"], r["stages"]["10M->50M"], r["stages"]["50M->100M"]
    check("decisión READY_STAGE_MODEL", r["DECISION"] == "READY_STAGE_MODEL", r["DECISION"])
    check("post-migración PASS_USABLE", r["post_migration"]["status"] == "PASS_USABLE", r["post_migration"]["status"])
    check("cobertura post-migración 0.90", abs(r["post_migration_coverage"] - 0.90) < 1e-9, r["post_migration_coverage"])
    check("n_ge_1m validado = 45", r["n_ge_1m"] == 45, r["n_ge_1m"])
    check("n_ge_1m raw = 50 (5 spikes)", r["n_ge_1m_raw"] == 50, r["n_ge_1m_raw"])
    check("n_ge_10m = 25", r["n_ge_10m"] == 25, r["n_ge_10m"])
    check("n_ge_50m = 8", r["n_ge_50m"] == 8, r["n_ge_50m"])
    check("n_ge_100m = 4", r["n_ge_100m"] == 4, r["n_ge_100m"])
    check("huérfanos no crean cruces (raw 10M = 25)", r["crosses"]["10M"]["n_raw_cross"] == 25,
          r["crosses"]["10M"]["n_raw_cross"])
    check("etapa1 N_reach 45", s1["N_reach"] == 45, s1["N_reach"])
    check("etapa1 N_observable 44 (hueco en el cruce)", s1["N_observable"] == 44, s1["N_observable"])
    check("etapa1 eventos 24", s1["events_effective (llegan a B)"] == 24, s1["events_effective (llegan a B)"])
    check("etapa1 false escalators 5", s1["false_escalators (>=2x A, no B, colapso >=80%)"] == 5,
          s1["false_escalators (>=2x A, no B, colapso >=80%)"])
    check("etapa2 N_eff 25 / eventos 8", (s2["N_effective"], s2["events_effective (llegan a B)"]) == (25, 8),
          (s2["N_effective"], s2["events_effective (llegan a B)"]))
    check("etapa3 N_eff 8 / eventos 4", (s3["N_effective"], s3["events_effective (llegan a B)"]) == (8, 4),
          (s3["N_effective"], s3["events_effective (llegan a B)"]))
    check("etapa3 tier DESCRIPTIVE_ONLY", s3["model_tier"].startswith("DESCRIPTIVE_ONLY"), s3["model_tier"])
    check("leave-top-5 etapa3 = 0", s3["leave_big_winner_out"]["events_without_top5"] == 0,
          s3["leave_big_winner_out"])
    qt = r["quality_tests"]
    check("50 filas duplicadas detectadas", qt["duplicated_trade_rows"] == 50, qt["duplicated_trade_rows"])
    check("30 trades huérfanos", qt["orphan_trades"] == 30, qt["orphan_trades"])
    check("1 token duplicado con 2 fechas", qt["tokens_with_multiple_creation_ts"] == 1,
          qt["tokens_with_multiple_creation_ts"])
    check("reconstrucción MC VALIDATED", r["mc_definition"]["reconstruction"]["status"] == "VALIDATED",
          r["mc_definition"]["reconstruction"])
    check("social at threshold UNKNOWN (no se imputa)", str(r["social_at_threshold_coverage"]).startswith("UNKNOWN"),
          r["social_at_threshold_coverage"])
    check("migraciones sin post = ATH no observable (20)",
          r["ath_class_counts"].get("unobservable_censored_at_migration") == 20, r["ath_class_counts"])

    print("\n== no_gap (sin hueco: el token vuelve a ser observable)")
    r = run(a.workdir, "no_gap")
    s1 = r["stages"]["1M->10M"]
    check("etapa1 N_observable 45 / eventos 25",
          (s1["N_observable"], s1["events_effective (llegan a B)"]) == (45, 25),
          (s1["N_observable"], s1["events_effective (llegan a B)"]))

    print("\n== no_post (los datos terminan en la bonding curve)")
    r = run(a.workdir, "no_post")
    check("post-migración FAIL", r["post_migration"]["status"] == "FAIL", r["post_migration"]["status"])
    check("decisión POST_MIGRATION_REQUIRED", r["DECISION"] == "POST_MIGRATION_REQUIRED", r["DECISION"])
    check("n_ge_1m = 0", r["n_ge_1m"] == 0, r["n_ge_1m"])

    print("\n== no_migrations (sin frontera temporal fiable)")
    r = run(a.workdir, "no_migrations")
    check("post-migración UNKNOWN", r["post_migration"]["status"] == "UNKNOWN", r["post_migration"]["status"])
    check("decisión POST_MIGRATION_REQUIRED", r["DECISION"] == "POST_MIGRATION_REQUIRED", r["DECISION"])

    print("\n== no_sol (sin SOL/USD: umbrales USD imposibles)")
    r = run(a.workdir, "no_sol")
    check("decisión DATA_FAIL", r["DECISION"] == "DATA_FAIL", r["DECISION"])

    print(f"\n{'TODO OK' if not FAILS else f'{len(FAILS)} FALLOS: {FAILS}'}")
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()

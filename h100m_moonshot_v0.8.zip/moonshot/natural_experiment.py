#!/usr/bin/env python3
"""
H-100M · FASE 0.3 — NATURAL EXPERIMENT ENGINE (corte Pump.fun 12-sep-2026)
=========================================================================

Pregunta: ¿cambian el modo de fee (Holder Rewards vs Creator Fee) y el activo del par
(RWA vs SOL) la probabilidad de alcanzar un umbral, comparando tokens lanzados el mismo día?

Nivel A: ejecuta la auditoría Fase 0.2 (phase0_audit.py, ya multi-par) y responde A–H.
Nivel B: experimento natural, sin ML:
  · tabla descriptiva de cohortes (4 grupos + resto)
  · contrastes estratificados por día (Mantel-Haenszel + IC de Robins-Breslow-Greenland)
  · test de permutación EXACTO condicional a estratos (suma de hipergeométricas)
  · ajuste IPTW con covariables del MOMENTO DE CREACIÓN (nunca post-tratamiento) + balance
  · interacción fee × par (ratio de OR MH, permutación)
  · event study alrededor del corte + placebos en fechas falsas
  · robustez (ventanas, horizontes, etiquetas, exclusiones, régimen SOL)
  · primaria sin corrección; secundarias con Benjamini-Hochberg
  · veredicto: SIGNAL / NO_SIGNAL / INSUFFICIENT_DATA

Decisiones de diseño (pre-registradas en la config que se copia al informe):
  1. Outcome primario = cruce VALIDADO de $1M dentro de H horas desde la CREACIÓN, sobre
     todos los lanzamientos elegibles. Condicionar a "graduado" condiciona a una variable
     que el propio tratamiento puede cambiar; P(1M | graduado) se reporta como descomposición.
  2. Covariables de propensión: solo información disponible al crear el token. Volumen,
     holders o actividad iniciales son POST-tratamiento (posibles mediadores) y se excluyen.
  3. Elegibilidad exige seguimiento completo: created_at + H <= fin del corpus.

Uso:
  python natural_experiment.py --config config.json --out ne_out
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from datetime import datetime, timezone

import duckdb
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import phase0_audit as p0  # noqa: E402

VERSION = "0.3.0"

NE_DEFAULTS = {
    "extra_thresholds_usd": [100_000, 2_000_000, 20_000_000],
    "required_at_cross": ["wallet"],
    "experiment": {
        "cutoff_utc": "2026-09-12T00:00:00",
        "window_start_utc": None,          # por defecto: primer lanzamiento
        "corpus_end_utc": None,            # fin de la recogida; por defecto max(ts) de trades
        "primary": {"threshold": 1_000_000, "horizon_hours": 168, "label": "validated"},
        "dev_buy_window_seconds": 10,
        "serial_creator_min_prior": 20,
        "q_min": 0.90,
        "n_permutations": 10000,
        "n_bootstrap": 300,
        "seed": 12345,
        "alpha": 0.05,
        "power": {"min_events_total": 20, "min_events_per_arm": 5, "mde_or_max": 2.0, "target": 0.80},
        "balance_smd_max": 0.10,
        "propensity_clip": [0.01, 0.99],
        "event_study": {"days_before": 14, "windows_days": [1, 3, 7, 14], "primary_window_days": 3,
                        "placebo_min": 19},
        "robustness": {"windows_days_post": [1, 3, 7], "horizons_hours": [24, 72, 168],
                       "drop_top": [1, 5], "n_permutations": 2000},
    },
}

GROUPS = [("SOL", "creator_fee", "A · SOL + Creator"), ("SOL", "holder_rewards", "B · SOL + Holder"),
          ("RWA", "creator_fee", "C · RWA + Creator"), ("RWA", "holder_rewards", "D · RWA + Holder")]


# ======================================================================================
# Estadística (numpy puro)
# ======================================================================================
def wilson(k, n, z=1.96):
    if n == 0:
        return (None, None)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (round(max(0.0, c - h), 6), round(min(1.0, c + h), 6))


def norm_ppf(p):
    # Acklam
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02,
         -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01,
         -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00,
         4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00]
    pl = 0.02425
    if p < pl:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    if p > 1 - pl:
        q = math.sqrt(-2 * math.log(1 - p))
        return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    q = p - 0.5
    r = q * q
    return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q / (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)


def strata_table(df, treat, y, strata):
    g = df.groupby(strata, observed=True)
    t = pd.DataFrame({
        "n_t": g[treat].sum(), "n": g[treat].size(),
        "e_t": g.apply(lambda x: int((x[treat] & x[y]).sum()), include_groups=False),
        "e": g[y].sum(),
    })
    t["n_c"] = t["n"] - t["n_t"]
    t["e_c"] = t["e"] - t["e_t"]
    return t


def mh_or(t):
    """OR de Mantel-Haenszel + IC 95% de Robins-Breslow-Greenland. t: strata con n_t,n_c,e_t,e_c."""
    a = t["e_t"].to_numpy(float); b = (t["n_t"] - t["e_t"]).to_numpy(float)
    c = t["e_c"].to_numpy(float); d = (t["n_c"] - t["e_c"]).to_numpy(float)
    n = a + b + c + d
    ok = n > 0
    a, b, c, d, n = a[ok], b[ok], c[ok], d[ok], n[ok]
    R = a * d / n; S = b * c / n
    sR, sS = R.sum(), S.sum()
    if sR == 0 or sS == 0:
        return {"or": None if sS == 0 and sR == 0 else (math.inf if sS == 0 else 0.0), "ci": None, "log_or": None, "se": None}
    orr = sR / sS
    P = (a + d) / n; Q = (b + c) / n
    var = ((P * R).sum() / (2 * sR ** 2) + ((P * S + Q * R).sum()) / (2 * sR * sS) + (Q * S).sum() / (2 * sS ** 2))
    se = math.sqrt(var)
    lo, hi = math.exp(math.log(orr) - 1.96 * se), math.exp(math.log(orr) + 1.96 * se)
    return {"or": orr, "ci": [lo, hi], "log_or": math.log(orr), "se": se}


def perm_test_strata(t, n_perm, rng):
    """Permutación exacta condicional: en cada estrato, eventos tratados ~ Hipergeométrica.
    Estadístico: T = Σ eventos tratados (equivale a CMH). Bilateral."""
    ne = t["e"].to_numpy(int); nn = t["n"].to_numpy(int); nt = t["n_t"].to_numpy(int)
    keep = (nt > 0) & (nt < nn) & (ne > 0) & (ne < nn)
    ne, nn, nt = ne[keep], nn[keep], nt[keep]
    obs = int(t["e_t"].to_numpy(int)[keep].sum())
    if len(nn) == 0:
        return None
    E = float((nt * ne / nn).sum())
    sims = rng.hypergeometric(np.broadcast_to(ne, (n_perm, len(ne))),
                              np.broadcast_to(nn - ne, (n_perm, len(ne))),
                              np.broadcast_to(nt, (n_perm, len(ne)))).sum(axis=1)
    p = (1 + np.sum(np.abs(sims - E) >= abs(obs - E) - 1e-9)) / (1 + n_perm)
    return float(p)


def perm_interaction(t1, t2, n_perm, rng):
    """Permutación para diferencia de log OR MH entre dos subpoblaciones (estratos independientes)."""
    def draws(t):
        ne = t["e"].to_numpy(int); nn = t["n"].to_numpy(int); nt = t["n_t"].to_numpy(int)
        a = rng.hypergeometric(np.broadcast_to(ne, (n_perm, len(ne))), np.broadcast_to(nn - ne, (n_perm, len(ne))),
                               np.broadcast_to(nt, (n_perm, len(ne))))
        b = nt - a; c = ne - a; d = (nn - nt) - c
        with np.errstate(divide="ignore", invalid="ignore"):
            R = (a * d / nn).sum(axis=1); S = (b * c / nn).sum(axis=1)
            return np.log(R / S)
    o1, o2 = mh_or(t1), mh_or(t2)
    if o1["log_or"] is None or o2["log_or"] is None:
        return None
    obs = o1["log_or"] - o2["log_or"]
    sim = draws(t1) - draws(t2)
    sim = sim[np.isfinite(sim)]
    if len(sim) < n_perm * 0.5:
        return None
    return float((1 + np.sum(np.abs(sim) >= abs(obs) - 1e-12)) / (1 + len(sim)))


def mde_or(n_t, n_c, p0, alpha, power):
    """OR mínimo detectable (aprox. normal sobre log OR)."""
    if n_t == 0 or n_c == 0 or p0 <= 0 or p0 >= 1:
        return None
    z = norm_ppf(1 - alpha / 2) + norm_ppf(power)
    for orr in np.exp(np.linspace(0.01, math.log(100), 2000)):
        p1 = orr * p0 / (1 - p0 + orr * p0)
        se = math.sqrt(1 / (n_t * p1) + 1 / (n_t * (1 - p1)) + 1 / (n_c * p0) + 1 / (n_c * (1 - p0)))
        if math.log(orr) / se >= z:
            return float(orr)
    return None


def logit_fit(X, y, w=None, l2=1.0, iters=50):
    """Logística IRLS con ridge (intercepto sin penalizar). X ya estandarizada, sin intercepto."""
    n, k = X.shape
    Xi = np.hstack([np.ones((n, 1)), X])
    w = np.ones(n) if w is None else w
    beta = np.zeros(k + 1)
    pen = np.full(k + 1, l2); pen[0] = 0.0
    for _ in range(iters):
        eta = np.clip(Xi @ beta, -30, 30)
        p = 1 / (1 + np.exp(-eta))
        W = w * p * (1 - p)
        g = Xi.T @ (w * (y - p)) - pen * beta
        H = (Xi.T * W) @ Xi + np.diag(pen)
        step = np.linalg.solve(H, g)
        beta += step
        if np.max(np.abs(step)) < 1e-8:
            break
    return beta


def predict(beta, X):
    Xi = np.hstack([np.ones((X.shape[0], 1)), X])
    return 1 / (1 + np.exp(-np.clip(Xi @ beta, -30, 30)))


def bh(pvals):
    """Benjamini-Hochberg: q-values en el orden de entrada (None se respeta)."""
    idx = [i for i, p in enumerate(pvals) if p is not None]
    m = len(idx)
    q = [None] * len(pvals)
    if m == 0:
        return q
    order = sorted(idx, key=lambda i: pvals[i])
    prev = 1.0
    for rank in range(m, 0, -1):
        i = order[rank - 1]
        prev = min(prev, pvals[i] * m / rank)
        q[i] = prev
    return q


def r6(x):
    if x is None:
        return None
    if isinstance(x, float) and (math.isinf(x) or math.isnan(x)):
        return None if math.isnan(x) else ("inf" if x > 0 else "-inf")
    return round(float(x), 6)


# ======================================================================================
# Motor
# ======================================================================================
class NaturalExperiment:
    def __init__(self, cfg, corpus: p0.Corpus, audit: p0.Audit):
        self.cfg = cfg
        self.e = cfg["experiment"]
        self.c = corpus
        self.a = audit
        self.con = corpus.con
        self.rng = np.random.default_rng(self.e["seed"])
        self.out = {}

    # ---------------------------------------------------------------- unidad de análisis
    def build_units(self):
        con, e = self.con, self.e
        cut = e["cutoff_utc"]
        end = e["corpus_end_utc"] or str(self.a.t_max)
        self.end = pd.Timestamp(end)
        self.cut = pd.Timestamp(cut)
        start = e["window_start_utc"]
        ths = [100_000, 1_000_000, 10_000_000]
        prim = e["primary"]
        H = int(prim["horizon_hours"])
        horizons = sorted(set(e["robustness"]["horizons_hours"]) | {H})
        cat = {str(k).upper(): v for k, v in self.cfg["pair_catalog"].items()}
        stables = [str(s).upper() for s in self.cfg["quote"]["stablecoins"]]
        cat.setdefault("SOL", "SOL")
        for s_ in stables:
            cat.setdefault(s_, "STABLE")
        cat_sql = " ".join(f"WHEN t.quote_asset = {p0.lit(k)} THEN {p0.lit(v)}" for k, v in cat.items())
        self.catalog = cat

        # dev buy: compras del creador en los primeros N segundos (USD)
        dbw = int(e["dev_buy_window_seconds"])
        has_creator = self.c.is_mapped("tokens", "creator") and self.c.is_mapped("trades", "wallet")
        if has_creator:
            con.execute(f"""CREATE OR REPLACE TABLE ne_devbuy AS
                SELECT tr.mint, sum(tr.quote_amt * tr.quote_usd) AS dev_buy_usd
                FROM trades tr JOIN tokens t ON t.mint = tr.mint AND tr.wallet = t.creator
                WHERE tr.side = 'buy' AND tr.ts <= t.created_at + INTERVAL '{dbw} seconds'
                GROUP BY 1""")
            # historial del creador point-in-time (lanzamientos y graduaciones ANTERIORES a esta creación)
            con.execute("""CREATE OR REPLACE TABLE ne_creator AS
                WITH ev AS (
                  SELECT creator, created_at AS ts, 0 AS is_grad, mint FROM tokens WHERE creator IS NOT NULL
                  UNION ALL
                  SELECT t.creator, b.boundary_ts, 1, NULL FROM boundary b JOIN tokens t USING(mint)
                  WHERE t.creator IS NOT NULL AND b.boundary_ts IS NOT NULL),
                c AS (SELECT *, sum(1 - is_grad) OVER w AS cum_launch, sum(is_grad) OVER w AS cum_grad
                      FROM ev WINDOW w AS (PARTITION BY creator ORDER BY ts, is_grad DESC
                                           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW))
                SELECT mint, cum_launch - 1 AS prior_launches, cum_grad AS prior_grads FROM c WHERE is_grad = 0""")
        else:
            con.execute("CREATE OR REPLACE TABLE ne_devbuy (mint VARCHAR, dev_buy_usd DOUBLE)")
            con.execute("CREATE OR REPLACE TABLE ne_creator (mint VARCHAR, prior_launches BIGINT, prior_grads BIGINT)")
        # contexto de mercado al crear: lanzamientos 24h previas y retorno SOL 24h (ASOF)
        con.execute("""CREATE OR REPLACE TABLE ne_hourly AS
            WITH h AS (SELECT date_trunc('hour', created_at) AS hr, count(*) n FROM tokens GROUP BY 1)
            SELECT hr, sum(n) OVER (ORDER BY hr RANGE BETWEEN INTERVAL 24 HOUR PRECEDING AND INTERVAL 1 HOUR PRECEDING)
                   AS launches_prev_24h FROM h""")
        con.execute(f"""CREATE OR REPLACE TABLE ne_units AS
            WITH cr AS (
              SELECT mint,
                {', '.join(f"min(val_cross_ts) FILTER (WHERE threshold = {X}) AS val_{int(X)}" for X in ths)},
                {', '.join(f"min(raw_cross_ts) FILTER (WHERE threshold = {X}) AS raw_{int(X)}" for X in ths)}
              FROM crosses GROUP BY 1),
            base AS (
              SELECT t.mint, t.creator, t.created_at, t.quote_asset, t.fee_mode_norm AS fee_mode,
                COALESCE(CASE {cat_sql} END, 'UNCLASSIFIED') AS pair_type,
                CASE WHEN t.created_at < TIMESTAMP '{cut}' THEN 'PRE' ELSE 'POST' END AS regime,
                date_trunc('day', t.created_at) AS day,
                epoch(t.created_at - TIMESTAMP '{cut}') / 3600.0 AS hours_from_cutoff,
                extract('hour' FROM t.created_at) AS launch_hour,
                (t.twitter IS NOT NULL) AS has_x, (t.telegram IS NOT NULL) AS has_tg, (t.website IS NOT NULL) AS has_web,
                b.boundary_ts AS grad_ts, (b.boundary_ts IS NOT NULL) AS graduated,
                l.ath_mc, l.ath_class, q.Q_total
              FROM tokens t LEFT JOIN boundary b USING(mint) LEFT JOIN tok_label l USING(mint) LEFT JOIN tok_q q USING(mint)
              WHERE t.created_at IS NOT NULL {f"AND t.created_at >= TIMESTAMP '{start}'" if start else ""})
            SELECT base.*, cr.* EXCLUDE (mint),
              db.dev_buy_usd, COALESCE(ch.prior_launches, 0) AS prior_launches, COALESCE(ch.prior_grads, 0) AS prior_grads,
              COALESCE(hh.launches_prev_24h, 0) AS launches_prev_24h
            FROM base LEFT JOIN cr USING(mint) LEFT JOIN ne_devbuy db USING(mint) LEFT JOIN ne_creator ch USING(mint)
            LEFT JOIN ne_hourly hh ON hh.hr = date_trunc('hour', base.created_at)""")
        # precio del par AL CREAR (ASOF) y retorno SOL 24h
        stale = int(self.cfg["quote"]["max_staleness_seconds"])
        st = ",".join(p0.lit(s_) for s_ in stables) or "''"
        con.execute(f"""CREATE OR REPLACE TABLE ne_units AS
            SELECT u.*,
              CASE WHEN u.quote_asset IN ({st}) THEN 1.0
                   WHEN q.ts IS NOT NULL AND epoch(u.created_at - q.ts) <= {stale} THEN q.price_usd END AS pair_price_usd_at_creation
            FROM ne_units u ASOF LEFT JOIN quote_px q ON u.quote_asset = q.asset AND u.created_at >= q.ts""")
        con.execute("""CREATE OR REPLACE TABLE ne_units AS
            SELECT u.*, s1.price_usd / NULLIF(s0.price_usd, 0) - 1 AS sol_ret_24h
            FROM ne_units u
            ASOF LEFT JOIN (SELECT ts, price_usd FROM quote_px WHERE asset='SOL') s1 ON u.created_at >= s1.ts
            ASOF LEFT JOIN (SELECT ts, price_usd FROM quote_px WHERE asset='SOL') s0 ON u.created_at - INTERVAL 24 HOUR >= s0.ts""")
        df = con.execute("SELECT * FROM ne_units").fetchdf()
        for c in ["created_at", "grad_ts", "day"] + [f"{k}_{int(X)}" for k in ("val", "raw") for X in ths]:
            df[c] = pd.to_datetime(df[c])

        qmin = float(e["q_min"])
        df["valid_pair_price"] = df["pair_price_usd_at_creation"].notna()
        df["valid_fee_mode"] = df["fee_mode"].isin(["creator_fee", "holder_rewards", "cashback"])
        df["valid_quality"] = df["Q_total"].fillna(0) >= qmin
        df["valid_post_grad_obs"] = ~df["ath_class"].eq("unobservable_censored_at_migration")
        df["valid_pair_class"] = ~df["pair_type"].eq("UNCLASSIFIED")
        df["serial_creator"] = df["prior_launches"] >= int(e["serial_creator_min_prior"])
        for h in horizons:
            df[f"fu_{h}h"] = (df["created_at"] + pd.Timedelta(hours=h)) <= self.end
            for X in ths:
                for kind in ("val", "raw"):
                    col = f"{kind}_{int(X)}"
                    df[f"Y_{kind}{int(X)}_{h}h"] = df[col].notna() & ((df[col] - df["created_at"]) <= pd.Timedelta(hours=h))
            df[f"grad_{h}h"] = df["grad_ts"].notna() & ((df["grad_ts"] - df["created_at"]) <= pd.Timedelta(hours=h))
            # variante anclada en graduación (secundaria/descomposición)
            df[f"fu_grad_{h}h"] = df["grad_ts"].notna() & ((df["grad_ts"] + pd.Timedelta(hours=h)) <= self.end)
            col = f"val_{int(prim['threshold'])}"
            df[f"Yg_{h}h"] = df[col].notna() & ((df[col] - df["grad_ts"]) <= pd.Timedelta(hours=h))
        lab = "val" if prim["label"] == "validated" else "raw"
        self.Y = f"Y_{lab}{int(prim['threshold'])}_{H}h"
        self.FU = f"fu_{H}h"
        self.H = H
        self.ths = ths
        df["eligible_base"] = (df["valid_pair_price"] & df["valid_fee_mode"] & df["valid_quality"]
                               & df["valid_post_grad_obs"] & df[self.FU])
        self.df = df
        self.has_creator = has_creator

    # ---------------------------------------------------------------- A–H
    def audit_questions(self):
        df = self.df
        post = df["regime"].eq("POST")
        elig = df["eligible_base"]
        reasons = {
            "sin_precio_del_par": int((~df["valid_pair_price"]).sum()),
            "fee_mode_desconocido": int((~df["valid_fee_mode"]).sum()),
            "calidad_Q<q_min": int((~df["valid_quality"]).sum()),
            "graduado_sin_datos_post": int((~df["valid_post_grad_obs"]).sum()),
            f"seguimiento_<{self.H}h": int((~df[self.FU]).sum()),
            "par_no_catalogado": int((~df["valid_pair_class"]).sum()),
        }
        coex = (df[post & elig & df["pair_type"].isin(["SOL", "RWA"])]
                .groupby(["day", "pair_type", "fee_mode"]).agg(n=("mint", "size"), events=(self.Y, "sum"))
                .reset_index())
        piv = coex.pivot_table(index="day", columns=["pair_type", "fee_mode"], values="n", fill_value=0)
        both_fee_days = 0
        if ("SOL", "holder_rewards") in piv.columns or ("RWA", "holder_rewards") in piv.columns:
            hr = sum(piv[c] for c in piv.columns if c[1] == "holder_rewards")
            cf = sum(piv[c] for c in piv.columns if c[1] == "creator_fee")
            both_fee_days = int(((hr > 0) & (cf > 0)).sum()) if not isinstance(hr, int) and not isinstance(cf, int) else 0
        self.coex = coex
        self.out["audit_A_H"] = {
            "A_launches": int(len(df)),
            "A_launches_PRE_POST": {k: int(v) for k, v in df["regime"].value_counts().items()},
            "B_graduated": int(df["graduated"].sum()),
            "C_graduated_with_post_observation": int((df["graduated"] & df["valid_post_grad_obs"]).sum()),
            "D_reached_1M_validated (cualquier momento)": int(df["val_1000000"].notna().sum()),
            "D_reached_1M_raw": int(df["raw_1000000"].notna().sum()),
            "E_RWA_launches_POST": int((post & df["pair_type"].eq("RWA")).sum()),
            "E_pair_type_counts": {f"{k[0]}|{k[1]}": int(v) for k, v in df.groupby(["regime", "pair_type"]).size().items()},
            "F_holder_rewards_launches": int(df["fee_mode"].eq("holder_rewards").sum()),
            "F_fee_mode_counts": {f"{k[0]}|{k[1]}": int(v) for k, v in
                                  df.groupby(["regime", df["fee_mode"].fillna("NULL")]).size().items()},
            "G_POST_days_with_HR_and_CF_eligible": both_fee_days,
            "G_POST_days_with_full_followup": int(df.loc[post & df[self.FU], "day"].nunique()),
            "H_eligible_total": int(elig.sum()),
            "H_eligible_POST": int((elig & post).sum()),
            "exclusion_reasons (no excluyentes)": reasons,
            "corpus_end_used": str(self.end), "primary_horizon_hours": self.H,
            "last_creation_with_full_followup": str(self.end - pd.Timedelta(hours=self.H)),
        }

    # ---------------------------------------------------------------- descriptivo
    def cohort_summary(self):
        df = self.df
        rows = []
        P = int(self.e["primary"]["threshold"])
        for (reg, pt, fm), g in df.groupby(["regime", "pair_type", df["fee_mode"].fillna("NULL")]):
            el = g[g["eligible_base"]]
            ev = int(el[self.Y].sum())
            grad = int(el[f"grad_{self.H}h"].sum())
            ttg = (g["grad_ts"] - g["created_at"]).dt.total_seconds() / 60
            t100 = (g["val_100000"] - g["created_at"]).dt.total_seconds() / 3600
            t1m = (g[f"val_{P}"] - g["created_at"]).dt.total_seconds() / 3600
            rows.append({
                "regime": reg, "pair_type": pt, "fee_mode": fm, "N_launches": len(g), "N_eligible": len(el),
                "graduated_H": grad, "grad_rate": r6(grad / len(el)) if len(el) else None,
                "reached_100k_val": int(el[f"Y_val100000_{self.H}h"].sum()),
                "reached_1M_raw": int(el[f"Y_raw{P}_{self.H}h"].sum()), "reached_1M_val": ev,
                "rate_1M_per_launch": r6(ev / len(el)) if len(el) else None,
                "rate_1M_CI95": wilson(ev, len(el)),
                "rate_1M_given_grad": r6(ev / grad) if grad else None,
                "median_min_to_grad": r6(ttg.median()) if ttg.notna().any() else None,
                "median_h_to_100k": r6(t100.median()) if t100.notna().any() else None,
                "median_h_to_1M": r6(t1m.median()) if t1m.notna().any() else None,
                "median_dev_buy_usd": r6(g["dev_buy_usd"].median()) if g["dev_buy_usd"].notna().any() else None,
            })
        self.cohorts = pd.DataFrame(rows).sort_values(["regime", "pair_type", "fee_mode"])
        four = {}
        post = self.cohorts[self.cohorts["regime"] == "POST"]
        for pt, fm, name in GROUPS:
            r = post[(post["pair_type"] == pt) & (post["fee_mode"] == fm)]
            four[name] = (r.iloc[0][["N_launches", "N_eligible", "graduated_H", "reached_1M_val", "rate_1M_per_launch",
                                     "rate_1M_given_grad"]].to_dict() if len(r) else "N=0")
        self.out["four_groups_POST"] = four

    # ---------------------------------------------------------------- covariables de creación
    def design_matrix(self, d, drop_pair=False, drop_fee=False):
        cols = {}
        h = d["launch_hour"].astype(float)
        cols["hour_sin"] = np.sin(2 * np.pi * h / 24); cols["hour_cos"] = np.cos(2 * np.pi * h / 24)
        db = d["dev_buy_usd"]
        cols["log_dev_buy"] = np.log1p(db.fillna(0).clip(lower=0)); cols["dev_buy_missing"] = db.isna().astype(float)
        cols["log_prior_launches"] = np.log1p(d["prior_launches"].astype(float))
        cols["log_prior_grads"] = np.log1p(d["prior_grads"].astype(float))
        for f in ("has_x", "has_tg", "has_web"):
            cols[f] = d[f].astype(float)
        cols["log_launches_prev_24h"] = np.log1p(d["launches_prev_24h"].astype(float))
        cols["sol_ret_24h"] = d["sol_ret_24h"].fillna(0).astype(float)
        X = pd.DataFrame(cols, index=d.index)
        dd = pd.get_dummies(d["day"].dt.strftime("%m%d"), prefix="day", drop_first=True, dtype=float)
        X = pd.concat([X, dd], axis=1)
        if not drop_pair:
            X = pd.concat([X, pd.get_dummies(d["pair_type"], prefix="pair", drop_first=True, dtype=float)], axis=1)
        if not drop_fee:
            X = pd.concat([X, pd.get_dummies(d["fee_mode"], prefix="fee", drop_first=True, dtype=float)], axis=1)
        X = X.loc[:, X.std() > 0]
        return X

    def iptw(self, d, treat, y, strata_col):
        """Propensión con covariables de creación; OR ponderado + bootstrap estratificado + balance."""
        e = self.e
        # el tratamiento NUNCA es covariable: H_FEE (estratos=pair_type) quita fee; H_RWA (estratos=fee_mode) quita par
        X = self.design_matrix(d, drop_pair=(strata_col == "fee_mode"), drop_fee=(strata_col == "pair_type"))
        tvec = d[treat].astype(float)
        leak = [c for c in X.columns if abs(np.corrcoef(X[c], tvec)[0, 1]) > 0.999]
        X = X.drop(columns=leak)
        mu, sd = X.mean(), X.std().replace(0, 1)
        Z = ((X - mu) / sd).to_numpy()
        tr = d[treat].to_numpy(bool).astype(float)
        yy = d[y].to_numpy(bool).astype(float)
        lo, hi = e["propensity_clip"]

        def est(Zb, trb, yb):
            beta = logit_fit(Zb, trb, l2=1.0)
            ps = np.clip(predict(beta, Zb), lo, hi)
            w = np.where(trb == 1, 1 / ps, 1 / (1 - ps))
            p1 = (w * yb * trb).sum() / (w * trb).sum(); p0_ = (w * yb * (1 - trb)).sum() / (w * (1 - trb)).sum()
            orr = (p1 / (1 - p1)) / (p0_ / (1 - p0_)) if 0 < p1 < 1 and 0 < p0_ < 1 else np.nan
            return orr, p1, p0_, ps, w

        orr, p1, p0_, ps, w = est(Z, tr, yy)
        # balance (SMD) antes / después
        def smd(wv):
            out = {}
            for j, c in enumerate(X.columns):
                if c.startswith("day_"):
                    continue
                x = Z[:, j]
                m1 = np.average(x[tr == 1], weights=wv[tr == 1]); m0 = np.average(x[tr == 0], weights=wv[tr == 0])
                v1 = np.average((x[tr == 1] - m1) ** 2, weights=wv[tr == 1]); v0 = np.average((x[tr == 0] - m0) ** 2, weights=wv[tr == 0])
                s = math.sqrt((v1 + v0) / 2) or 1.0
                out[c] = round(float((m1 - m0) / s), 4)
            return out
        smd_before = smd(np.ones_like(w)); smd_after = smd(w)
        ess = lambda ww: float(ww.sum() ** 2 / (ww ** 2).sum())
        # bootstrap estratificado por día
        boots = []
        days = d["day"].to_numpy()
        idx_by_day = [np.flatnonzero(days == dd) for dd in np.unique(days)]
        for _ in range(int(e["n_bootstrap"])):
            ii = np.concatenate([self.rng.choice(ix, size=len(ix), replace=True) for ix in idx_by_day])
            if tr[ii].sum() == 0 or (1 - tr[ii]).sum() == 0:
                continue
            o, *_ = est(Z[ii], tr[ii], yy[ii])
            if np.isfinite(o) and o > 0:
                boots.append(math.log(o))
        ci = [math.exp(np.percentile(boots, 2.5)), math.exp(np.percentile(boots, 97.5))] if len(boots) >= 50 else None
        return {
            "or": r6(orr) if np.isfinite(orr) else None, "ci95_bootstrap": [r6(x) for x in ci] if ci else None,
            "weighted_rate_treated": r6(p1), "weighted_rate_control": r6(p0_),
            "n_bootstrap_ok": len(boots),
            "overlap_share_ps_in_[0.05,0.95]": r6(float(((ps > 0.05) & (ps < 0.95)).mean())),
            "ess_treated": r6(ess(w[tr == 1])), "ess_control": r6(ess(w[tr == 0])),
            "max_abs_smd_before": r6(max(abs(v) for v in smd_before.values())) if smd_before else None,
            "max_abs_smd_after": r6(max(abs(v) for v in smd_after.values())) if smd_after else None,
            "smd_after": smd_after,
            "covariates": [c for c in X.columns if not c.startswith("day_")] + ["day fixed effects"],
            "dropped_as_treatment_proxy": leak,
        }

    # ---------------------------------------------------------------- contraste genérico
    def contrast(self, d, treat, y, strata_cols, n_perm, with_iptw=True, iptw_strata=None):
        e = self.e
        d = d.copy()
        d["_stratum"] = d[strata_cols].astype(str).agg("|".join, axis=1)
        t = strata_table(d, treat, y, "_stratum")
        informative = t[(t["n_t"] > 0) & (t["n_c"] > 0)]
        dd = d[d["_stratum"].isin(informative.index)]
        n_t, n_c = int(dd[treat].sum()), int((~dd[treat]).sum())
        e_t, e_c = int((dd[treat] & dd[y]).sum()), int((~dd[treat] & dd[y]).sum())
        mh = mh_or(informative) if len(informative) else {"or": None, "ci": None}
        pperm = perm_test_strata(informative, n_perm, self.rng) if len(informative) else None
        p0r = e_c / n_c if n_c else 0.0
        mde = mde_or(n_t, n_c, p0r, e["alpha"], e["power"]["target"]) if n_c and n_t else None
        pw = e["power"]
        adequate = (e_t + e_c >= pw["min_events_total"] and e_t >= pw["min_events_per_arm"]
                    and e_c >= pw["min_events_per_arm"] and mde is not None and mde <= pw["mde_or_max"])
        res = {
            "N_treatment": n_t, "N_control": n_c, "N_success_treatment": e_t, "N_success_control": e_c,
            "N_effective": n_t + n_c,
            "strata_informative": int(len(informative)), "strata_dropped_single_arm": int(len(t) - len(informative)),
            "rows_dropped_single_arm": int(len(d) - len(dd)),
            "rate_treatment": r6(e_t / n_t) if n_t else None, "rate_control": r6(p0r) if n_c else None,
            "crude_or": r6((e_t / (n_t - e_t)) / (e_c / (n_c - e_c))) if n_t and n_c and e_c and e_t and n_t > e_t and n_c > e_c else None,
            "mh_or": r6(mh["or"]) if isinstance(mh["or"], float) else mh["or"],
            "mh_ci95": [r6(x) for x in mh["ci"]] if mh.get("ci") else None,
            "permutation_p": r6(pperm),
            "mde_or_80pct": r6(mde), "power": "adequate" if adequate else "inadequate",
        }
        if with_iptw and e_t + e_c >= 5 and n_t >= 10 and n_c >= 10:
            try:
                res["iptw"] = self.iptw(dd, treat, y, iptw_strata)
            except np.linalg.LinAlgError as ex:
                res["iptw"] = {"error": str(ex)}
        return res, informative

    # ---------------------------------------------------------------- hipótesis
    def hypotheses(self):
        df, e = self.df, self.e
        post = df[df["regime"].eq("POST") & df["eligible_base"]]
        n_perm = int(e["n_permutations"])
        # H-FEE: HR vs CF, estratos día × tipo de par (SOL y RWA)
        dfee = post[post["fee_mode"].isin(["holder_rewards", "creator_fee"]) & post["pair_type"].isin(["SOL", "RWA"])].copy()
        dfee["T"] = dfee["fee_mode"].eq("holder_rewards")
        h_fee, _ = self.contrast(dfee, "T", self.Y, ["day", "pair_type"], n_perm, iptw_strata="pair_type")
        # H-RWA: RWA vs SOL, estratos día × fee
        drwa = post[post["fee_mode"].isin(["holder_rewards", "creator_fee"]) & post["pair_type"].isin(["SOL", "RWA"])].copy()
        drwa["T"] = drwa["pair_type"].eq("RWA")
        h_rwa, _ = self.contrast(drwa, "T", self.Y, ["day", "fee_mode"], n_perm, iptw_strata="fee_mode")
        # H-INT: efecto HR en RWA vs efecto HR en SOL
        r_rwa, t_rwa = self.contrast(dfee[dfee["pair_type"].eq("RWA")], "T", self.Y, ["day"], n_perm, with_iptw=False)
        r_sol, t_sol = self.contrast(dfee[dfee["pair_type"].eq("SOL")], "T", self.Y, ["day"], n_perm, with_iptw=False)
        m1, m2 = (mh_or(t_rwa) if len(t_rwa) else {"log_or": None}), (mh_or(t_sol) if len(t_sol) else {"log_or": None})
        if m1.get("log_or") is not None and m2.get("log_or") is not None:
            lr = m1["log_or"] - m2["log_or"]; se = math.sqrt(m1["se"] ** 2 + m2["se"] ** 2)
            ratio = {"or_ratio": r6(math.exp(lr)), "ci95": [r6(math.exp(lr - 1.96 * se)), r6(math.exp(lr + 1.96 * se))]}
            pint = perm_interaction(t_rwa, t_sol, n_perm, self.rng)
        else:
            ratio, pint = {"or_ratio": None, "ci95": None}, None
        pw = e["power"]
        int_adequate = all(r["power"] == "adequate" for r in (r_rwa, r_sol))
        h_int = {"HR_effect_in_RWA": r_rwa, "HR_effect_in_SOL": r_sol, **ratio, "permutation_p": r6(pint),
                 "power": "adequate" if int_adequate else "inadequate",
                 "note": "Interacción = OR_HR|RWA / OR_HR|SOL. Requiere potencia en AMBAS subpoblaciones."}
        # Secundaria: anclada en graduación (descomposición, condiciona a variable post-tratamiento)
        dg = dfee[dfee[f"fu_grad_{self.H}h"]].copy()
        h_fee_grad, _ = self.contrast(dg, "T", f"Yg_{self.H}h", ["day", "pair_type"], n_perm, with_iptw=False)
        h_fee_gradprob, _ = self.contrast(dfee, "T", f"grad_{self.H}h", ["day", "pair_type"], n_perm, with_iptw=False)
        self.hyp = {"H_FEE": h_fee, "H_RWA": h_rwa, "H_INT": h_int,
                    "H_FEE_decomposition": {
                        "P(graduate within H)": h_fee_gradprob,
                        "P(1M within H after graduation | graduated) [condiciona a post-tratamiento]": h_fee_grad}}
        self.dfee = dfee

    # ---------------------------------------------------------------- event study + placebo
    def event_study(self):
        df, es = self.df, self.e["event_study"]
        d = df[df["eligible_base"]].copy()
        d["rel_day"] = np.floor((d["created_at"] - self.cut).dt.total_seconds() / 86400).astype(int)
        rows = []
        for rd, g in d.groupby("rel_day"):
            if rd < -int(es["days_before"]):
                continue
            k, n = int(g[self.Y].sum()), len(g)
            sc = g[g["pair_type"].eq("SOL") & g["fee_mode"].eq("creator_fee")]
            rows.append({"rel_day": rd, "N_eligible": n, "events": k, "rate": r6(k / n), "rate_CI95": wilson(k, n),
                         "grad_rate": r6(g[f"grad_{self.H}h"].mean()),
                         "N_SOL_CF": len(sc), "rate_SOL_CF": r6(sc[self.Y].mean()) if len(sc) else None,
                         "share_HR": r6(g["fee_mode"].eq("holder_rewards").mean()),
                         "share_RWA": r6(g["pair_type"].eq("RWA").mean())})
        self.es_rows = pd.DataFrame(rows)

        def window_diff(c, k, sub=None):
            dd = d if sub is None else d[sub(d)]
            pre = dd[(dd["created_at"] >= c - pd.Timedelta(days=k)) & (dd["created_at"] < c)]
            pos = dd[(dd["created_at"] >= c) & (dd["created_at"] < c + pd.Timedelta(days=k))]
            if len(pre) == 0 or len(pos) == 0:
                return None
            r0, r1 = pre[self.Y].mean(), pos[self.Y].mean()
            days_post = pos["day"].nunique()
            return {"N_pre": len(pre), "N_post": len(pos), "events_pre": int(pre[self.Y].sum()),
                    "events_post": int(pos[self.Y].sum()), "rate_pre": r6(r0), "rate_post": r6(r1),
                    "diff": r6(r1 - r0), "post_days_available": int(days_post), "truncated": bool(days_post < k)}

        windows = {}
        for k in es["windows_days"]:
            windows[f"±{k}d"] = {"all": window_diff(self.cut, k),
                                 "SOL+CreatorFee only (grupo sin cambio de mecanismo)":
                                     window_diff(self.cut, k, lambda x: x["pair_type"].eq("SOL") & x["fee_mode"].eq("creator_fee"))}
        # placebos: cortes falsos con ventana ±k totalmente en PRE
        k = int(es["primary_window_days"])
        obs = window_diff(self.cut, k)
        start = d["created_at"].min().normalize()
        cands = pd.date_range(start + pd.Timedelta(days=k), self.cut - pd.Timedelta(days=k), freq="D")
        pl = []
        for c in cands:
            r = window_diff(c, k)
            if r is not None and r["N_pre"] > 0 and r["N_post"] > 0:
                pl.append({"fake_cutoff": str(c.date()), **r})
        self.placebo = pd.DataFrame(pl)
        if obs is None or obs["diff"] is None:
            status, pr = "NO_DATA", None
        elif len(pl) < int(es["placebo_min"]):
            status, pr = f"INSUFFICIENT_PLACEBOS ({len(pl)} < {es['placebo_min']})", None
        else:
            diffs = np.abs(self.placebo["diff"].astype(float).to_numpy())
            pr = float((1 + np.sum(diffs >= abs(obs["diff"]))) / (1 + len(diffs)))
            status = "PASSED (el corte real destaca sobre los falsos)" if pr <= self.e["alpha"] else \
                "FAILED (fechas falsas producen cambios igual de grandes: ruido/régimen)"
        self.out["event_study"] = {
            "what_it_measures": "cambio de plataforma en la tasa global (no el efecto del fee mode)",
            "windows": windows, "primary_window_days": k, "observed": obs,
            "placebo": {"n": len(pl), "rank_p": r6(pr), "status": status},
        }

    # ---------------------------------------------------------------- robustez (H-FEE)
    def robustness(self):
        e, rb = self.e, self.e["robustness"]
        df = self.df
        base = self.hyp["H_FEE"]
        n_perm = int(rb["n_permutations"])
        rows = []

        def run(name, d, y):
            if len(d) == 0:
                return
            r, _ = self.contrast(d, "T", y, ["day", "pair_type"], n_perm, with_iptw=False)
            rows.append({"variant": name, "N": r["N_effective"], "events_T": r["N_success_treatment"],
                         "events_C": r["N_success_control"], "mh_or": r["mh_or"],
                         "ci_lo": r["mh_ci95"][0] if r["mh_ci95"] else None,
                         "ci_hi": r["mh_ci95"][1] if r["mh_ci95"] else None, "perm_p": r["permutation_p"],
                         "power": r["power"]})

        def pool(h):
            d = df[df["regime"].eq("POST") & df["valid_pair_price"] & df["valid_fee_mode"] & df["valid_quality"]
                   & df["valid_post_grad_obs"] & df[f"fu_{h}h"] & df["fee_mode"].isin(["holder_rewards", "creator_fee"])
                   & df["pair_type"].isin(["SOL", "RWA"])].copy()
            d["T"] = d["fee_mode"].eq("holder_rewards")
            return d

        P = int(e["primary"]["threshold"])
        run("PRIMARY", self.dfee, self.Y)
        for k in rb["windows_days_post"]:
            d = self.dfee[self.dfee["created_at"] < self.cut + pd.Timedelta(days=k)]
            run(f"window_first_{k}d_post", d, self.Y)
        for h in rb["horizons_hours"]:
            if h != self.H:
                run(f"horizon_{h}h", pool(h), f"Y_val{P}_{h}h")
        run("label_1M_raw", self.dfee, f"Y_raw{P}_{self.H}h")
        run("label_10M_val", self.dfee, f"Y_val10000000_{self.H}h")
        run("label_100k_val", self.dfee, f"Y_val100000_{self.H}h")
        winners = self.dfee[self.dfee[self.Y]].sort_values("ath_mc", ascending=False)["mint"].tolist()
        for kx in rb["drop_top"]:
            run(f"drop_top{kx}_winners", self.dfee[~self.dfee["mint"].isin(winners[:kx])], self.Y)
        run("exclude_serial_creators", self.dfee[~self.dfee["serial_creator"]], self.Y)
        sr = self.dfee["sol_ret_24h"]
        if sr.notna().sum() > 30:
            q1, q2 = sr.quantile([1 / 3, 2 / 3])
            run("SOL_regime_DOWN", self.dfee[sr <= q1], self.Y)
            run("SOL_regime_FLAT", self.dfee[(sr > q1) & (sr <= q2)], self.Y)
            run("SOL_regime_UP", self.dfee[sr > q2], self.Y)
        self.rob = pd.DataFrame(rows)
        # regla pre-registrada
        prim = base.get("mh_or")
        passed, why = True, []
        if not isinstance(prim, (int, float)) or prim is None:
            passed, why = False, ["sin OR primario"]
        else:
            sign = 1 if prim > 1 else -1
            for _, r in self.rob.iterrows():
                if r["variant"] == "PRIMARY" or not isinstance(r["mh_or"], (int, float)):
                    continue
                enough = (r["events_T"] + r["events_C"]) >= e["power"]["min_events_total"]
                if not enough:
                    continue
                s = 1 if r["mh_or"] > 1 else -1
                if s != sign:
                    passed = False; why.append(f"{r['variant']}: cambia de signo (OR {r['mh_or']})")
                if r["variant"].startswith("SOL_regime") and r["ci_lo"] is not None and \
                        ((sign > 0 and r["ci_hi"] < 1) or (sign < 0 and r["ci_lo"] > 1)):
                    passed = False; why.append(f"{r['variant']}: efecto opuesto significativo")
            dt5 = self.rob[self.rob["variant"] == "drop_top5_winners"]
            if len(dt5) and (dt5.iloc[0]["perm_p"] is None or dt5.iloc[0]["perm_p"] > e["alpha"]):
                passed = False; why.append("sin top-5 ganadores deja de ser significativo")
        self.out["robustness"] = {"status": "passed" if passed else "failed", "reasons": why,
                                  "rule": "mismo signo en todas las variantes con >=min eventos; ningún régimen SOL "
                                          "con efecto opuesto significativo; sigue p<alpha sin top-5 ganadores"}

    # ---------------------------------------------------------------- veredictos
    def verdicts(self, p0_report):
        e = self.e
        alpha = e["alpha"]
        gate = []
        if p0_report["DECISION"] == "DATA_FAIL":
            gate.append("Fase 0.2 = DATA_FAIL: " + "; ".join(p0_report["decision_reasons"]))
        if p0_report["post_migration"]["status"] in ("FAIL", "UNKNOWN", "PARTIAL_NO_GLOBAL_CLAIMS"):
            gate.append(f"post-migración {p0_report['post_migration']['status']}: $1M no observable honestamente")

        # multiplicidad: primaria sin corrección; secundarias BH
        sec_names = ["H_RWA", "H_INT", "EVENT_STUDY_placebo"]
        sec_p = [self.hyp["H_RWA"]["permutation_p"], self.hyp["H_INT"]["permutation_p"],
                 self.out["event_study"]["placebo"]["rank_p"]]
        qv = bh(sec_p)
        self.out["multiplicity"] = {
            "primary": "H_FEE sobre outcome primario (sin corrección, alpha=%.2f)" % alpha,
            "secondary_BH": {n: {"p": r6(p), "q_BH": r6(q)} for n, p, q in zip(sec_names, sec_p, qv)},
            "exploratory_uncorrected": "robustez y descomposición: solo descriptivas",
        }

        def judge(h, p_used, is_primary):
            reasons = []
            if gate:
                return "INSUFFICIENT_DATA", gate
            if h.get("power") != "adequate":
                return "INSUFFICIENT_DATA", [f"potencia insuficiente (eventos T/C = {h.get('N_success_treatment')}/"
                                             f"{h.get('N_success_control')}, MDE OR {h.get('mde_or_80pct')})"]
            sig = p_used is not None and p_used < alpha
            ci = h.get("mh_ci95") or h.get("ci95")
            ci_ok = ci is not None and ci[0] is not None and (ci[0] > 1 or ci[1] < 1)
            ok = sig and ci_ok
            if not sig:
                reasons.append(f"p={p_used} >= {alpha}")
            if not ci_ok:
                reasons.append("IC MH incluye 1")
            ip = h.get("iptw")
            if ok and ip is not None:
                ici = ip.get("ci95_bootstrap")
                same = ici is not None and ((h["mh_or"] > 1 and ici[0] > 1) or (h["mh_or"] < 1 and ici[1] < 1))
                if not same:
                    ok = False; reasons.append("tras IPTW el IC incluye 1 o cambia de signo (autoselección)")
                if (ip.get("max_abs_smd_after") or 0) > e["balance_smd_max"]:
                    ok = False; reasons.append(f"balance insuficiente tras IPTW (SMD {ip.get('max_abs_smd_after')})")
            if ok and is_primary and self.out["robustness"]["status"] != "passed":
                ok = False; reasons.append("robustez fallida: " + "; ".join(self.out["robustness"]["reasons"]))
            return ("SIGNAL" if ok else "NO_SIGNAL"), reasons or ["cumple todos los criterios pre-registrados"]

        v = {}
        v["H_FEE"] = judge(self.hyp["H_FEE"], self.hyp["H_FEE"]["permutation_p"], True)
        v["H_RWA"] = judge(self.hyp["H_RWA"], qv[0], False)
        hi = dict(self.hyp["H_INT"]); hi["mh_or"] = hi.get("or_ratio")
        v["H_INT"] = judge(hi, qv[1], False)
        self.out["verdicts"] = {k: {"status": s, "reasons": r} for k, (s, r) in v.items()}
        self.out["STATUS"] = v["H_FEE"][0]

    # ---------------------------------------------------------------- run
    def run(self, p0_report):
        steps = [("units", self.build_units), ("audit_A_H", self.audit_questions), ("cohorts", self.cohort_summary),
                 ("hypotheses", self.hypotheses), ("event_study", self.event_study), ("robustness", self.robustness)]
        for name, fn in steps:
            print(f"  · {name} ...", file=sys.stderr, flush=True)
            fn()
        self.verdicts(p0_report)
        self.out["hypotheses"] = self.hyp
        self.out["pair_catalog_used"] = self.catalog
        self.out["preregistration"] = {
            "primary_outcome": f"cruce {'validado' if self.e['primary']['label']=='validated' else 'raw'} de "
                               f"${int(self.e['primary']['threshold']):,} dentro de {self.H}h desde la creación",
            "population": "lanzamientos POST elegibles (precio del par, fee conocido, Q, seguimiento completo)",
            "estimator": "MH estratificado por día×(par|fee) + permutación exacta condicional; IPTW como ajuste",
            "covariates_rejected_post_treatment": ["volumen inicial", "holders iniciales", "primeras operaciones",
                                                   "actividad posterior", "ATH", "viralidad"],
            "cutoff": str(self.cut),
        }
        return self.out


# ======================================================================================
# Informe humano
# ======================================================================================
def fmt_rate(x):
    return "—" if x is None else f"{100 * x:.3f}%"


def write_human(o, path):
    L = []
    bar = "=" * 57
    L += [bar, "MOONSHOT NATURAL EXPERIMENT v0.3 — corte Pump.fun", bar, ""]
    a = o["audit_A_H"]
    L += [f"CUT: {o['preregistration']['cutoff']}   ·   fin de corpus: {a['corpus_end_used']}",
          f"Último lanzamiento con seguimiento completo ({a['primary_horizon_hours']}h): {a['last_creation_with_full_followup']}",
          "", f"N launches:   {a['A_launches']:,}   {a['A_launches_PRE_POST']}",
          f"N graduated:  {a['B_graduated']:,}   (con datos post: {a['C_graduated_with_post_observation']:,})",
          f"N 1M (val):   {a['D_reached_1M_validated (cualquier momento)']:,}   (raw {a['D_reached_1M_raw']:,})",
          f"N effective:  {a['H_eligible_total']:,}   (POST {a['H_eligible_POST']:,})",
          f"Días POST con HR y CF elegibles: {a['G_POST_days_with_HR_and_CF_eligible']}",
          f"Exclusiones: {a['exclusion_reasons (no excluyentes)']}", "",
          f"PRIMARY OUTCOME: {o['preregistration']['primary_outcome']}", ""]
    for name, g in o["four_groups_POST"].items():
        if isinstance(g, str):
            L.append(f"{name:22s} N = 0")
        else:
            L.append(f"{name:22s} N_elig = {g['N_eligible']:>7,}   1M = {g['reached_1M_val']:>4}   "
                     f"rate = {fmt_rate(g['rate_1M_per_launch'])}   |grad = {fmt_rate(g['rate_1M_given_grad'])}")
    L.append("")

    def block(title, h, key_or="mh_or", key_ci="mh_ci95"):
        L.append(title)
        if "N_treatment" in h:
            L.append(f"  N T/C = {h['N_treatment']:,}/{h['N_control']:,}   eventos T/C = {h['N_success_treatment']}/{h['N_success_control']}")
        L.append(f"  MH OR (día-estratificado) = {h.get(key_or)}   95% CI = {h.get(key_ci)}")
        L.append(f"  permutation p = {h.get('permutation_p')}   MDE OR = {h.get('mde_or_80pct', '—')}   potencia: {h.get('power')}")
        ip = h.get("iptw")
        if ip and "or" in ip:
            L.append(f"  IPTW OR = {ip['or']}   95% CI boot = {ip['ci95_bootstrap']}   SMD máx antes/después = "
                     f"{ip['max_abs_smd_before']}/{ip['max_abs_smd_after']}")
        L.append("")
    block("HOLDER EFFECT (H_FEE · primaria)", o["hypotheses"]["H_FEE"])
    block("RWA EFFECT (H_RWA · secundaria)", o["hypotheses"]["H_RWA"])
    hi = o["hypotheses"]["H_INT"]
    L += ["INTERACTION Holder × RWA (H_INT · secundaria)",
          f"  OR_HR|RWA / OR_HR|SOL = {hi['or_ratio']}   95% CI = {hi['ci95']}   permutation p = {hi['permutation_p']}   potencia: {hi['power']}", ""]
    m = o["multiplicity"]["secondary_BH"]
    L.append("BH (secundarias): " + ", ".join(f"{k}: q={v['q_BH']}" for k, v in m.items()))
    es = o["event_study"]
    L += ["", f"EVENT STUDY ±{es['primary_window_days']}d: {es['observed']}",
          f"PLACEBO: {es['placebo']['status']}  (n={es['placebo']['n']}, rank p={es['placebo']['rank_p']})",
          f"ROBUSTNESS: {o['robustness']['status']}  {o['robustness']['reasons']}", ""]
    for k, v in o["verdicts"].items():
        L.append(f"{k:6s} → {v['status']:18s} {'; '.join(v['reasons'])}")
    L += ["", f"STATUS: {o['STATUS']}", bar]
    with open(path, "w") as f:
        f.write("\n".join(L) + "\n")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(description="H-100M Fase 0.3 — natural experiment (corte 12-sep)")
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", default="ne_out")
    ap.add_argument("--memory-limit", default=None)
    ap.add_argument("--threads", type=int, default=None)
    ap.add_argument("--keep-db", action="store_true")
    args = ap.parse_args()
    with open(args.config) as f:
        user = json.load(f)
    cfg = p0.deep_merge(p0.deep_merge(p0.DEFAULTS, NE_DEFAULTS), user)
    os.makedirs(args.out, exist_ok=True)
    db = os.path.join(args.out, "ne.duckdb")
    con = duckdb.connect(db)
    con.execute("SET TimeZone='UTC'")
    con.execute(f"SET temp_directory={p0.lit(os.path.join(args.out, 'duckdb_tmp'))}")
    if args.memory_limit:
        con.execute(f"SET memory_limit={p0.lit(args.memory_limit)}")
    if args.threads:
        con.execute(f"SET threads={int(args.threads)}")
    t0 = time.time()
    corpus = p0.Corpus(cfg, con)
    corpus.validate_mapping()
    for need in ("fee_mode", "quote_asset"):
        if not corpus.cfg["tables"]["tokens"].get("columns", {}).get(need):
            print(f"AVISO: tokens.{need} no mapeado -> "
                  + ("todos los tokens tendrán fee desconocido: H_FEE no evaluable" if need == "fee_mode"
                     else "todos los pares = SOL: H_RWA no evaluable"), file=sys.stderr)
    print("Nivel A · cargando y auditando ...", file=sys.stderr)
    corpus.load()
    audit = p0.Audit(cfg, corpus)
    r0 = audit.run()
    r0["notes"] = corpus.notes
    r0["_config"] = cfg
    r0 = p0.to_jsonable(r0)
    with open(os.path.join(args.out, "phase0_report.json"), "w") as f:
        json.dump(r0, f, indent=2, ensure_ascii=False)
    p0.write_md(r0, os.path.join(args.out, "phase0_report.md"))
    print("Nivel B · experimento natural ...", file=sys.stderr)
    ne = NaturalExperiment(cfg, corpus, audit)
    o = ne.run(r0)
    o["_meta"] = {"version": VERSION, "run_utc": datetime.now(timezone.utc).isoformat(),
                  "elapsed_s": round(time.time() - t0, 1), "phase0_decision": r0["DECISION"]}
    o["_config_experiment"] = cfg["experiment"]
    o = p0.to_jsonable(o)
    with open(os.path.join(args.out, "natural_experiment.json"), "w") as f:
        json.dump(o, f, indent=2, ensure_ascii=False)
    ne.cohorts.to_csv(os.path.join(args.out, "cohort_summary.csv"), index=False)
    ne.es_rows.to_csv(os.path.join(args.out, "event_study.csv"), index=False)
    ne.placebo.to_csv(os.path.join(args.out, "placebo_results.csv"), index=False)
    ne.rob.to_csv(os.path.join(args.out, "robustness.csv"), index=False)
    ne.coex.to_csv(os.path.join(args.out, "daily_coexistence.csv"), index=False)
    flat = pd.DataFrame([{"hypothesis": k, **{kk: vv for kk, vv in v.items() if not isinstance(vv, (dict, list))}}
                         for k, v in o["hypotheses"].items() if isinstance(v, dict) and "N_treatment" in v])
    flat.to_csv(os.path.join(args.out, "natural_experiment.csv"), index=False)
    ne.df.to_parquet(os.path.join(args.out, "ne_tokens.parquet"), index=False)
    txt = write_human(o, os.path.join(args.out, "natural_experiment.txt"))
    con.close()
    if not args.keep_db:
        for f_ in (db, db + ".wal"):
            if os.path.exists(f_):
                os.remove(f_)
    print("\n" + txt)


if __name__ == "__main__":
    main()

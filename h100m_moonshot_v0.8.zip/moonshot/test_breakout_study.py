import json
from pathlib import Path
import pandas as pd
import numpy as np
import breakout_study as bs


def make_case(out: Path):
    start = pd.Timestamp('2026-01-01', tz='UTC')
    rows=[]; trades=[]
    cases={
        'WIN': [400000, 400000, 8000, 9000],
        'DEAD': [300000, 300000, 7000, 7000],
        'FLAT_NOT_LONG': [300000, 300000, 7000, 10000],
    }
    # 1-min observations. Winner: 0-1h ATH, 1h-2h crash, 24h base, 6h reactivation, 10x/30x later.
    for mint, vals in cases.items():
        ts=[]; mc=[]; holders=[]
        for i in range(1800):
            t=start+pd.Timedelta(minutes=i)
            if mint=='WIN':
                if i<30: m=400000 + i*2000
                elif i<120: m=400000 - (i-30)*4200
                elif i<1560: m=7000 + 1000*np.sin(i/30)
                elif i<1650: m=7000 + (i-1560)*150
                else: m=20500 + (i-1650)*110000
                h=10 + (i-1500)*0.15 if i>=1500 else 10
            elif mint=='DEAD':
                if i<30: m=300000+i*2000
                elif i<120: m=300000-(i-30)*3900
                else: m=7000+300*np.sin(i/10)
                h=10
            else:
                if i<30: m=300000+i*2000
                elif i<120: m=300000-(i-30)*3900
                elif i<240: m=7000+300*np.sin(i/10)
                else: m=10000
                h=10
            ts.append(t); mc.append(max(m, 1000)); holders.append(h)
        rows += [{'mint':mint,'ts':t,'mc_usd':m,'holders':h} for t,m,h in zip(ts,mc,holders)]
        if mint=='WIN':
            for i in range(1500,1800,30):
                t=start+pd.Timedelta(minutes=i)
                n=2 if i<1590 else 6
                for j in range(n):
                    trades.append({'mint':mint,'ts':t+pd.Timedelta(seconds=j),'wallet':f'w{i}_{j}', 'side':'buy','quote_amount':100+i})
            # previous window intentionally almost empty
            for i in [1100]:
                trades.append({'mint':mint,'ts':start+pd.Timedelta(minutes=i), 'wallet':'old','side':'buy','quote_amount':10})
    snap=pd.DataFrame(rows); tr=pd.DataFrame(trades)
    sp=out/'snapshots.csv'; tp=out/'trades.csv'
    snap.to_csv(sp,index=False); tr.to_csv(tp,index=False)
    return sp,tp


def main():
    root=Path('/tmp/breakout_test'); root.mkdir(exist_ok=True)
    sp,tp=make_case(root)
    cfg=json.loads(json.dumps(bs.DEFAULT_CONFIG))
    cfg['preregistration_id']='TEST_FIXED'
    cfg['base']['min_duration_hours']=6.0
    cfg['floor']['stable_window_hours']=2.0
    cfg['floor']['max_range_pct']=0.50
    cfg['reactivation']['window_hours']=1.0
    cfg['reactivation']['volume_ratio']=2.0
    cfg['acceleration']['window_hours']=1.0
    cfg['acceleration']['holder_slope_ratio']=1.2
    cfg['acceleration']['buyer_rate_ratio']=1.2
    cfg['outcomes']['horizons_hours']=[24.0,48.0]
    result=bs.run(str(sp),str(tp),str(root/'out'),cfg)
    assert result['leakage_audit']['status']=='PASS', result
    lp=root/'out'/'breakout_levels.parquet'
    levels=pd.read_parquet(lp) if lp.exists() else pd.read_csv(root/'out'/'breakout_levels.csv')
    assert {'N0','N1','N2','N3','N4'}.issubset(set(levels.level)), levels.level.unique()
    n4=levels[levels.level=='N4']
    assert (n4.time_to_2x_hours.notna()).any(), n4
    print('BREAKOUT STUDY TEST: PASS')
    print(levels[['mint','level','signal_time','signal_mc_usd','time_to_2x_hours','time_to_10x_hours']].to_string(index=False))

if __name__=='__main__': main()

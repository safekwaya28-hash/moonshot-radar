#!/usr/bin/env python3
"""
Test end-to-end de scan.py con una cadena Solana simulada (RPC falso) y verdad conocida.
  python test_scan.py
"""
import base64
import io
import json
import os
import random
import shutil
import struct
import sys
import tempfile
import time
from contextlib import redirect_stdout

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pump_discovery as pdsc  # noqa: E402
import scan  # noqa: E402

FAILS = []
DISC = pdsc.PUMP_MINT_AUTHORITY
PUMP = pdsc.PUMP_PROGRAM
DEC = 6
SUP = 1_000_000_000


def check(name, cond, got=None):
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + ("" if cond else f"   (obtenido: {got})"))
    if not cond:
        FAILS.append(name)


def addr(tag):
    return (tag + "x" * 44)[:44]


class Sim:
    def __init__(self, T):
        self.T = T
        self.txs, self.hist, self.accounts = {}, {}, {}
        self.bal = {}           # (mint, owner) -> tokens
        self.n = 0
        self.slot = 400_000_000
        self.rng = random.Random(5)

    def _tb(self, idx, mint, owner, amt):
        return {"accountIndex": idx, "mint": mint, "owner": owner,
                "uiTokenAmount": {"amount": str(int(round(amt * 10 ** DEC))), "decimals": DEC, "uiAmount": amt}}

    def tx(self, t, slot, signer, keys, changes=(), sol=0, logs=(), ixs=()):
        sig = f"s{self.n:07d}"
        self.n += 1
        allk = [signer] + [k for k in keys if k != signer]
        pre_t, post_t = [], []
        for j, (mint, owner, d) in enumerate(changes):
            if owner not in allk:
                allk.append(owner)
            b0 = self.bal.get((mint, owner))
            b1 = (b0 or 0) + d
            if b0 is not None:
                pre_t.append(self._tb(20 + j, mint, owner, b0))
            if b1 > 1e-12:
                post_t.append(self._tb(20 + j, mint, owner, b1))
                self.bal[(mint, owner)] = b1
            else:
                self.bal.pop((mint, owner), None)
        fee = 5000
        tx = {"slot": slot, "blockTime": t,
              "meta": {"err": None, "fee": fee, "preBalances": [10 ** 10] + [1] * (len(allk) - 1),
                       "postBalances": [10 ** 10 + sol - fee] + [1] * (len(allk) - 1),
                       "preTokenBalances": pre_t, "postTokenBalances": post_t, "logMessages": list(logs)},
              "transaction": {"signatures": [sig], "message": {"accountKeys": allk, "instructions": list(ixs)}}}
        self.txs[sig] = tx
        for k in set(allk):
            self.hist.setdefault(k, []).append((t, slot, sig))
        return sig

    def fund(self, wallet, funder, t):
        self.tx(t, self.slot, funder, [wallet], sol=-10 ** 9)

    def launch(self, tag, t, name, symbol, curve_data=None, mint_auth=None):
        mint, curve, creator = addr("MINT" + tag), addr("CURVE" + tag), addr("CREATOR" + tag)
        self.slot += 50
        borsh = lambda s: struct.pack("<I", len(s)) + s.encode()  # noqa: E731
        data = pdsc.b58encode(b"\x18\x1e\xc8\x28\x05\x1c\x07\x77" + borsh(name) + borsh(symbol) + borsh("ipfs://x"))
        self.tx(t, self.slot, creator, [mint, curve, DISC, PUMP], [(mint, curve, SUP)], sol=-2 * 10 ** 7,
                logs=["Program log: Instruction: Create"], ixs=[{"programId": PUMP, "accounts": [], "data": data}])
        vtok, vsol = 800_000_000 * 10 ** DEC, 40 * 10 ** 9      # MC = 50 SOL
        raw = curve_data if curve_data is not None else (
            b"\x00" * 8 + struct.pack("<QQQQQ?", vtok, vsol, 600_000_000 * 10 ** DEC, 10 * 10 ** 9, SUP * 10 ** DEC, False))
        self.accounts[curve] = {"owner": PUMP, "data": [base64.b64encode(raw).decode(), "base64"]}
        self.accounts[mint] = {"owner": pdsc.TOKEN_PROGRAM, "data": {"parsed": {"info": {
            "mintAuthority": mint_auth, "freezeAuthority": None, "decimals": DEC, "extensions": []}}}}
        return {"mint": mint, "curve": curve, "creator": creator, "slot": self.slot, "t": t}

    def trade(self, L, w, tokens, t, slot=None, side="buy"):
        slot = slot if slot is not None else L["slot"] + self.rng.randint(3, 400)
        sol = tokens * 5e-8
        d = tokens if side == "buy" else -tokens
        lam = -int(sol * 1e9) if side == "buy" else int(sol * 1e9)
        if side == "buy" and self.bal.get((L["mint"], w)) is None:
            lam -= 2_039_280
        self.tx(t, slot, w, [L["mint"], L["curve"], PUMP], [(L["mint"], w, d), (L["mint"], L["curve"], -d)], sol=lam,
                logs=[f"Program log: Instruction: {'Buy' if side == 'buy' else 'Sell'}"])


class FakeRPC:
    def __init__(self, sim):
        self.s = sim
        self.calls = 0

    def call(self, method, params):
        self.calls += 1
        if method == "getSignaturesForAddress":
            a, opt = params
            h = sorted(self.s.hist.get(a, []), key=lambda x: (x[0], x[1], x[2]), reverse=True)
            lst = [{"signature": sg, "blockTime": t, "slot": sl, "err": None} for t, sl, sg in h]
            if opt.get("before"):
                i = [x["signature"] for x in lst].index(opt["before"])
                lst = lst[i + 1:]
            return lst[: opt.get("limit", 1000)]
        if method == "getTransaction":
            return self.s.txs.get(params[0])
        if method == "getMultipleAccounts":
            return {"value": [self.s.accounts.get(a) for a in params[0]]}
        raise ValueError(method)


def build_world(T):
    s = Sim(T)
    rng = random.Random(7)
    old = T - 100 * 86400
    # A: orgánico. 40 compradores con financiadores distintos y wallets viejas; 6 venden parte
    A = s.launch("A", T - 20 * 60, "Organic Cat", "ORG")
    buyersA = [addr(f"WA{i:03d}") for i in range(40)]
    for i, w in enumerate(buyersA):
        s.fund(w, addr(f"FUNDA{i:03d}"), old + i)
    for i, w in enumerate(buyersA):
        s.trade(A, w, 5_000_000, A["t"] + 30 + i * 20)
    for w in buyersA[:6]:
        s.trade(A, w, 2_000_000, A["t"] + 900, side="sell")
    # B: bundle. 12 wallets frescas del MISMO financiador compran en el slot de creación (~36%)
    B = s.launch("B", T - 15 * 60, "Bundle Dog", "BND")
    bund = [addr(f"WB{i:03d}") for i in range(12)]
    for w in bund:
        s.fund(w, addr("BIGFUNDER"), T - 3600)
    for w in bund:
        s.trade(B, w, 30_000_000, B["t"], slot=B["slot"])
    orgB = [addr(f"WBO{i:03d}") for i in range(10)]
    for i, w in enumerate(orgB):
        s.fund(w, addr(f"FUNDBO{i:03d}"), old + i)
        s.trade(B, w, 1_000_000, B["t"] + 60 + i * 30)
    for w in bund[:6]:
        s.trade(B, w, 5_000_000, B["t"] + 500, side="sell")
    # C: mint authority activa (HARD)
    C = s.launch("C", T - 10 * 60, "Mintable", "MNT", mint_auth=addr("EVILAUTH"))
    for i in range(8):
        w = addr(f"WC{i:03d}"); s.fund(w, addr(f"FUNDC{i:03d}"), old + i); s.trade(C, w, 1_000_000, C["t"] + 30 * i)
    # D: poca actividad (2 compras)
    D = s.launch("D", T - 5 * 60, "Quiet", "QUIET")
    for i in range(2):
        w = addr(f"WD{i:03d}"); s.fund(w, addr(f"FUNDD{i:03d}"), old + i); s.trade(D, w, 1_000_000, D["t"] + 30 * i)
    # G: curva ilegible
    G = s.launch("G", T - 12 * 60, "Garbage", "GRB", curve_data=b"\x01\x02\x03")
    for i in range(6):
        w = addr(f"WG{i:03d}"); s.fund(w, addr(f"FUNDG{i:03d}"), old + i); s.trade(G, w, 1_000_000, G["t"] + 30 * i)
    # H: el creador compra y vende
    H = s.launch("H", T - 18 * 60, "Rug Pull", "RUG")
    s.trade(H, H["creator"], 40_000_000, H["t"] + 1, slot=H["slot"])
    for i in range(10):
        w = addr(f"WH{i:03d}"); s.fund(w, addr(f"FUNDH{i:03d}"), old + i); s.trade(H, w, 2_000_000, H["t"] + 20 + 30 * i)
    s.trade(H, H["creator"], 40_000_000, H["t"] + 600, side="sell")
    # E: demasiado viejo (fuera de ventana) · F: demasiado joven (< min_age)
    E = s.launch("E", T - 120 * 60, "Old", "OLD")
    F = s.launch("F", T - 60, "Baby", "BABY")
    return s


def main():
    T = int(time.time())
    s = build_world(T)
    out = tempfile.mkdtemp()
    cfg = dict(scan.DEFAULTS)
    print("\n== scan completo")
    rows, text = scan.run_scan(FakeRPC(s), cfg, T, 150.0, out)
    by = {r["symbol"]: r for r in rows}
    check("descubre exactamente los 6 de la ventana (sin OLD ni BABY)", set(by) == {"ORG", "BND", "MNT", "QUIET", "GRB", "RUG"}, sorted(by))
    check("nombre y ticker decodificados del create", by["ORG"]["name"] == "Organic Cat", by["ORG"].get("name"))
    check("MC desde la curva = 50 SOL × $150 = $7.5k", abs(by["ORG"]["mc_usd"] - 7500) < 1, by["ORG"]["mc_usd"])
    check("ORG → CLEAN", by["ORG"]["label"] == "CLEAN", (by["ORG"]["label"], by["ORG"]["reasons"]))
    check("BND → MANIPULATED", by["BND"]["label"] == "MANIPULATED", (by["BND"]["label"], by["BND"]["reasons"]))
    fb = by["BND"]["f"]
    check("BND: cluster de 12 wallets del mismo financiador", fb["largest_funder_cluster"] == 12, fb.get("largest_funder_cluster"))
    check("BND: insider = (6×25M + 6×30M)/1000M = 33%", abs(fb["insider_cluster_share"] - 0.33) < 0.005, fb["insider_cluster_share"])
    check("BND: wallets frescas detectadas", fb["fresh_wallet_share"] > 0.5, fb["fresh_wallet_share"])
    check("MNT → MANIPULATED por HARD (sin gastar forensics)", by["MNT"]["label"] == "MANIPULATED"
          and by["MNT"]["reasons"][0].startswith("HARD") and "f" not in by["MNT"], by["MNT"]["reasons"])
    check("QUIET → WATCH por actividad insuficiente", by["QUIET"]["label"] == "WATCH"
          and any("buys" in x for x in by["QUIET"]["reasons"]), (by["QUIET"]["label"], by["QUIET"]["reasons"]))
    check("GRB → INVALID (curva ilegible)", by["GRB"]["label"] == "INVALID", (by["GRB"]["label"], by["GRB"]["reasons"]))
    check("RUG → MANIPULATED (creador vendió)", by["RUG"]["label"] == "MANIPULATED"
          and "creador ha vendido" in by["RUG"]["reasons"], by["RUG"]["reasons"])
    fo = by["ORG"]["f"]
    check("ORG: 40 compradores, 6 vendedores, 40 holders", (fo["unique_buyers"], fo["unique_sellers"], fo["holders"]) == (40, 6, 40),
          (fo["unique_buyers"], fo["unique_sellers"], fo["holders"]))
    check("ORG: insider = 0, fresh = 0", fo["insider_cluster_share"] == 0 and fo["fresh_wallet_share"] == 0,
          (fo["insider_cluster_share"], fo["fresh_wallet_share"]))
    check("score: ORG > QUIET", by["ORG"]["moonshot_score"] > by["QUIET"]["moonshot_score"],
          (by["ORG"]["moonshot_score"], by["QUIET"]["moonshot_score"]))
    check("score no se calcula para MANIPULATED/INVALID", by["BND"]["moonshot_score"] is None and by["GRB"]["moonshot_score"] is None)
    check("tarjeta en el formato pedido", all(k in text for k in ("🟢 CLEAN", "$ORG", "MC:", "AGE:", "BUYERS:", "SELLERS:",
          "HOLDERS:", "VOLUME:", "INSIDER CLUSTER:", "SNIPER:", "FRESH WALLETS:", "TOP HOLDERS:", "MOONSHOT SCORE:", "REASON:")))
    check("CLEAN se muestra antes que WATCH", text.index("$ORG") < text.index("$QUIET"))
    log = [json.loads(l) for l in open(os.path.join(out, "scan_log.jsonl"))]
    check("scan_log registra los 6 (incluidos descartados)", len(log) == 6, len(log))

    print("\n== point-in-time: reproducir el scan 16 min antes")
    rows2, _ = scan.run_scan(FakeRPC(s), cfg, T - 16 * 60, 150.0, tempfile.mkdtemp())
    by2 = {r["symbol"]: r for r in rows2}
    check("a T-16min solo existen ORG y RUG (BND nace a T-15)", set(by2) == {"ORG", "RUG"}, sorted(by2))
    check("ORG a T-16: aún sin las ventas (nacen a +15min)", by2["ORG"]["f"]["sells"] == 0, by2["ORG"]["f"]["sells"])
    check("RUG a T-16: el creador todavía no había vendido → no MANIPULATED por venta",
          "creador ha vendido" not in by2["RUG"]["reasons"], by2["RUG"]["reasons"])

    print("\n== presupuesto top_n = 2")
    cfg2 = dict(cfg, top_n=2)
    rows3, text3 = scan.run_scan(FakeRPC(s), cfg2, T, 150.0, tempfile.mkdtemp())
    n_na = sum(1 for r in rows3 if r["label"] == "NOT_ANALYZED")
    check("HARD no consume presupuesto; 3 no analizados y registrados", n_na == 3, n_na)

    print("\n== doctor")
    buf = io.StringIO()
    with redirect_stdout(buf):
        ok = scan.doctor(FakeRPC(s), cfg, 150.0)
    o = buf.getvalue()
    check("doctor parsea las creaciones", "creaciones parseadas: 8" in o, o[:300])
    check("doctor detecta la curva ilegible y NO da luz verde", ok is False and "curvas decodificadas: 7/8" in o, o)
    shutil.rmtree(out)
    print(f"\n{'TODO OK' if not FAILS else f'{len(FAILS)} FALLOS: {FAILS}'}")
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()

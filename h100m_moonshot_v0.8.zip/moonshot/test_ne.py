#!/usr/bin/env python3
"""
Tests de natural_experiment.py contra corpus sintéticos con efecto conocido.
  python test_ne.py [--workdir DIR]     (~10-12 min: genera 4 corpus de ~70k lanzamientos)
"""
import argparse
import json
import math
import os
import subprocess
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_synthetic_ne  # noqa: E402

FAILS = []


def check(name, cond, got=None):
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}" + ("" if cond else f"   (obtenido: {got})"))
    if not cond:
        FAILS.append(name)


def run(workdir, sc):
    data, out = os.path.join(workdir, sc), os.path.join(workdir, f"out_{sc}")
    if not os.path.exists(os.path.join(data, "config.json")):
        make_synthetic_ne.make(data, sc)
    subprocess.run([sys.executable, os.path.join(HERE, "natural_experiment.py"), "--config",
                    os.path.join(data, "config.json"), "--out", out],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    with open(os.path.join(out, "natural_experiment.json")) as f:
        o = json.load(f)
    return o, pd.read_parquet(os.path.join(out, "ne_tokens.parquet")), pd.read_parquet(os.path.join(data, "truth.parquet"))


def oracle_or(units, truth):
    m = units.merge(truth[["mint", "p1", "p0"]], on="mint")
    m = m[m.regime.eq("POST") & m.eligible_base & m.fee_mode.isin(["holder_rewards", "creator_fee"])
          & m.pair_type.isin(["SOL", "RWA"])]
    p1, p0 = m.p1.mean(), m.p0.mean()
    return (p1 / (1 - p1)) / (p0 / (1 - p0))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workdir", default=os.path.join(HERE, "_test_ne"))
    a = ap.parse_args()
    os.makedirs(a.workdir, exist_ok=True)

    print("\n== effect_long (efecto HR real + autoselección)")
    o, u, t = run(a.workdir, "effect_long")
    h = o["hypotheses"]["H_FEE"]
    orc = oracle_or(u, t)
    ip = h["iptw"]
    check("STATUS = SIGNAL", o["STATUS"] == "SIGNAL", o["STATUS"])
    check(f"OR ingenuo sesgado (> oráculo {orc:.2f})", h["mh_or"] > orc * 1.5, h["mh_or"])
    check("IPTW más cerca del oráculo que el ingenuo",
          abs(math.log(ip["or"]) - math.log(orc)) < abs(math.log(h["mh_or"]) - math.log(orc)), (ip["or"], h["mh_or"]))
    check("IC IPTW contiene el oráculo", ip["ci95_bootstrap"][0] <= orc <= ip["ci95_bootstrap"][1],
          (ip["ci95_bootstrap"], orc))
    check("balance tras IPTW (SMD máx <= 0.1)", ip["max_abs_smd_after"] <= 0.1, ip["max_abs_smd_after"])
    check("H_RWA = NO_SIGNAL (efecto plantado 0)", o["verdicts"]["H_RWA"]["status"] == "NO_SIGNAL",
          o["verdicts"]["H_RWA"])
    check("H_INT = NO_SIGNAL (efecto plantado 0)", o["verdicts"]["H_INT"]["status"] == "NO_SIGNAL",
          o["verdicts"]["H_INT"])
    # MC multi-par: el Y detectado coincide con la verdad, también en pares RWA
    m = u.merge(t[["mint", "winner", "pair", "peak"]], on="mint")
    el = m[m.eligible_base]
    agree = (el["Y_val1000000_168h"] == el["winner"]).mean()
    agree_rwa = (el.loc[el.pair_type.eq("RWA"), "Y_val1000000_168h"] == el.loc[el.pair_type.eq("RWA"), "winner"]).mean()
    check("Y detectado == verdad (>= 99.5%)", agree >= 0.995, agree)
    check("Y detectado == verdad en pares RWA (>= 99.5%)", agree_rwa >= 0.995, agree_rwa)
    nv = m[m.pair.eq("NVDAX") & m.winner]
    ratio = (nv["ath_mc"] / nv["peak"]).median()
    check("ATH NVDAX / pico real ≈ 1 (±2%): MC en USD vía precio del par", abs(ratio - 1) < 0.02, ratio)
    a_h = o["audit_A_H"]
    check("A: lanzamientos = verdad", a_h["A_launches"] == len(t), a_h["A_launches"])
    check("B: graduados = migraciones dentro del corpus",
          a_h["B_graduated"] == len(pd.read_parquet(os.path.join(a.workdir, "effect_long", "migrations.parquet"))),
          a_h["B_graduated"])

    print("\n== null_long (SIN efecto, misma autoselección)")
    o, u, t = run(a.workdir, "null_long")
    h = o["hypotheses"]["H_FEE"]
    check("el análisis ingenuo 've' un efecto (MH p < 0.05)", h["permutation_p"] < 0.05, h["permutation_p"])
    check("IC IPTW incluye 1", h["iptw"]["ci95_bootstrap"][0] <= 1 <= h["iptw"]["ci95_bootstrap"][1],
          h["iptw"]["ci95_bootstrap"])
    check("STATUS = NO_SIGNAL", o["STATUS"] == "NO_SIGNAL", o["STATUS"])

    print("\n== today (corpus termina el 22-sep: solo ~3 días POST con 7d de seguimiento)")
    o, u, t = run(a.workdir, "today")
    check("días POST con seguimiento completo <= 4", o["audit_A_H"]["G_POST_days_with_full_followup"] <= 4,
          o["audit_A_H"]["G_POST_days_with_full_followup"])
    check("STATUS = INSUFFICIENT_DATA", o["STATUS"] == "INSUFFICIENT_DATA", (o["STATUS"], o["verdicts"]["H_FEE"]))

    print("\n== few_rwa (RWA ~1% de POST)")
    o, u, t = run(a.workdir, "few_rwa")
    check("H_RWA = INSUFFICIENT_DATA", o["verdicts"]["H_RWA"]["status"] == "INSUFFICIENT_DATA", o["verdicts"]["H_RWA"])
    check("H_INT = INSUFFICIENT_DATA", o["verdicts"]["H_INT"]["status"] == "INSUFFICIENT_DATA", o["verdicts"]["H_INT"])
    check("H_FEE sigue evaluable (SIGNAL)", o["verdicts"]["H_FEE"]["status"] == "SIGNAL", o["verdicts"]["H_FEE"])

    print(f"\n{'TODO OK' if not FAILS else f'{len(FAILS)} FALLOS: {FAILS}'}")
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()

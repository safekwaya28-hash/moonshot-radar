@echo off
REM Doble clic: instala lo necesario (solo la primera vez tarda) y ejecuta el radar.
cd /d "%~dp0"
where python >nul 2>nul || (echo Necesitas Python 3: https://www.python.org/downloads/  ^(marca "Add python to PATH"^) & pause & exit /b)
python -m pip install -q -r requirements.txt
python moonshot.py %*
echo.
pause

#!/usr/bin/env python3
"""
H-100M · FASE 0.2 — DATA + IDENTIFICATION AUDIT
================================================

Audita si el corpus permite estudiar honestamente los saltos
$1M -> $10M -> $50M -> $100M. NO construye features ni modelos.

Salidas (en --out):
  phase0_report.json      informe máquina (claves pedidas en la Fase 0.2)
  phase0_report.md        resumen legible
  phase0_tokens.parquet   una fila por token: ATH, clase de observabilidad, Q-scores
  phase0_crosses.parquet  una fila por (token, umbral): raw/validated cross, gaps, cohortes

Uso:
  python phase0_audit.py --introspect --config config.json   # ver esquemas + sugerir mapeo
  python phase0_audit.py --config config.json --out out/     # auditoría completa

Principios (no negociables):
  * La cobertura se mide con los DATOS, nunca por la existencia de una columna.
  * Sin fuente => "ABSENT"/"UNKNOWN". Nunca se imputa.
  * Todos los parámetros de definición (W, k, gaps, umbrales) se leen de la config
    y se copian al informe: quedan pre-registrados junto al resultado.
  * Todo en UTC.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from datetime import datetime, timezone

import duckdb

VERSION = "0.3.0"

# --------------------------------------------------------------------------------------
# Esquema lógico. Cada tabla real se mapea a estos campos en config["tables"][t]["columns"].
# --------------------------------------------------------------------------------------
LOGICAL = {
    "tokens": {
        "mint": "VARCHAR", "created_at": "TS", "creator": "VARCHAR",
        "name": "VARCHAR", "symbol": "VARCHAR", "description": "VARCHAR",
        "twitter": "VARCHAR", "telegram": "VARCHAR", "website": "VARCHAR", "discord": "VARCHAR",
        "total_supply": "DOUBLE",
        "quote_asset": "VARCHAR", "fee_mode": "VARCHAR",
    },
    "trades": {
        "mint": "VARCHAR", "ts": "TS", "signature": "VARCHAR", "wallet": "VARCHAR",
        "side": "VARCHAR", "is_buy": "BOOLEAN",
        "sol_amount": "DOUBLE", "quote_amount": "DOUBLE", "token_amount": "DOUBLE",
        "price_sol": "DOUBLE", "price_quote": "DOUBLE", "price_usd": "DOUBLE", "mc_usd": "DOUBLE",
        "venue": "VARCHAR",
    },
    "snapshots": {
        "mint": "VARCHAR", "ts": "TS", "mc_usd": "DOUBLE", "price_usd": "DOUBLE",
        "price_sol": "DOUBLE", "price_quote": "DOUBLE", "liquidity_usd": "DOUBLE", "holders": "DOUBLE",
        "v_sol": "DOUBLE", "complete": "BOOLEAN",
    },
    "migrations": {"mint": "VARCHAR", "ts": "TS", "pool": "VARCHAR", "venue": "VARCHAR"},
    "sol_price": {"ts": "TS", "price_usd": "DOUBLE"},
    "quote_prices": {"asset": "VARCHAR", "ts": "TS", "price_usd": "DOUBLE"},
    "social_history": {"mint": "VARCHAR", "ts": "TS", "field": "VARCHAR", "value": "VARCHAR"},
}

DEFAULTS = {
    "thresholds_usd": [1_000_000, 10_000_000, 50_000_000, 100_000_000],
    "extra_thresholds_usd": [2_000_000, 20_000_000],          # para false escalators
    "mc_source": "trades",           # trades | snapshots  (fuente primaria de MC(t))
    "supply": {"mode": "fixed", "value": 1_000_000_000},      # o {"mode":"column"} -> tokens.total_supply
    "sol_usd_constant": None,        # SOLO como último recurso; queda marcado en el informe
    # ---- activo del par (v0.3). Sin tokens.quote_asset mapeado, todo es SOL (compatibilidad v0.2)
    "quote": {
        "default_asset": "SOL",
        "aliases": {},               # {"<mint del activo>": "NVDAX", ...}  -> nombre canónico
        "stablecoins": ["USDC", "USDT"],
        "amount_scales": {},         # {"SOL": 1e-9, "USDC": 1e-6, "NVDAX": 1e-8}; si falta: amount_scales.sol_amount
        "max_staleness_seconds": 7200,   # precio del par más viejo que esto => NULL (no se imputa)
    },
    # Catálogo de pares: DEBE venir del catálogo histórico del proveedor, no inventado.
    "pair_catalog": {},              # {"NVDAX": "RWA", "SOL": "SOL", "USDC": "STABLE", "PUMP": "CRYPTO"}
    "fee_mode_values": {
        "creator_fee": ["creator_fee", "creator", "cf", "standard"],
        "holder_rewards": ["holder_rewards", "holder", "hr", "rewards"],
        "cashback": ["cashback", "cb"],
    },
    "cross": {
        "window_seconds": 600,       # W
        "min_followups": 2,          # k observaciones posteriores dentro de W
        "rule": "all",               # all: todas las posteriores en W >= X | median: mediana >= X
        "max_bracket_gap_seconds": 900,   # cruce observable si obs previa <= 15 min antes
    },
    "outcome": {
        "followup_days": 7,          # outcome negativo aceptado si hay >= 7 días de seguimiento
        "censor_window_hours": 24,   # token "vivo" en el final del corpus => ATH es cota inferior
    },
    "quality": {
        "q_min": 0.90,
        "critical_gap_seconds": 900,     # gap máximo tolerado en la hora previa al cruce
        "snapshot_gap_seconds": 900,
        "price_jump_ratio": 50.0,
        "wallet_min_coverage": 0.95,
        "min_post_migration_trades": 1,
        "reconstruction_tolerance": 0.20,
    },
    "required_at_cross": ["wallet", "social_launch", "snapshot_liquidity", "snapshot_holders"],
    "snapshot_max_lag_seconds": 900,     # snapshot usable para congelar features: <= 15 min ANTES del cruce
    "metadata_is_launch_time": False,    # ¿los metadatos sociales son los del momento de creación? (verificar)
    "power": {
        "alpha": 0.05,
        "k_values": [5, 10, 20],
        "lift_to_detect": 3.0,
        "models_tested": 4,              # M1..M4 (M0 = random es el nulo)
        "temporal_cuts": 1,
    },
    "regimes": {"min_days_per_regime": 7, "rolling_days": 7, "bins": 2,
                "use_grad_rate": False, "use_sol": True},
    "timestamp_units": {},               # {"trades": "s"|"ms"|"us"|"timestamp", ...}
    "amount_scales": {"sol_amount": 1.0, "token_amount": 1.0},
    "side_values": {"buy": ["buy", "b", "true", "1"], "sell": ["sell", "s", "false", "0"]},
    "run_timestamp_utc": None,
}


def deep_merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def q(ident: str) -> str:
    return '"' + ident.replace('"', '""') + '"'


def lit(s: str) -> str:
    return "'" + str(s).replace("'", "''") + "'"


# --------------------------------------------------------------------------------------
# Carga y normalización
# --------------------------------------------------------------------------------------
class Corpus:
    def __init__(self, cfg: dict, con: duckdb.DuckDBPyConnection):
        self.cfg = cfg
        self.con = con
        self.present: dict[str, bool] = {}
        self.mapped: dict[str, set] = {}
        self.notes: list[str] = []

    def reader(self, table: str) -> str | None:
        t = self.cfg.get("tables", {}).get(table)
        if not t or not t.get("path"):
            return None
        path = t["path"]
        fmt = t.get("format") or ("csv" if path.lower().endswith((".csv", ".csv.gz")) else "parquet")
        if fmt == "csv":
            return f"read_csv_auto({lit(path)}, union_by_name=true)"
        return f"read_parquet({lit(path)}, union_by_name=true)"

    def raw_columns(self, table: str) -> list[tuple[str, str]]:
        r = self.reader(table)
        if r is None:
            return []
        try:
            return [(row[0], row[1]) for row in self.con.execute(f"DESCRIBE SELECT * FROM {r}").fetchall()]
        except duckdb.Error as e:
            raise SystemExit(f"No puedo leer la tabla '{table}' ({self.cfg['tables'][table]['path']}): {e}")

    def ts_expr(self, table: str, col: str) -> str:
        unit = self.cfg["timestamp_units"].get(table, "timestamp")
        c = q(col)
        if unit == "s":
            return f"make_timestamp(CAST(ROUND(CAST({c} AS DOUBLE) * 1000000) AS BIGINT))"
        if unit == "ms":
            return f"make_timestamp(CAST({c} AS BIGINT) * 1000)"
        if unit == "us":
            return f"make_timestamp(CAST({c} AS BIGINT))"
        return f"CAST({c} AS TIMESTAMP)"

    def field(self, table: str, logical: str) -> str:
        ltype = LOGICAL[table][logical]
        col = self.cfg["tables"].get(table, {}).get("columns", {}).get(logical)
        sqltype = "TIMESTAMP" if ltype == "TS" else ltype
        if not col:
            return f"CAST(NULL AS {sqltype}) AS {logical}"
        self.mapped.setdefault(table, set()).add(logical)
        if ltype == "TS":
            return f"{self.ts_expr(table, col)} AS {logical}"
        if ltype == "VARCHAR":
            return f"NULLIF(TRIM(CAST({q(col)} AS VARCHAR)), '') AS {logical}"
        if ltype == "BOOLEAN":
            return (f"CASE WHEN lower(CAST({q(col)} AS VARCHAR)) IN ('true','1','t','yes','y') THEN TRUE "
                    f"WHEN lower(CAST({q(col)} AS VARCHAR)) IN ('false','0','f','no','n') THEN FALSE END AS {logical}")
        return f"TRY_CAST({q(col)} AS {sqltype}) AS {logical}"

    def is_mapped(self, table: str, logical: str) -> bool:
        return logical in self.mapped.get(table, set())

    def validate_mapping(self):
        errors = []
        for table, spec in self.cfg.get("tables", {}).items():
            if table not in LOGICAL:
                errors.append(f"tabla desconocida en config: {table}")
                continue
            if not spec.get("path"):
                continue
            real = {c for c, _ in self.raw_columns(table)}
            for logical, col in spec.get("columns", {}).items():
                if logical not in LOGICAL[table]:
                    errors.append(f"{table}.{logical}: campo lógico desconocido")
                elif col and col not in real:
                    errors.append(f"{table}.{logical} -> '{col}' no existe. Columnas reales: {sorted(real)}")
        for req in [("tokens", "mint"), ("tokens", "created_at"), ("trades", "mint"), ("trades", "ts")]:
            if not self.cfg.get("tables", {}).get(req[0], {}).get("columns", {}).get(req[1]):
                errors.append(f"mapeo obligatorio ausente: {req[0]}.{req[1]}")
        if errors:
            raise SystemExit("ERRORES DE CONFIG:\n  - " + "\n  - ".join(errors))

    def attach_quote_usd(self, table: str):
        """quote_usd(t) = último precio del activo del par con ts <= t (ASOF hacia atrás, sin look-ahead).
        Stablecoins = 1. Precio más viejo que max_staleness => NULL. SOL sin tabla => constante si se configuró."""
        con, cfg = self.con, self.cfg
        qc = cfg["quote"]
        stables = ",".join(lit(str(a).upper()) for a in qc["stablecoins"]) or "''"
        stale = int(qc["max_staleness_seconds"])
        const = (f"WHEN x.quote_asset = 'SOL' THEN {float(cfg['sol_usd_constant'])}"
                 if cfg.get("sol_usd_constant") and not self.present["sol_price"] else "")
        con.execute(f"""CREATE OR REPLACE TABLE {table} AS
            SELECT x.*,
              CASE WHEN x.quote_asset IN ({stables}) THEN 1.0
                   {const}
                   WHEN q.ts IS NOT NULL AND epoch(x.ts - q.ts) <= {stale} THEN q.price_usd END AS quote_usd,
              CASE WHEN q.ts IS NOT NULL THEN epoch(x.ts - q.ts) END AS quote_px_age_s
            FROM {table} x ASOF LEFT JOIN quote_px q ON x.quote_asset = q.asset AND x.ts >= q.ts""")
        if table == "trades":
            src = []
            if self.present.get("sol_price"):
                src.append("SOL: sol_price")
            if self.present.get("quote_prices"):
                src.append("otros: quote_prices")
            if const:
                src.append(f"SOL: CONSTANTE {cfg['sol_usd_constant']} (FLAG)")
            src.append("stablecoins = 1")
            self.sol_usd_method = ("ABSENT" if not (self.present.get("sol_price") or self.present.get("quote_prices") or const)
                                   else "ASOF hacia atrás por activo · " + ", ".join(src) + f" · staleness máx {stale}s")

    def load(self):
        con, cfg = self.con, self.cfg
        # ---- sol_price
        r = self.reader("sol_price")
        self.present["sol_price"] = r is not None
        if r:
            con.execute(f"""CREATE OR REPLACE TABLE sol_price AS
                SELECT {self.field('sol_price','ts')}, {self.field('sol_price','price_usd')}
                FROM {r}""")
            con.execute("DELETE FROM sol_price WHERE ts IS NULL OR price_usd IS NULL OR price_usd <= 0")
        # ---- tokens
        r = self.reader("tokens")
        self.present["tokens"] = True
        cols = ", ".join(self.field("tokens", f) for f in LOGICAL["tokens"])
        con.execute(f"CREATE OR REPLACE TABLE tokens_raw AS SELECT {cols} FROM {r}")
        # tokens únicos (primera creación); la duplicación se reporta en calidad
        qc = cfg["quote"]
        alias_sql = " ".join(f"WHEN quote_asset = {lit(k)} THEN {lit(str(v).upper())}" for k, v in qc["aliases"].items())
        qa_expr = (f"UPPER(COALESCE(CASE {alias_sql} END, quote_asset, {lit(qc['default_asset'])}))" if alias_sql
                   else f"UPPER(COALESCE(quote_asset, {lit(qc['default_asset'])}))")
        fm_cases = " ".join(
            f"WHEN lower(fee_mode) IN ({','.join(lit(str(v).lower()) for v in vals)}) THEN {lit(mode)}"
            for mode, vals in cfg["fee_mode_values"].items())
        fm_expr = f"CASE WHEN fee_mode IS NULL THEN NULL {fm_cases} ELSE 'unrecognized' END"
        con.execute(f"""CREATE OR REPLACE TABLE tokens AS
            SELECT * REPLACE ({qa_expr} AS quote_asset), fee_mode AS fee_mode_raw, {fm_expr} AS fee_mode_norm
            FROM (SELECT *, row_number() OVER (PARTITION BY mint ORDER BY created_at NULLS LAST) rn
                  FROM tokens_raw WHERE mint IS NOT NULL) WHERE rn = 1""")
        # ---- precios de activos de par (point-in-time)
        r = self.reader("quote_prices")
        self.present["quote_prices"] = r is not None
        parts = []
        if self.present["sol_price"]:
            parts.append("SELECT 'SOL' AS asset, ts, price_usd FROM sol_price")
        if r:
            parts.append(f"""SELECT UPPER(asset) AS asset, ts, price_usd FROM
                (SELECT {self.field('quote_prices','asset')}, {self.field('quote_prices','ts')},
                        {self.field('quote_prices','price_usd')} FROM {r})
                WHERE ts IS NOT NULL AND price_usd > 0""")
        if parts:
            con.execute("CREATE OR REPLACE TABLE quote_px AS " + " UNION ALL ".join(parts))
        else:
            con.execute("CREATE OR REPLACE TABLE quote_px (asset VARCHAR, ts TIMESTAMP, price_usd DOUBLE)")
        if cfg.get("sol_usd_constant"):
            self.notes.append("SOL/USD constante: los umbrales en USD son aproximados; no usar para claims finales.")
        # ---- supply
        sup = cfg["supply"]
        if sup.get("mode") == "column":
            if not self.is_mapped("tokens", "total_supply"):
                raise SystemExit("supply.mode=column requiere tokens.total_supply mapeado")
            self.supply_sql = "t.total_supply"
            self.supply_desc = "tokens.total_supply (por token)"
        else:
            self.supply_sql = str(float(sup.get("value", 1e9)))
            self.supply_desc = f"fijo = {float(sup.get('value', 1e9)):.0f}"
        # ---- trades
        r = self.reader("trades")
        self.present["trades"] = True
        tf = {f: self.field("trades", f) for f in LOGICAL["trades"]}
        sv = cfg["side_values"]
        if self.is_mapped("trades", "is_buy"):
            side = "CASE WHEN is_buy THEN 'buy' WHEN NOT is_buy THEN 'sell' END"
        elif self.is_mapped("trades", "side"):
            buys = ",".join(lit(str(v).lower()) for v in sv["buy"])
            sells = ",".join(lit(str(v).lower()) for v in sv["sell"])
            side = f"CASE WHEN lower(side) IN ({buys}) THEN 'buy' WHEN lower(side) IN ({sells}) THEN 'sell' END"
        else:
            side = "CAST(NULL AS VARCHAR)"
        s_def = float(cfg["amount_scales"].get("sol_amount", 1.0))
        s_tok = float(cfg["amount_scales"].get("token_amount", 1.0))
        scale_cases = " ".join(f"WHEN t.quote_asset = {lit(str(a).upper())} THEN {float(v)}"
                               for a, v in cfg["quote"]["amount_scales"].items())
        scale_expr = f"CASE {scale_cases} ELSE {s_def} END" if scale_cases else str(s_def)
        con.execute(f"""CREATE OR REPLACE TABLE trades0 AS
            SELECT x.mint, x.ts, x.signature, x.wallet, {side} AS side,
                   COALESCE(x.quote_amount, x.sol_amount) * {scale_expr} AS quote_amt,
                   x.token_amount * {s_tok} AS tok_amt,
                   COALESCE(x.price_quote, x.price_sol) AS price_quote_direct,
                   x.price_usd, x.mc_usd AS mc_usd_direct, x.venue,
                   COALESCE(t.quote_asset, {lit(cfg['quote']['default_asset'].upper())}) AS quote_asset
            FROM (SELECT {', '.join(tf.values())} FROM {r}) x LEFT JOIN tokens t USING (mint)""")
        con.execute("""CREATE OR REPLACE TABLE trades0 AS
            SELECT *, COALESCE(price_quote_direct,
                               CASE WHEN tok_amt > 0 AND quote_amt > 0 THEN quote_amt / tok_amt END) AS px_quote
            FROM trades0""")
        con.execute(f"CREATE OR REPLACE TABLE trades AS SELECT * FROM trades0 tr ORDER BY quote_asset, ts")
        con.execute("DROP TABLE trades0")
        self.attach_quote_usd("trades")
        con.execute(f"""CREATE OR REPLACE TABLE trades AS
            SELECT tr.*,
              mc_usd_direct AS mc_obs_direct,
              CASE WHEN mc_usd_direct IS NULL THEN
                  COALESCE(tr.price_usd * {self.supply_sql}, tr.px_quote * tr.quote_usd * {self.supply_sql})
              END AS mc_reconstructed
            FROM trades tr LEFT JOIN tokens t USING (mint)""")
        con.execute("ALTER TABLE trades ADD COLUMN mc DOUBLE")
        con.execute("UPDATE trades SET mc = COALESCE(mc_obs_direct, mc_reconstructed)")
        # ---- snapshots
        r = self.reader("snapshots")
        self.present["snapshots"] = r is not None
        if r:
            sf = ", ".join(self.field("snapshots", f) for f in LOGICAL["snapshots"])
            con.execute(f"CREATE OR REPLACE TABLE snaps0 AS SELECT {sf} FROM {r}")
            con.execute(f"""CREATE OR REPLACE TABLE snapshots AS
                SELECT s.*, COALESCE(s.price_quote, s.price_sol) AS px_quote,
                       COALESCE(t.quote_asset, {lit(cfg['quote']['default_asset'].upper())}) AS quote_asset
                FROM snaps0 s LEFT JOIN tokens t ON t.mint = s.mint""")
            self.attach_quote_usd("snapshots")
            con.execute(f"""CREATE OR REPLACE TABLE snapshots AS
                SELECT s.mint, s.ts, s.liquidity_usd, s.holders, s.v_sol, s.complete, s.quote_asset, s.quote_usd,
                       s.mc_usd AS mc_obs_direct,
                       CASE WHEN s.mc_usd IS NULL THEN
                         COALESCE(s.price_usd * {self.supply_sql}, s.px_quote * s.quote_usd * {self.supply_sql}) END
                         AS mc_reconstructed
                FROM snapshots s LEFT JOIN tokens t ON t.mint = s.mint""")
            con.execute("ALTER TABLE snapshots ADD COLUMN mc DOUBLE")
            con.execute("UPDATE snapshots SET mc = COALESCE(mc_obs_direct, mc_reconstructed)")
            con.execute("DROP TABLE snaps0")
        # ---- migrations
        r = self.reader("migrations")
        self.present["migrations"] = r is not None
        if r:
            mf = ", ".join(self.field("migrations", f) for f in LOGICAL["migrations"])
            con.execute(f"CREATE OR REPLACE TABLE migrations_raw AS SELECT {mf} FROM {r}")
            con.execute("""CREATE OR REPLACE TABLE migrations AS
                SELECT mint, min(ts) AS ts, any_value(pool) AS pool, any_value(venue) AS venue, count(*) AS n_rows
                FROM migrations_raw WHERE mint IS NOT NULL GROUP BY mint""")
        # ---- social_history
        r = self.reader("social_history")
        self.present["social_history"] = r is not None
        if r:
            hf = ", ".join(self.field("social_history", f) for f in LOGICAL["social_history"])
            con.execute(f"CREATE OR REPLACE TABLE social_history AS SELECT {hf} FROM {r}")


# --------------------------------------------------------------------------------------
# Utilidades estadísticas (sin scipy)
# --------------------------------------------------------------------------------------
def binom_sf(h: int, n: int, p: float) -> float:
    """P(X >= h), X ~ Binom(n, p)."""
    if h <= 0:
        return 1.0
    if h > n:
        return 0.0
    if p <= 0.0:
        return 0.0
    if p >= 1.0:
        return 1.0
    lp, lq = math.log(p), math.log1p(-p)
    lc = math.lgamma(n + 1)
    terms = [lc - math.lgamma(i + 1) - math.lgamma(n - i + 1) + i * lp + (n - i) * lq for i in range(h, n + 1)]
    m = max(terms)
    return float(min(1.0, math.exp(m) * sum(math.exp(t - m) for t in terms)))


def clopper_pearson(k: int, n: int, alpha: float = 0.05):
    if n == 0:
        return None
    def beta_ppf(qq, a, b):  # bisección sobre la CDF beta vía binomial
        lo, hi = 0.0, 1.0
        for _ in range(80):
            mid = (lo + hi) / 2
            # I_mid(a,b) con a,b enteros = P(Binom(a+b-1, mid) >= a)
            cdf = binom_sf(a, a + b - 1, mid)
            if cdf < qq:
                lo = mid
            else:
                hi = mid
        return (lo + hi) / 2
    lo = 0.0 if k == 0 else beta_ppf(alpha / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta_ppf(1 - alpha / 2, k + 1, n - k)
    return [round(lo, 6), round(hi, 6)]


def model_tier(events: int) -> str:
    if events < 20:
        return "DESCRIPTIVE_ONLY (<20 eventos: effect sizes, IC exactos, 1-2 señales pre-especificadas; NO ML)"
    if events < 50:
        return "PENALIZED_SIMPLE (20-50: logística penalizada / Firth, muy pocas variables)"
    if events <= 100:
        return "SMALL_MODELS (50-100: modelos pequeños pre-especificados)"
    return "COMPARATIVE (>100: comparaciones más ambiciosas permitidas)"


def fmt_usd(x: float) -> str:
    return f"{int(x/1e6)}M" if x >= 1e6 else f"{int(x/1e3)}k"


# --------------------------------------------------------------------------------------
# Auditoría
# --------------------------------------------------------------------------------------
class Audit:
    def __init__(self, cfg: dict, corpus: Corpus):
        self.cfg = cfg
        self.c = corpus
        self.con = corpus.con
        self.r: dict = {}

    def one(self, sql: str):
        row = self.con.execute(sql).fetchone()
        return row[0] if row and len(row) == 1 else row

    def rows(self, sql: str):
        return self.con.execute(sql).fetchall()

    # ---------------- helpers
    def obs_table(self) -> str:
        """Serie MC(t) primaria."""
        src = self.cfg["mc_source"]
        if src == "snapshots":
            if not self.c.present["snapshots"]:
                raise SystemExit("mc_source=snapshots pero no hay tabla snapshots")
            return "snapshots"
        return "trades"

    # ---------------- corpus bounds
    def corpus_bounds(self):
        src = self.obs_table()
        lo, hi = self.one(f"SELECT min(ts), max(ts) FROM {src} WHERE ts IS NOT NULL")
        self.t_min, self.t_max = lo, hi
        self.r["corpus_date_min"] = str(lo) if lo else None
        self.r["corpus_date_max"] = str(hi) if hi else None
        self.r["n_tokens"] = self.one("SELECT count(*) FROM tokens")
        self.r["n_tokens_raw_rows"] = self.one("SELECT count(*) FROM tokens_raw")
        self.r["n_trades"] = self.one("SELECT count(*) FROM trades")
        self.r["n_snapshots"] = self.one("SELECT count(*) FROM snapshots") if self.c.present["snapshots"] else 0
        self.r["n_migrations"] = self.one("SELECT count(*) FROM migrations") if self.c.present["migrations"] else 0

    # ---------------- BLOQUE H: frontera de migración y cobertura post-migración
    def migration(self):
        con = self.con
        qc = self.cfg["quality"]
        if self.c.present["migrations"]:
            boundary_src = "migrations table"
            con.execute("CREATE OR REPLACE TABLE boundary AS SELECT mint, ts AS boundary_ts, pool, venue FROM migrations")
        elif self.c.present["snapshots"] and self.c.is_mapped("snapshots", "complete"):
            boundary_src = "snapshots.complete (primer TRUE)"
            con.execute("""CREATE OR REPLACE TABLE boundary AS
                SELECT mint, min(ts) AS boundary_ts, NULL AS pool, NULL AS venue
                FROM snapshots WHERE complete GROUP BY mint""")
        else:
            boundary_src = None
            con.execute("CREATE OR REPLACE TABLE boundary (mint VARCHAR, boundary_ts TIMESTAMP, pool VARCHAR, venue VARCHAR)")

        snap_join = ("""LEFT JOIN (SELECT b.mint, count(s.ts) AS n_post_snap FROM boundary b
                          JOIN snapshots s ON s.mint = b.mint AND s.ts > b.boundary_ts AND s.mc IS NOT NULL
                          GROUP BY b.mint) sp USING(mint)""" if self.c.present["snapshots"] else "")
        snap_col = "COALESCE(sp.n_post_snap, 0)" if self.c.present["snapshots"] else "0"
        mpt = int(qc['min_post_migration_trades'])
        con.execute(f"""CREATE OR REPLACE TABLE mig_cov AS
            WITH tc AS (
              SELECT b.mint,
                count(t.ts) FILTER (WHERE t.ts <= b.boundary_ts) AS n_pre,
                count(t.ts) FILTER (WHERE t.ts >  b.boundary_ts) AS n_post,
                count(t.ts) FILTER (WHERE t.ts >  b.boundary_ts AND t.mc IS NOT NULL) AS n_post_price
              FROM boundary b LEFT JOIN trades t ON t.mint = b.mint GROUP BY b.mint)
            SELECT b.mint, b.boundary_ts, b.pool, COALESCE(tc.n_pre,0) n_pre, COALESCE(tc.n_post,0) n_post,
                   COALESCE(tc.n_post_price,0) n_post_price, {snap_col} AS n_post_snap,
                   (COALESCE(tc.n_post,0) >= {mpt}) AS has_post_trades,
                   (COALESCE(tc.n_post_price,0) >= {mpt} OR {snap_col} > 0) AS has_post_price
            FROM boundary b LEFT JOIN tc USING(mint) {snap_join}""")
        n_mig = self.one("SELECT count(*) FROM mig_cov")
        if boundary_src is None:
            status, cov = "UNKNOWN", None
            reason = "No hay tabla de migraciones ni flag 'complete' fechado: no existe frontera temporal fiable."
            # indicio (no prueba): ¿hay precios muy por encima del nivel de graduación?
            hint = self.one("SELECT count(DISTINCT mint) FROM trades WHERE mc >= 1000000")
            reason += f" Indicio no concluyente: {hint} tokens con MC>=1M en trades."
        elif n_mig == 0:
            status, cov, reason = "FAIL", 0.0, "Frontera definida pero ningún token migró en el corpus."
        else:
            cov = self.one("SELECT avg(CAST(has_post_price AS DOUBLE)) FROM mig_cov")
            post_any = self.one("SELECT avg(CAST(has_post_trades AS DOUBLE)) FROM mig_cov")
            if cov < 0.01:
                status, reason = "FAIL", "Los datos terminan en la bonding curve (sin precio post-migración)."
            elif cov >= 0.95:
                status, reason = "PASS_EXCELLENT", ">=95% de migraciones con precio posterior."
            elif cov >= 0.80:
                status, reason = "PASS_USABLE", "80-95%: usable con análisis de missingness."
            else:
                status, reason = "PARTIAL_NO_GLOBAL_CLAIMS", "<80%: no hacer claims globales post-migración."
            reason += f" (trades post cualquiera: {post_any:.1%})"
        bad_boundary = self.one("""SELECT count(*) FROM boundary b JOIN tokens t USING(mint)
                                   WHERE b.boundary_ts < t.created_at""") if n_mig else 0
        grad = self.rows("""SELECT quantile_cont(epoch(b.boundary_ts - t.created_at)/60.0, [0.25,0.5,0.75])
                            FROM boundary b JOIN tokens t USING(mint) WHERE b.boundary_ts >= t.created_at""")
        g = grad[0][0] if grad and grad[0][0] else None
        self.boundary_src = boundary_src
        self.r["post_migration"] = {
            "status": status, "boundary_source": boundary_src, "n_migrated": n_mig,
            "coverage_price_after_migration": None if cov is None else round(cov, 4),
            "boundaries_before_creation": bad_boundary, "reason": reason,
        }
        self.r["post_migration_coverage"] = None if cov is None else round(cov, 4)
        self.r["median_time_to_graduation"] = None if not g else {
            "minutes_p25": round(g[0], 2), "minutes_p50": round(g[1], 2), "minutes_p75": round(g[2], 2)}
        self.r["graduation_rate"] = round(n_mig / max(self.r["n_tokens"], 1), 6) if boundary_src else None

    # ---------------- BLOQUE B: ATH por token + clase de observabilidad
    def ath(self):
        con = self.con
        src = self.obs_table()
        oc = self.cfg["outcome"]
        tol = self.cfg["quality"]["reconstruction_tolerance"]
        con.execute(f"""CREATE OR REPLACE TABLE tok_ath AS
            SELECT mint, max(mc) AS ath_mc, arg_max(ts, mc) AS ath_ts, min(ts) AS first_ts,
                   max(ts) AS last_ts, arg_max(mc, ts) AS last_mc, count(*) AS n_obs,
                   bool_or(mc_obs_direct IS NOT NULL) AS any_direct
            FROM {src} WHERE mc IS NOT NULL AND mc > 0 AND ts IS NOT NULL GROUP BY mint""")
        con.execute(f"""CREATE OR REPLACE TABLE tok_label AS
            SELECT t.mint, t.created_at, a.ath_mc, a.ath_ts, a.first_ts, a.last_ts, a.last_mc, a.n_obs,
              b.boundary_ts, mc.has_post_price,
              CASE
                WHEN a.mint IS NULL THEN 'no_price'
                WHEN b.boundary_ts IS NOT NULL AND NOT COALESCE(mc.has_post_price, FALSE) THEN 'unobservable_censored_at_migration'
                WHEN a.last_ts >= TIMESTAMP '{self.t_max}' - INTERVAL '{int(oc['censor_window_hours'])} hours'
                     THEN 'observed_lower_bound_right_censored'
                ELSE 'observed_final'
              END AS ath_class,
              CASE WHEN a.any_direct THEN 'observed' WHEN a.mint IS NOT NULL THEN 'reconstructed' END AS ath_method
            FROM tokens t LEFT JOIN tok_ath a USING(mint)
            LEFT JOIN boundary b USING(mint) LEFT JOIN mig_cov mc USING(mint)""")
        dist = dict(self.rows("SELECT ath_class, count(*) FROM tok_label GROUP BY 1"))
        n = max(self.r["n_tokens"], 1)
        observable = sum(v for k, v in dist.items() if k.startswith("observed"))
        self.r["ath_observable_rate"] = round(observable / n, 6)
        self.r["ath_class_counts"] = dist

        # validez de la reconstrucción: comparar MC reconstruido vs observado donde coexisten
        recon = {"status": "NOT_NEEDED"}
        n_recon = self.one(f"SELECT count(*) FROM {src} WHERE mc_reconstructed IS NOT NULL")
        if n_recon:
            if self.c.present["snapshots"] and src == "trades":
                other = "snapshots"
            elif src == "snapshots":
                other = "trades"
            else:
                other = None
            agree = None
            if other:
                agree = self.rows(f"""
                    WITH a AS (SELECT mint, ts, mc FROM {src} WHERE mc_reconstructed IS NOT NULL),
                         b AS (SELECT mint, ts, mc_obs_direct AS mcd FROM {other} WHERE mc_obs_direct IS NOT NULL),
                         j AS (SELECT a.mc / b.mcd AS ratio, a.ts - b.ts AS dt FROM a ASOF JOIN b ON a.mint=b.mint AND a.ts >= b.ts)
                    SELECT count(*), avg(CASE WHEN abs(ratio-1) <= {tol} THEN 1.0 ELSE 0.0 END),
                           median(ratio) FROM j WHERE dt <= INTERVAL '60 seconds'""")[0]
            if agree and agree[0] and agree[0] >= 100:
                ok = agree[1] >= 0.90
                recon = {"status": "VALIDATED" if ok else "FAILED", "n_pairs": agree[0],
                         "share_within_tolerance": round(agree[1], 4), "median_ratio": round(agree[2], 4),
                         "tolerance": tol}
            else:
                recon = {"status": "UNVALIDATED",
                         "why": "No hay MC observado directo solapado (<=60s) para contrastar la reconstrucción.",
                         "n_pairs": agree[0] if agree else 0}
        self.r["mc_definition"] = {
            "formula": "MC(t) = precio del token en el activo del par × USD del par (ASOF ≤ t) × supply",
            "supply": self.c.supply_desc,
            "quote_usd": self.c.sol_usd_method,
            "primary_source": src,
            "reconstruction": recon,
            "comparable": recon.get("status") in ("NOT_NEEDED", "VALIDATED"),
        }
        if recon.get("status") in ("UNVALIDATED", "FAILED"):
            self.c.notes.append(f"MC reconstruido {recon['status']}: los umbrales USD no son demostrablemente comparables.")

    # ---------------- BLOQUE C: cruces raw y validados
    def crosses(self):
        con = self.con
        src = self.obs_table()
        cc = self.cfg["cross"]
        W = int(cc["window_seconds"])
        k = int(cc["min_followups"])
        ths = sorted(set(self.cfg["thresholds_usd"]) | set(self.cfg["extra_thresholds_usd"]))
        lo = min(ths)
        con.execute(f"""CREATE OR REPLACE TABLE cand_obs AS
            SELECT o.mint, o.ts, o.mc, lag(o.ts) OVER (PARTITION BY o.mint ORDER BY o.ts) AS prev_ts
            FROM {src} o WHERE o.mint IN (SELECT a.mint FROM tok_ath a JOIN tokens t USING(mint) WHERE a.ath_mc >= {lo})
              AND o.mc IS NOT NULL AND o.ts IS NOT NULL""")
        agg = "min(mc)" if cc["rule"] == "all" else "quantile_cont(mc, 0.5)"
        con.execute(f"""CREATE OR REPLACE TABLE cand_obs AS
            SELECT *, count(*) OVER w AS n_next, {agg} OVER w AS next_stat
            FROM cand_obs
            WINDOW w AS (PARTITION BY mint ORDER BY ts
                         RANGE BETWEEN CURRENT ROW AND INTERVAL '{W} seconds' FOLLOWING EXCLUDE CURRENT ROW)""")
        parts = []
        for X in ths:
            parts.append(f"""
              SELECT mint, {X}::DOUBLE AS threshold,
                min(ts) FILTER (WHERE mc >= {X}) AS raw_cross_ts,
                arg_min(prev_ts, ts) FILTER (WHERE mc >= {X}) AS raw_prev_ts,
                min(ts) FILTER (WHERE mc >= {X} AND n_next >= {k} AND next_stat >= {X}) AS val_cross_ts,
                arg_min(prev_ts, ts) FILTER (WHERE mc >= {X} AND n_next >= {k} AND next_stat >= {X}) AS val_prev_ts
              FROM cand_obs GROUP BY mint""")
        con.execute("CREATE OR REPLACE TABLE crosses AS " + " UNION ALL ".join(parts))
        con.execute("DELETE FROM crosses WHERE raw_cross_ts IS NULL")
        con.execute("""ALTER TABLE crosses ADD COLUMN bracket_gap_s DOUBLE;
                       UPDATE crosses SET bracket_gap_s = epoch(val_cross_ts - val_prev_ts);""")
        # snapshot usable más reciente ANTES (o en) el cruce validado — nunca después (anti-leakage)
        if self.c.present["snapshots"]:
            con.execute("""CREATE OR REPLACE TABLE crosses AS
                SELECT c.*, epoch(c.val_cross_ts - s.ts) AS snap_lag_s,
                       s.liquidity_usd AS snap_liq, s.holders AS snap_holders
                FROM crosses c ASOF LEFT JOIN
                     (SELECT mint, ts, liquidity_usd, holders FROM snapshots) s
                ON c.mint = s.mint AND c.val_cross_ts >= s.ts""")
        else:
            con.execute("""CREATE OR REPLACE TABLE crosses AS SELECT *, CAST(NULL AS DOUBLE) snap_lag_s,
                           CAST(NULL AS DOUBLE) snap_liq, CAST(NULL AS DOUBLE) snap_holders FROM crosses""")

        out = {}
        for X in self.cfg["thresholds_usd"]:
            row = self.one(f"""SELECT count(*), count(val_cross_ts),
                   avg(CASE WHEN bracket_gap_s <= 60 THEN 1.0 ELSE 0.0 END) FILTER (WHERE val_cross_ts IS NOT NULL),
                   avg(CASE WHEN bracket_gap_s <= 300 THEN 1.0 ELSE 0.0 END) FILTER (WHERE val_cross_ts IS NOT NULL),
                   avg(CASE WHEN bracket_gap_s <= 900 THEN 1.0 ELSE 0.0 END) FILTER (WHERE val_cross_ts IS NOT NULL),
                   avg(CASE WHEN bracket_gap_s <= 3600 THEN 1.0 ELSE 0.0 END) FILTER (WHERE val_cross_ts IS NOT NULL),
                   avg(CASE WHEN snap_lag_s <= 60 THEN 1.0 ELSE 0.0 END) FILTER (WHERE val_cross_ts IS NOT NULL),
                   avg(CASE WHEN snap_lag_s <= 300 THEN 1.0 ELSE 0.0 END) FILTER (WHERE val_cross_ts IS NOT NULL),
                   avg(CASE WHEN snap_lag_s <= 900 THEN 1.0 ELSE 0.0 END) FILTER (WHERE val_cross_ts IS NOT NULL),
                   avg(CASE WHEN snap_lag_s <= 3600 THEN 1.0 ELSE 0.0 END) FILTER (WHERE val_cross_ts IS NOT NULL)
                   FROM crosses WHERE threshold = {X}""")
            n_raw, n_val = row[0], row[1]
            r2 = lambda v: None if v is None else round(v, 4)
            out[fmt_usd(X)] = {
                "n_raw_cross": n_raw, "n_validated_cross": n_val,
                "n_spike_only (raw sin validar)": n_raw - n_val,
                "bracket_gap_le": {"1m": r2(row[2]), "5m": r2(row[3]), "15m": r2(row[4]), "1h": r2(row[5])},
                "snapshot_before_cross_le": {"1m": r2(row[6]), "5m": r2(row[7]), "15m": r2(row[8]), "1h": r2(row[9])}
                if self.c.present["snapshots"] else "ABSENT",
            }
            self.r[f"n_ge_{fmt_usd(X).lower()}"] = n_val
            self.r[f"n_ge_{fmt_usd(X).lower()}_raw"] = n_raw
        self.r["crosses"] = out
        for X in self.cfg["thresholds_usd"][:-1]:
            key = fmt_usd(X)
            self.r[f"cross_{key.lower()}_observability"] = out[key]["bracket_gap_le"]["15m"]

    # ---------------- BLOQUE I: calidad por token + tests globales
    def quality(self):
        con = self.con
        qc = self.cfg["quality"]
        has_s = self.c.present["snapshots"]
        liq = "avg(CASE WHEN liquidity_usd IS NOT NULL THEN 1.0 ELSE 0.0 END)" if (has_s and self.c.is_mapped("snapshots", "liquidity_usd")) else "NULL"
        hol = "avg(CASE WHEN holders IS NOT NULL THEN 1.0 ELSE 0.0 END)" if (has_s and self.c.is_mapped("snapshots", "holders")) else "NULL"
        snap_q = (f"""LEFT JOIN (SELECT mint, {liq} AS q_liq, {hol} AS q_hol FROM snapshots GROUP BY mint) s USING(mint)"""
                  if has_s else "LEFT JOIN (SELECT NULL::VARCHAR mint, NULL::DOUBLE q_liq, NULL::DOUBLE q_hol) s USING(mint)")
        wal = "avg(CASE WHEN tr.wallet IS NOT NULL THEN 1.0 ELSE 0.0 END)" if self.c.is_mapped("trades", "wallet") else "0.0"
        con.execute(f"""CREATE OR REPLACE TABLE tok_q AS
            WITH tq AS (
              SELECT tr.mint,
                avg(CASE WHEN tr.ts IS NOT NULL AND tr.ts >= t.created_at - INTERVAL '60 seconds' THEN 1.0 ELSE 0.0 END) AS q_ts,
                avg(CASE WHEN tr.px_quote > 0 OR tr.price_usd > 0 OR tr.mc_obs_direct > 0 THEN 1.0 ELSE 0.0 END) AS q_price,
                avg(CASE WHEN tr.mc > 0 THEN 1.0 ELSE 0.0 END) AS q_mc,
                {wal} AS q_wallet
              FROM trades tr JOIN tokens t USING(mint) GROUP BY tr.mint)
            SELECT l.mint, tq.q_ts AS Q_timestamp, tq.q_price AS Q_price, tq.q_mc AS Q_MC,
                   s.q_liq AS Q_liquidity, tq.q_wallet AS Q_wallet, s.q_hol AS Q_holder,
                   CASE WHEN l.boundary_ts IS NULL OR COALESCE(l.has_post_price, FALSE) THEN 1.0 ELSE 0.0 END AS Q_migration
            FROM tok_label l LEFT JOIN tq USING(mint) {snap_q}""")
        con.execute("""ALTER TABLE tok_q ADD COLUMN Q_total DOUBLE;
            UPDATE tok_q SET Q_total = least(COALESCE(Q_timestamp,0), COALESCE(Q_price,0), COALESCE(Q_MC,0),
                   COALESCE(Q_liquidity,1), COALESCE(Q_wallet,1), COALESCE(Q_holder,1), Q_migration);""")
        # Q_liquidity/Q_holder NULL => fuente ausente: no penaliza Q_total aquí; se exige en required_at_cross.

        tests = {}
        n_tr = max(self.r["n_trades"], 1)
        tests["trades_ts_null_rate"] = self.one("SELECT avg(CASE WHEN ts IS NULL THEN 1.0 ELSE 0.0 END) FROM trades")
        tests["trades_before_token_creation_rate"] = self.one(
            "SELECT avg(CASE WHEN tr.ts < t.created_at - INTERVAL '60 seconds' THEN 1.0 ELSE 0.0 END) FROM trades tr JOIN tokens t USING(mint)")
        tests["tokens_created_at_null"] = self.one("SELECT count(*) FROM tokens WHERE created_at IS NULL")
        if self.c.is_mapped("trades", "signature"):
            key = "signature, mint, wallet, side, quote_amt, tok_amt"
            dup = self.one(f"SELECT count(*) - (SELECT count(*) FROM (SELECT DISTINCT {key} FROM trades)) FROM trades")
            tests["duplicated_trade_rows"] = dup
            tests["duplicate_rate"] = dup / n_tr
        else:
            tests["duplicated_trade_rows"] = "UNKNOWN (signature no mapeada)"
            tests["duplicate_rate"] = None
        tests["duplicated_token_rows"] = self.r["n_tokens_raw_rows"] - self.r["n_tokens"]
        tests["tokens_with_multiple_creation_ts"] = self.one(
            "SELECT count(*) FROM (SELECT mint FROM tokens_raw GROUP BY mint HAVING count(DISTINCT created_at) > 1)")
        tests["orphan_trades"] = self.one("SELECT count(*) FROM trades WHERE mint NOT IN (SELECT mint FROM tokens)")
        tests["orphan_rate"] = tests["orphan_trades"] / n_tr
        tests["trades_with_null_mint"] = self.one("SELECT count(*) FROM trades WHERE mint IS NULL")
        if self.c.present["migrations"]:
            tests["migrations_without_token"] = self.one("SELECT count(*) FROM migrations WHERE mint NOT IN (SELECT mint FROM tokens)")
            tests["migrations_multiple_rows_per_token"] = self.one("SELECT count(*) FROM migrations WHERE n_rows > 1")
        if self.c.present["snapshots"]:
            tests["orphan_snapshots"] = self.one("SELECT count(*) FROM snapshots WHERE mint NOT IN (SELECT mint FROM tokens)")
            tests["duplicated_snapshot_mint_ts"] = self.one(
                "SELECT count(*) - (SELECT count(*) FROM (SELECT DISTINCT mint, ts FROM snapshots)) FROM snapshots")
            tests["snapshot_mc_null_rate"] = self.one("SELECT avg(CASE WHEN mc IS NULL THEN 1.0 ELSE 0.0 END) FROM snapshots")
        tests["trades_price_invalid_rate"] = self.one(
            "SELECT avg(CASE WHEN COALESCE(px_quote, price_usd, mc_obs_direct) IS NULL OR COALESCE(px_quote, price_usd, mc_obs_direct) <= 0 THEN 1.0 ELSE 0.0 END) FROM trades")
        tests["trades_mc_null_rate"] = self.one("SELECT avg(CASE WHEN mc IS NULL THEN 1.0 ELSE 0.0 END) FROM trades")
        tests["quote_price_coverage_by_asset"] = {
            a: {"trades": n, "quote_usd_available": round(c, 4)}
            for a, n, c in self.rows("""SELECT quote_asset, count(*), avg(CASE WHEN quote_usd IS NOT NULL THEN 1.0 ELSE 0.0 END)
                                        FROM trades GROUP BY 1 ORDER BY 2 DESC LIMIT 50""")}
        J = float(qc["price_jump_ratio"])
        tests["price_jump_rate"] = self.one(f"""
            WITH x AS (SELECT mc / lag(mc) OVER (PARTITION BY mint ORDER BY ts) AS r FROM trades WHERE mc > 0)
            SELECT avg(CASE WHEN r > {J} OR r < {1/J} THEN 1.0 ELSE 0.0 END) FROM x WHERE r IS NOT NULL""")
        if self.c.present["snapshots"]:
            G = int(qc["snapshot_gap_seconds"])
            tests["gap_rate"] = self.one(f"""
                WITH x AS (SELECT epoch(ts - lag(ts) OVER (PARTITION BY mint ORDER BY ts)) g FROM snapshots)
                SELECT avg(CASE WHEN g > {G} THEN 1.0 ELSE 0.0 END) FROM x WHERE g IS NOT NULL""")
        else:
            tests["gap_rate"] = None
        if self.c.is_mapped("trades", "wallet"):
            tests["wallet_address_invalid_len_rate"] = self.one(
                "SELECT avg(CASE WHEN length(wallet) NOT BETWEEN 32 AND 44 THEN 1.0 ELSE 0.0 END) FROM trades WHERE wallet IS NOT NULL")
        for kk, v in list(tests.items()):
            if isinstance(v, float):
                tests[kk] = round(v, 6)
        self.r["quality_tests"] = tests
        self.r["orphan_rate"] = tests["orphan_rate"]
        self.r["duplicate_rate"] = tests["duplicate_rate"]
        self.r["gap_rate"] = tests["gap_rate"]
        qd = self.rows("SELECT quantile_cont(Q_total, [0.05, 0.25, 0.5]), avg(CASE WHEN Q_total >= %f THEN 1.0 ELSE 0.0 END) FROM tok_q"
                       % qc["q_min"])[0]
        self.r["quality_score"] = {"Q_total_p05_p25_p50": [round(x, 4) for x in qd[0]] if qd[0] else None,
                                   "share_tokens_Q_total_ge_q_min": round(qd[1], 4) if qd[1] is not None else None,
                                   "q_min": qc["q_min"],
                                   "note": "Q solo decide admisión; NO es feature predictiva."}

    # ---------------- BLOQUE J: granularidad temporal
    def granularity(self):
        out = {}
        for tbl in ["snapshots", "trades"]:
            if tbl == "snapshots" and not self.c.present["snapshots"]:
                out[tbl] = "ABSENT"
                continue
            row = self.rows(f"""
                WITH x AS (SELECT mint, epoch(ts - lag(ts) OVER (PARTITION BY mint ORDER BY ts)) g FROM {tbl} WHERE ts IS NOT NULL),
                     pt AS (SELECT mint, max(g) mg FROM x GROUP BY mint)
                SELECT quantile_cont(g, [0.25, 0.5, 0.75]), max(g),
                       (SELECT median(mg) FROM pt WHERE mg IS NOT NULL)
                FROM x WHERE g IS NOT NULL""")[0]
            out[tbl] = {"interval_seconds_p25": row[0][0] if row[0] else None,
                        "interval_seconds_median": row[0][1] if row[0] else None,
                        "interval_seconds_p75": row[0][2] if row[0] else None,
                        "max_gap_seconds": row[1],
                        "median_per_token_max_gap_seconds": row[2]}
        self.r["snapshot_cadence"] = out

    # ---------------- BLOQUE A: matriz de cobertura (medida con datos)
    def coverage_matrix(self):
        rt = lambda v: None if v is None else round(v, 4)
        m = {}
        tr = self.rows("""SELECT min(ts), max(ts), count(DISTINCT mint), count(*),
                 avg(CASE WHEN wallet IS NOT NULL THEN 1.0 ELSE 0.0 END),
                 avg(CASE WHEN wallet IS NOT NULL AND tok_amt IS NOT NULL AND side IS NOT NULL THEN 1.0 ELSE 0.0 END),
                 avg(CASE WHEN mc IS NOT NULL THEN 1.0 ELSE 0.0 END) FROM trades""")[0]
        wallet_ts = self.one("SELECT avg(CASE WHEN wallet IS NOT NULL AND ts IS NOT NULL THEN 1.0 ELSE 0.0 END) FROM trades")
        m["trades"] = {"range": [str(tr[0]), str(tr[1])], "tokens": tr[2], "rows": tr[3],
                       "resolution_median_s": (self.r["snapshot_cadence"]["trades"] or {}).get("interval_seconds_median")
                       if isinstance(self.r["snapshot_cadence"]["trades"], dict) else None,
                       "wallet": rt(tr[4]),
                       "holder": ("INDIRECT (reconstruible desde trades; transfers no observados)" if (tr[5] or 0) > 0.95
                                  else f"INSUFFICIENT ({rt(tr[5])} filas con wallet+amount+side)"),
                       "liquidity": "ABSENT", "mc": rt(tr[6]),
                       "post_migration": self.r["post_migration"]["status"]}
        self.r["wallet_timestamp_coverage"] = rt(wallet_ts)
        if self.c.present["snapshots"]:
            s = self.rows("""SELECT min(ts), max(ts), count(DISTINCT mint), count(*),
                 avg(CASE WHEN holders IS NOT NULL THEN 1.0 ELSE 0.0 END),
                 avg(CASE WHEN liquidity_usd IS NOT NULL THEN 1.0 ELSE 0.0 END),
                 avg(CASE WHEN mc IS NOT NULL THEN 1.0 ELSE 0.0 END) FROM snapshots""")[0]
            post_snap = self.one("SELECT avg(CASE WHEN n_post_snap > 0 THEN 1.0 ELSE 0.0 END) FROM mig_cov") \
                if self.r["post_migration"]["n_migrated"] else None
            m["snapshots"] = {"range": [str(s[0]), str(s[1])], "tokens": s[2], "rows": s[3],
                              "resolution_median_s": self.r["snapshot_cadence"]["snapshots"]["interval_seconds_median"],
                              "wallet": "ABSENT", "holder": rt(s[4]), "liquidity": rt(s[5]), "mc": rt(s[6]),
                              "post_migration": rt(post_snap)}
            self.r["holder_timestamp_coverage"] = rt(s[4])
        else:
            m["snapshots"] = "ABSENT"
            self.r["holder_timestamp_coverage"] = "ABSENT (solo reconstruible desde trades)"
        tk = self.rows("""SELECT min(created_at), max(created_at), count(*),
                 avg(CASE WHEN creator IS NOT NULL THEN 1.0 ELSE 0.0 END) FROM tokens""")[0]
        m["tokens"] = {"range": [str(tk[0]), str(tk[1])], "tokens": tk[2], "creator": rt(tk[3])}
        if self.c.present["migrations"]:
            mg = self.rows("SELECT min(ts), max(ts), count(*), avg(CASE WHEN pool IS NOT NULL THEN 1.0 ELSE 0.0 END) FROM migrations")[0]
            m["migrations"] = {"range": [str(mg[0]), str(mg[1])], "tokens": mg[2], "pool": rt(mg[3])}
        else:
            m["migrations"] = "ABSENT"
        self.r["coverage_matrix"] = m

    # ---------------- BLOQUE K: social point-in-time
    def social(self):
        fields = [f for f in ["twitter", "telegram", "website", "discord", "description"] if self.c.is_mapped("tokens", f)]
        if not fields:
            self.r["social_at_launch_coverage"] = "ABSENT (ningún campo social mapeado)"
        else:
            per = {f: round(self.one(f"SELECT avg(CASE WHEN {f} IS NOT NULL THEN 1.0 ELSE 0.0 END) FROM tokens"), 4) for f in fields}
            name_cov = self.one("SELECT avg(CASE WHEN name IS NOT NULL OR symbol IS NOT NULL THEN 1.0 ELSE 0.0 END) FROM tokens")
            self.r["social_at_launch_coverage"] = {
                "metadata_present_rate (name o symbol)": round(name_cov, 4),
                "field_presence_rate": per,
                "point_in_time": "VERIFIED_BY_USER" if self.cfg["metadata_is_launch_time"] else "UNVERIFIED",
                "note": "Presencia de campo = el token lo anunció. Ausencia puede ser 'no anunciado' o 'no capturado': "
                        "solo es interpretable si metadata_present_rate ~1.",
            }
        if self.c.present["social_history"]:
            n = self.one("SELECT count(DISTINCT mint) FROM social_history")
            self.r["social_at_threshold_coverage"] = {"tokens_with_history": n}
        else:
            self.r["social_at_threshold_coverage"] = "UNKNOWN (sin historial de cambios; no se imputa)"

    # ---------------- BLOQUE M: regímenes (descriptivos, v0)
    def regimes(self):
        con = self.con
        rc = self.cfg["regimes"]
        R = int(rc["rolling_days"])
        sol = ""
        if self.c.present["sol_price"]:
            sol = f""", sol0 AS (SELECT date_trunc('day', ts) d, arg_max(price_usd, ts) AS sol_px FROM sol_price GROUP BY 1),
                 sol AS (SELECT d, sol_px, sol_px / lag(sol_px, {R}) OVER (ORDER BY d) - 1 AS sol_ret_R FROM sol0)"""
        con.execute(f"""CREATE OR REPLACE TABLE daily AS
            WITH l AS (SELECT date_trunc('day', created_at) d, count(*) launches FROM tokens WHERE created_at IS NOT NULL GROUP BY 1),
                 g AS (SELECT date_trunc('day', boundary_ts) d, count(*) grads FROM boundary GROUP BY 1),
                 v AS (SELECT date_trunc('day', ts) d, sum(quote_amt * quote_usd) vol_usd FROM trades WHERE ts IS NOT NULL GROUP BY 1)
                 {sol}
            SELECT l.d, l.launches, COALESCE(g.grads,0) grads, v.vol_usd
                   {', sol.sol_px AS sol_close, sol.sol_ret_R' if sol else ''}
            FROM l LEFT JOIN g USING(d) LEFT JOIN v USING(d) {'LEFT JOIN sol USING(d)' if sol else ''} ORDER BY l.d""")
        solcols = ""
        con.execute(f"""CREATE OR REPLACE TABLE daily AS
            SELECT *, avg(launches) OVER (ORDER BY d ROWS BETWEEN {R-1} PRECEDING AND CURRENT ROW) AS launches_R,
                   sum(grads) OVER (ORDER BY d ROWS BETWEEN {R-1} PRECEDING AND CURRENT ROW)
                     / NULLIF(sum(launches) OVER (ORDER BY d ROWS BETWEEN {R-1} PRECEDING AND CURRENT ROW), 0) AS grad_rate_R
                   {solcols}
            FROM daily""")
        nb = int(rc["bins"])
        lab = f"'L' || ntile({nb}) OVER (ORDER BY launches_R)"
        desc = [f"{nb}-tiles de launches/día ({R}d)"]
        if rc["use_grad_rate"]:
            lab += f" || '_G' || CASE WHEN grad_rate_R IS NULL THEN 'NA' ELSE CAST(ntile({nb}) OVER (ORDER BY grad_rate_R) AS VARCHAR) END"
            desc.append(f"{nb}-tiles de tasa de graduación ({R}d)")
        if sol and rc["use_sol"]:
            lab += " || '_SOL' || CASE WHEN sol_ret_R IS NULL THEN 'NA' WHEN sol_ret_R >= 0 THEN 'UP' ELSE 'DN' END"
            desc.append(f"signo retorno SOL ({R}d)")
        elif rc["use_sol"]:
            desc.append("(SOL no disponible)")
        con.execute(f"CREATE OR REPLACE TABLE daily AS SELECT *, {lab} AS regime_id FROM daily")
        allreg = self.rows("SELECT regime_id, count(*) FROM daily GROUP BY 1 ORDER BY 1")
        md = int(rc["min_days_per_regime"])
        self.r["regime_count"] = sum(1 for _, n in allreg if n >= md)
        self.r["regimes"] = {
            "definition": " × ".join(desc),
            "days_per_regime (todos)": dict(allreg),
            "min_days_per_regime": md,
            "warning": "Terciles calculados sobre todo el corpus: válido para estratificar/describir. "
                       "Para modelar, recalcular con cortes expanding-window (point-in-time).",
        }

    # ---------------- BLOQUES D, E, F, L, P, Q, R: cohortes por etapa, N efectivo, potencia
    def stages(self):
        con = self.con
        cfgc, oc, qc = self.cfg["cross"], self.cfg["outcome"], self.cfg["quality"]
        req = set(self.cfg["required_at_cross"])
        ths = self.cfg["thresholds_usd"]
        max_bracket = int(cfgc["max_bracket_gap_seconds"])
        snap_lag = int(self.cfg["snapshot_max_lag_seconds"])
        crit = int(qc["critical_gap_seconds"])
        src = self.obs_table()

        # checks por (token, umbral) en el instante del cruce validado
        wallet_mapped = self.c.is_mapped("trades", "wallet")
        wcov = "avg(CASE WHEN t.wallet IS NOT NULL THEN 1.0 ELSE 0.0 END)" if wallet_mapped else "0.0"
        con.execute(f"""CREATE OR REPLACE TABLE cross_ctx AS
            WITH c AS (SELECT * FROM crosses WHERE val_cross_ts IS NOT NULL),
            w AS (SELECT c.mint, c.threshold, {wcov} AS wallet_cov_pre
                  FROM c JOIN trades t ON t.mint = c.mint AND t.ts <= c.val_cross_ts GROUP BY 1, 2),
            g0 AS (SELECT c.mint, c.threshold, o.ts,
                          epoch(o.ts - lag(o.ts) OVER (PARTITION BY c.mint, c.threshold ORDER BY o.ts)) AS g
                   FROM c JOIN {src} o ON o.mint = c.mint
                    AND o.ts BETWEEN c.val_cross_ts - INTERVAL '3600 seconds' AND c.val_cross_ts),
            g AS (SELECT mint, threshold, max(g) AS max_gap_1h FROM g0 GROUP BY 1, 2)
            SELECT c.mint, c.threshold, c.val_cross_ts, c.bracket_gap_s, c.snap_lag_s, c.snap_liq, c.snap_holders,
                   w.wallet_cov_pre, g.max_gap_1h
            FROM c LEFT JOIN w USING(mint, threshold) LEFT JOIN g USING(mint, threshold)""")
        social_fields = [f for f in ["twitter", "telegram", "website"] if self.c.is_mapped("tokens", f)]
        social_known = ("(t.name IS NOT NULL OR t.symbol IS NOT NULL)" if social_fields else "FALSE")
        conds = {
            "observable_cross": f"x.bracket_gap_s IS NOT NULL AND x.bracket_gap_s <= {max_bracket}",
            "wallet": f"COALESCE(x.wallet_cov_pre,0) >= {qc['wallet_min_coverage']}",
            "social_launch": social_known,
            "snapshot_liquidity": f"x.snap_lag_s IS NOT NULL AND x.snap_lag_s <= {snap_lag} AND x.snap_liq IS NOT NULL",
            "snapshot_holders": f"x.snap_lag_s IS NOT NULL AND x.snap_lag_s <= {snap_lag} AND x.snap_holders IS NOT NULL",
            "quality": f"COALESCE(q.Q_total,0) >= {qc['q_min']} AND COALESCE(x.max_gap_1h, 0) <= {crit} AND t.created_at IS NOT NULL",
        }
        complete_sql = " AND ".join(f"({conds[k]})" for k in ["wallet", "social_launch", "snapshot_liquidity", "snapshot_holders"] if k in req) or "TRUE"
        con.execute(f"""CREATE OR REPLACE TABLE cross_flags AS
            SELECT x.*, l.ath_mc, l.last_ts, l.last_mc, l.ath_class,
              ({conds['observable_cross']}) AS ok_cross,
              ({conds['wallet']}) AS ok_wallet, ({conds['social_launch']}) AS ok_social,
              ({conds['snapshot_liquidity']}) AS ok_liq, ({conds['snapshot_holders']}) AS ok_hold,
              ({complete_sql}) AS ok_complete,
              ({conds['quality']}) AS ok_quality
            FROM cross_ctx x JOIN tok_label l USING(mint) JOIN tokens t USING(mint) LEFT JOIN tok_q q USING(mint)""")

        tmax = f"TIMESTAMP '{self.t_max}'"
        fu = int(oc["followup_days"])
        cw = int(oc["censor_window_hours"])
        stages_out = {}
        power_out = {}
        pw = self.cfg["power"]
        n_stages = len(ths) - 1
        n_tests = n_stages * len(pw["k_values"]) * int(pw["models_tested"]) * int(pw["temporal_cuts"])
        alpha_adj = pw["alpha"] / n_tests
        self.r["multiplicity_registry"] = {
            "stages": n_stages, "k_values": pw["k_values"], "models_tested": pw["models_tested"],
            "temporal_cuts": pw["temporal_cuts"], "n_tests": n_tests,
            "alpha": pw["alpha"], "alpha_bonferroni": alpha_adj,
            "rule": "K fijados antes de ver resultados; no se elige a posteriori el K que mejor queda.",
        }
        n_eff_entry = {}
        for X in ths:  # N por umbral de entrada (sin exigir outcome)
            row = self.one(f"""SELECT count(*), count(*) FILTER (WHERE ok_cross),
                   count(*) FILTER (WHERE ok_cross AND ok_complete),
                   count(*) FILTER (WHERE ok_cross AND ok_complete AND ok_quality)
                   FROM cross_flags WHERE threshold = {X}""")
            n_eff_entry[X] = row
            self.r[f"n_effective_{fmt_usd(X).lower()}"] = row[3]

        for A, B in zip(ths[:-1], ths[1:]):
            name = f"{fmt_usd(A)}->{fmt_usd(B)}"
            con.execute(f"""CREATE OR REPLACE TABLE stage_tmp AS
                SELECT f.*, cb.val_cross_ts AS cross_B,
                  (cb.val_cross_ts IS NOT NULL) AS reached_B,
                  (cb.val_cross_ts IS NOT NULL
                     OR {tmax} - f.val_cross_ts >= INTERVAL '{fu} days'
                     OR f.last_ts < {tmax} - INTERVAL '{cw} hours') AS outcome_observable
                FROM cross_flags f
                LEFT JOIN crosses cb ON cb.mint = f.mint AND cb.threshold = {B}
                WHERE f.threshold = {A}""")
            row = self.one("""SELECT count(*),
                   count(*) FILTER (WHERE ok_cross AND outcome_observable),
                   count(*) FILTER (WHERE ok_cross AND outcome_observable AND ok_complete),
                   count(*) FILTER (WHERE ok_cross AND outcome_observable AND ok_complete AND ok_quality),
                   count(*) FILTER (WHERE ok_cross AND outcome_observable AND ok_complete AND ok_quality AND reached_B),
                   count(*) FILTER (WHERE reached_B)
                   FROM stage_tmp""")
            n_reach, n_obs, n_comp, n_eff, events, events_raw = row
            # razones de exclusión (no excluyentes)
            reasons = dict(zip(
                ["cross_not_bracketed", "outcome_censored", "wallet", "social_launch", "snapshot_liquidity", "snapshot_holders", "quality"],
                self.one("""SELECT count(*) FILTER (WHERE NOT ok_cross), count(*) FILTER (WHERE NOT outcome_observable),
                    count(*) FILTER (WHERE NOT ok_wallet), count(*) FILTER (WHERE NOT ok_social),
                    count(*) FILTER (WHERE NOT ok_liq), count(*) FILTER (WHERE NOT ok_hold),
                    count(*) FILTER (WHERE NOT ok_quality) FROM stage_tmp""")))
            reasons = {k: v for k, v in reasons.items() if k in ("cross_not_bracketed", "outcome_censored", "quality") or k in req}
            # velocidad hasta A (Bloque F)
            speed = dict(self.rows(f"""SELECT CASE WHEN epoch(s.val_cross_ts - t.created_at) < 3600 THEN 'FAST_<1h'
                       WHEN epoch(s.val_cross_ts - t.created_at) < 86400 THEN 'MEDIUM_1h-24h' ELSE 'SLOW_>24h' END b,
                       count(*) FROM stage_tmp s JOIN tokens t USING(mint)
                       WHERE ok_cross AND outcome_observable AND ok_complete AND ok_quality GROUP BY 1"""))
            speed_ev = dict(self.rows(f"""SELECT CASE WHEN epoch(s.val_cross_ts - t.created_at) < 3600 THEN 'FAST_<1h'
                       WHEN epoch(s.val_cross_ts - t.created_at) < 86400 THEN 'MEDIUM_1h-24h' ELSE 'SLOW_>24h' END b,
                       count(*) FROM stage_tmp s JOIN tokens t USING(mint)
                       WHERE ok_cross AND outcome_observable AND ok_complete AND ok_quality AND reached_B GROUP BY 1"""))
            # régimen en el cruce (Bloque F / M)
            by_reg = self.rows(f"""SELECT d.regime_id, count(*), count(*) FILTER (WHERE reached_B)
                       FROM stage_tmp s JOIN daily d ON d.d = date_trunc('day', s.val_cross_ts)
                       WHERE ok_cross AND outcome_observable AND ok_complete AND ok_quality GROUP BY 1 ORDER BY 1""")
            # false escalators (Bloque L): cruzan A, suben >= 2A, no llegan a B, y colapsan
            fe = self.one(f"""SELECT count(*) FROM stage_tmp
                       WHERE ok_cross AND outcome_observable AND NOT reached_B
                         AND ath_mc >= {2*A} AND last_mc <= 0.2 * ath_mc""")
            # leave-the-big-winner-out (Bloque R)
            ev_ath = [r[0] for r in self.rows("""SELECT ath_mc FROM stage_tmp
                       WHERE ok_cross AND outcome_observable AND ok_complete AND ok_quality AND reached_B ORDER BY ath_mc DESC""")]
            lbwo = {f"events_without_top{k}": max(len(ev_ath) - k, 0) for k in (1, 3, 5)}
            base = events / n_eff if n_eff else None
            stages_out[name] = {
                "N_reach": n_reach, "N_observable": n_obs, "N_complete": n_comp, "N_effective": n_eff,
                "events_effective (llegan a B)": events, "events_any_quality (llegan a B, sin filtros)": events_raw,
                "base_rate": None if base is None else round(base, 5),
                "base_rate_CI95_exact": clopper_pearson(events, n_eff) if n_eff else None,
                "model_tier": model_tier(events),
                "exclusion_reasons (no excluyentes)": reasons,
                "speed_bins_effective": speed, "speed_bins_events": speed_ev,
                "by_regime [regime, N_eff, events]": [list(r) for r in by_reg],
                "regimes_with_events": sum(1 for r in by_reg if r[2] > 0),
                "false_escalators (>=2x A, no B, colapso >=80%)": fe,
                "leave_big_winner_out": lbwo,
            }
            # Bloque E/P: potencia de Precision@K contra el nulo
            pk = {}
            for K in pw["k_values"]:
                if not n_eff or K > n_eff or not base or base <= 0:
                    pk[f"K={K}"] = "N/A (N_effective < K o base rate 0)"
                    continue
                h = next((h for h in range(0, K + 1) if binom_sf(h, K, base) <= alpha_adj), None)
                if h is None:
                    pk[f"K={K}"] = {"detectable": False,
                                    "why": f"ni K/K aciertos es significativo a alpha={alpha_adj:.2e} con base {base:.3f}"}
                    continue
                p_alt = min(1.0, pw["lift_to_detect"] * base)
                pk[f"K={K}"] = {"min_hits_significant": h, "min_detectable_precision": round(h / K, 3),
                                "min_detectable_lift": round((h / K) / base, 2),
                                f"power_at_lift_{pw['lift_to_detect']}x": round(binom_sf(h, K, p_alt), 3)}
            power_out[name] = pk
        self.r["stages"] = stages_out
        self.r["power_by_stage"] = power_out
        con.execute("DROP TABLE IF EXISTS stage_tmp")

    # ---------------- Decisión automática
    def decide(self):
        r = self.r
        reasons = []
        qt = r["quality_tests"]
        data_fail = []
        if (qt.get("trades_ts_null_rate") or 0) > 0.05:
            data_fail.append("timestamps nulos >5% en trades")
        if (qt.get("trades_mc_null_rate") or 0) > 0.20 and self.cfg["mc_source"] == "trades":
            data_fail.append("MC no calculable en >20% de trades (¿falta SOL/USD o supply?)")
        if isinstance(r.get("duplicate_rate"), float) and r["duplicate_rate"] > 0.05:
            data_fail.append("duplicados >5%")
        if (r.get("orphan_rate") or 0) > 0.05:
            data_fail.append("trades huérfanos >5%")
        if r["mc_definition"]["reconstruction"].get("status") == "FAILED":
            data_fail.append("reconstrucción de MC no coincide con MC observado")
        if self.c.sol_usd_method == "ABSENT" and not any(
                self.c.is_mapped(t, "mc_usd") or self.c.is_mapped(t, "price_usd") for t in ("trades", "snapshots")):
            data_fail.append("sin SOL/USD ni precio USD: umbrales en USD imposibles")
        if data_fail:
            decision, study = "DATA_FAIL", "INSUFFICIENT_DATA"
            reasons += data_fail
        elif r["post_migration"]["status"] in ("FAIL", "UNKNOWN", "PARTIAL_NO_GLOBAL_CLAIMS"):
            decision, study = "POST_MIGRATION_REQUIRED", "POST_MIGRATION_REQUIRED"
            reasons.append(f"post-migración: {r['post_migration']['status']} — {r['post_migration']['reason']}")
        else:
            first = list(r["stages"].values())[0]
            ev = first["events_effective (llegan a B)"]
            if ev < 20:
                decision, study = "LIMITED_SAMPLE", "CONDITIONAL_STAGE"
                reasons.append(f"etapa 1 con {ev} eventos efectivos (<20): solo análisis descriptivo")
            else:
                decision, study = "READY_STAGE_MODEL", "CONDITIONAL_STAGE"
                reasons.append(f"etapa 1 con {ev} eventos efectivos")
            n100 = r.get("n_effective_100m", 0) or 0
            if n100 >= 50:
                study = "DIRECT_Y100M"
                reasons.append(f"{n100} tokens >=100M efectivos: estudio directo posible")
        if not r["mc_definition"]["comparable"]:
            reasons.append("AVISO: MC reconstruido no validado; umbrales USD no demostrablemente comparables")
        r["DECISION"] = decision
        r["RECOMMENDED_STUDY"] = study
        r["decision_reasons"] = reasons
        r["stage_tiers"] = {k: v["model_tier"] for k, v in r["stages"].items()}

    def run(self):
        steps = [("bounds", self.corpus_bounds), ("migration", self.migration), ("ath", self.ath),
                 ("crosses", self.crosses), ("quality", self.quality), ("granularity", self.granularity),
                 ("coverage", self.coverage_matrix), ("social", self.social), ("regimes", self.regimes),
                 ("stages", self.stages), ("decide", self.decide)]
        timings = {}
        for name, fn in steps:
            t0 = time.time()
            print(f"  · {name} ...", file=sys.stderr, flush=True)
            fn()
            timings[name] = round(time.time() - t0, 2)
        self.r["_timings_s"] = timings
        return self.r


# --------------------------------------------------------------------------------------
# Salida
# --------------------------------------------------------------------------------------
def to_jsonable(o):
    if isinstance(o, dict):
        return {str(k): to_jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [to_jsonable(v) for v in o]
    if isinstance(o, float):
        return None if (math.isnan(o) or math.isinf(o)) else o
    if hasattr(o, "isoformat"):
        return o.isoformat()
    if hasattr(o, "item"):
        return o.item()
    try:
        json.dumps(o)
        return o
    except TypeError:
        return str(o)


def write_md(r: dict, path: str):
    L = []
    L.append(f"# H-100M · Fase 0.2 — informe de auditoría\n")
    L.append(f"**DECISIÓN: `{r['DECISION']}`** · estudio recomendado: `{r['RECOMMENDED_STUDY']}`\n")
    for x in r["decision_reasons"]:
        L.append(f"- {x}")
    L.append(f"\nCorpus: {r['corpus_date_min']} → {r['corpus_date_max']} · tokens {r['n_tokens']:,} · "
             f"trades {r['n_trades']:,} · snapshots {r['n_snapshots']:,} · migraciones {r['n_migrations']:,}\n")
    pm = r["post_migration"]
    L.append(f"## Post-migración\n`{pm['status']}` · cobertura {pm['coverage_price_after_migration']} · fuente de frontera: {pm['boundary_source']}\n\n{pm['reason']}\n")
    L.append("## Umbrales (cruce validado / raw)\n")
    L.append("| Umbral | validados | raw | solo spike | cruce acotado ≤15m | snapshot previo ≤5m |")
    L.append("|---|---|---|---|---|---|")
    for k, v in r["crosses"].items():
        sn = v["snapshot_before_cross_le"]
        sn5 = sn["5m"] if isinstance(sn, dict) else sn
        L.append(f"| {k} | {v['n_validated_cross']} | {v['n_raw_cross']} | {v['n_spike_only (raw sin validar)']} | "
                 f"{v['bracket_gap_le']['15m']} | {sn5} |")
    L.append("\n## Etapas\n")
    L.append("| Etapa | N_reach | N_obs | N_complete | N_eff | eventos | base | IC95 | tier |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for k, v in r["stages"].items():
        L.append(f"| {k} | {v['N_reach']} | {v['N_observable']} | {v['N_complete']} | {v['N_effective']} | "
                 f"{v['events_effective (llegan a B)']} | {v['base_rate']} | {v['base_rate_CI95_exact']} | {v['model_tier'].split(' ')[0]} |")
    L.append("\nRazones de exclusión por etapa (no excluyentes):\n")
    for k, v in r["stages"].items():
        L.append(f"- **{k}**: {v['exclusion_reasons (no excluyentes)']} · false escalators: "
                 f"{v['false_escalators (>=2x A, no B, colapso >=80%)']} · sin top-1/3/5: {list(v['leave_big_winner_out'].values())}")
    L.append(f"\n## Potencia (Precision@K vs nulo, α Bonferroni = {r['multiplicity_registry']['alpha_bonferroni']:.2e}, "
             f"{r['multiplicity_registry']['n_tests']} tests registrados)\n")
    for k, v in r["power_by_stage"].items():
        L.append(f"- **{k}**: " + "; ".join(f"{kk}: {vv}" for kk, vv in v.items()))
    L.append("\n## Definición de MC\n")
    md = r["mc_definition"]
    L.append(f"{md['formula']} · supply {md['supply']} · precio del par {md['quote_usd']} · fuente {md['primary_source']} · "
             f"reconstrucción `{md['reconstruction'].get('status')}` · comparable: {md['comparable']}\n")
    L.append("## Calidad\n")
    for k, v in r["quality_tests"].items():
        L.append(f"- {k}: {v}")
    L.append(f"\nQ-score: {r['quality_score']}\n")
    L.append("## Granularidad\n")
    L.append(f"```\n{json.dumps(r['snapshot_cadence'], indent=1, default=str)}\n```\n")
    L.append(f"## Social\n- at launch: {r['social_at_launch_coverage']}\n- at threshold: {r['social_at_threshold_coverage']}\n")
    L.append(f"## Regímenes\n{r['regime_count']} regímenes con ≥{r['_config']['regimes']['min_days_per_regime']} días. "
             f"{r['regimes']['definition']}\n")
    if r.get("notes"):
        L.append("## Notas\n" + "\n".join(f"- {n}" for n in r["notes"]))
    with open(path, "w") as f:
        f.write("\n".join(L) + "\n")


def introspect(cfg: dict, con):
    corpus = Corpus(cfg, con)
    synonyms = {
        "mint": ["mint", "token_address", "token", "address", "mint_address", "token_mint"],
        "created_at": ["created_at", "creation_time", "created", "created_timestamp", "launch_time", "block_time"],
        "creator": ["creator", "deployer", "dev", "creator_address"],
        "ts": ["ts", "timestamp", "block_time", "time", "blocktime", "slot_time", "datetime"],
        "signature": ["signature", "tx", "tx_hash", "txid", "transaction", "sig"],
        "wallet": ["wallet", "trader", "user", "owner", "signer", "maker", "buyer"],
        "side": ["side", "type", "direction", "trade_type"],
        "is_buy": ["is_buy", "isbuy", "buy"],
        "sol_amount": ["sol_amount", "sol", "amount_sol", "quote_amount", "lamports"],
        "token_amount": ["token_amount", "amount", "base_amount", "tokens"],
        "mc_usd": ["mc_usd", "market_cap", "marketcap", "usd_market_cap", "mcap"],
        "price_usd": ["price_usd", "usd_price"], "price_sol": ["price_sol", "price"],
        "liquidity_usd": ["liquidity_usd", "liquidity", "liq"], "holders": ["holders", "holder_count", "n_holders"],
        "v_sol": ["v_sol", "virtual_sol_reserves", "vsol"], "complete": ["complete", "is_complete", "graduated"],
        "pool": ["pool", "pool_address", "amm", "pair"], "venue": ["venue", "dex", "program", "source"],
        "name": ["name"], "symbol": ["symbol", "ticker"], "description": ["description", "desc"],
        "twitter": ["twitter", "x", "twitter_url"], "telegram": ["telegram", "tg"],
        "website": ["website", "web", "url"], "discord": ["discord"], "total_supply": ["total_supply", "supply"],
    }
    suggested = {"tables": {}}
    for table in LOGICAL:
        cols = corpus.raw_columns(table)
        if not cols:
            continue
        print(f"\n== {table} ({cfg['tables'][table]['path']})")
        for c, t in cols:
            print(f"   {c:32s} {t}")
        sample = con.execute(f"SELECT * FROM {corpus.reader(table)} LIMIT 2").fetchdf()
        print(sample.to_string(max_colwidth=40))
        real = {c.lower(): c for c, _ in cols}
        m = {}
        for logical in LOGICAL[table]:
            for s in synonyms.get(logical, [logical]):
                if s in real:
                    m[logical] = real[s]
                    break
        suggested["tables"][table] = {"path": cfg["tables"][table]["path"], "columns": m}
    print("\n== MAPEO SUGERIDO (VERIFICAR A MANO: sugerencia por nombre, no prueba de contenido)")
    print(json.dumps(suggested, indent=2))


def main():
    ap = argparse.ArgumentParser(description="H-100M Fase 0.2 — data + identification audit")
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", default="phase0_out")
    ap.add_argument("--db", default=None, help="fichero DuckDB (por defecto <out>/phase0.duckdb)")
    ap.add_argument("--memory-limit", default=None, help="p.ej. 12GB")
    ap.add_argument("--threads", type=int, default=None)
    ap.add_argument("--introspect", action="store_true")
    ap.add_argument("--keep-db", action="store_true", help="conservar el fichero DuckDB intermedio (puede ocupar GBs)")
    args = ap.parse_args()

    with open(args.config) as f:
        user_cfg = json.load(f)
    cfg = deep_merge(DEFAULTS, user_cfg)
    os.makedirs(args.out, exist_ok=True)
    con = duckdb.connect(":memory:" if args.introspect else (args.db or os.path.join(args.out, "phase0.duckdb")))
    con.execute("SET TimeZone='UTC'")
    tmpdir = os.path.join(args.out, "duckdb_tmp")
    con.execute(f"SET temp_directory={lit(tmpdir)}")
    if args.memory_limit:
        con.execute(f"SET memory_limit={lit(args.memory_limit)}")
    if args.threads:
        con.execute(f"SET threads={int(args.threads)}")

    if args.introspect:
        introspect(cfg, con)
        return

    corpus = Corpus(cfg, con)
    corpus.validate_mapping()
    t0 = time.time()
    print("Cargando y normalizando ...", file=sys.stderr)
    corpus.load()
    print("Auditando ...", file=sys.stderr)
    audit = Audit(cfg, corpus)
    r = audit.run()
    r["notes"] = corpus.notes
    r["_config"] = cfg
    r["_meta"] = {"version": VERSION, "run_utc": datetime.now(timezone.utc).isoformat(),
                  "elapsed_s": round(time.time() - t0, 1), "tables_present": corpus.present,
                  "mapped_fields": {k: sorted(v) for k, v in corpus.mapped.items()}}
    r = to_jsonable(r)
    with open(os.path.join(args.out, "phase0_report.json"), "w") as f:
        json.dump(r, f, indent=2, ensure_ascii=False)
    write_md(r, os.path.join(args.out, "phase0_report.md"))
    con.execute(f"""COPY (SELECT l.*, q.* EXCLUDE (mint) FROM tok_label l LEFT JOIN tok_q q USING(mint))
                    TO {lit(os.path.join(args.out, 'phase0_tokens.parquet'))} (FORMAT parquet)""")
    con.execute(f"""COPY (SELECT c.*, f.ok_cross, f.ok_complete, f.ok_quality, f.wallet_cov_pre, f.max_gap_1h
                    FROM crosses c LEFT JOIN cross_flags f USING(mint, threshold))
                    TO {lit(os.path.join(args.out, 'phase0_crosses.parquet'))} (FORMAT parquet)""")
    con.close()
    db_path = args.db or os.path.join(args.out, "phase0.duckdb")
    if not args.keep_db:
        for f in (db_path, db_path + ".wal"):
            if os.path.exists(f):
                os.remove(f)
    print(f"\nDECISIÓN: {r['DECISION']}  ·  estudio: {r['RECOMMENDED_STUDY']}")
    for x in r["decision_reasons"]:
        print(f"  - {x}")
    print(f"Informe: {os.path.join(args.out, 'phase0_report.json')}")


if __name__ == "__main__":
    main()

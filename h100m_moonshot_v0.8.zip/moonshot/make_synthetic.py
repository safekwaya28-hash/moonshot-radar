#!/usr/bin/env python3
"""
Corpus sintético con VERDAD CONOCIDA para verificar phase0_audit.py.

Escenario base (plantado):
  - 2000 tokens en 30 días; 200 migran; 180 con datos post-migración (cobertura 0.90 -> PASS_USABLE)
  - Ganadores post-migración:
      15  pico 1.5-1.9M              (cruzan 1M, no 2M)
       5  pico 2.5-5M y colapso 90%  (false escalators etapa 1M->10M)
      17  pico 15-40M                (uno con hueco de 67 min justo en el cruce de 1M)
       4  pico 60-90M
       4  pico 150-400M
       5  spikes: régimen ~500k con UN trade a 1.2M (cruce raw, NO validado)
  - 50 filas de trade duplicadas, 30 trades huérfanos, 1 token duplicado con otra fecha

Verdad esperada:
  n_ge_1m validado = 45 (raw 50) · n_ge_10m = 25 · n_ge_50m = 8 · n_ge_100m = 4
  etapa 1M->10M: N_reach 45, N_observable 44, eventos efectivos 24, false escalators 5
  etapa 10M->50M: N_eff 25, eventos 8 · etapa 50M->100M: N_eff 8, eventos 4
"""
import argparse
import json
import math
import os
import random

import numpy as np
import pandas as pd

START = pd.Timestamp("2026-05-01 00:00:00")
DAYS = 30
SUPPLY = 1e9
BOUNDARY_MC = 70_000.0


def sol_price_table():
    hours = pd.date_range(START - pd.Timedelta(days=1), START + pd.Timedelta(days=DAYS + 1), freq="h")
    rng = np.random.default_rng(1)
    px = 150 * np.exp(np.cumsum(rng.normal(0, 0.004, len(hours))))
    return pd.DataFrame({"ts": hours, "price_usd": px})


def make(outdir: str, scenario: str = "base", seed: int = 7):
    rnd = random.Random(seed)
    sol = sol_price_table()
    sol_px = sol["price_usd"].to_numpy()
    sol_t0 = sol["ts"].iloc[0]

    def sol_at(t):
        return float(sol_px[int((t - sol_t0).total_seconds() // 3600)])

    tokens, trades, snaps, migs = [], [], [], []
    truth = {"winners": {}}

    def wallet():
        return "".join(rnd.choice("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz") for _ in range(44))

    def add_trade(mint, t, mc, side=None):
        t = t.floor("s")
        su = sol_at(t)
        price_usd = mc / SUPPLY
        price_sol = price_usd / su
        sol_amt = rnd.uniform(0.1, 5.0)
        tok_amt = sol_amt / price_sol
        trades.append({
            "mint": mint, "block_time": int(t.timestamp()),  # epoch s
            "tx": f"{mint[:6]}-{len(trades)}", "trader": wallet(),
            "type": side or rnd.choice(["buy", "buy", "sell"]),
            "lamports": round(sol_amt * 1e9), "amount": round(tok_amt * 1e6),
        })

    def add_snaps(mint, created, full):
        ft = pd.Series([m for _, m in full], index=pd.DatetimeIndex([x for x, _ in full]))
        ts = created + pd.Timedelta(minutes=1)
        holders = 1
        while ts < full[-1][0]:
            mc_now = float(ft.asof(ts)) if ts >= ft.index[0] else 4_000.0
            holders += rnd.randint(0, 5)
            snaps.append({"mint": mint, "ts_ms": int(ts.timestamp() * 1000), "market_cap": mc_now,
                          "liquidity": mc_now * 0.1, "holder_count": holders})
            ts += pd.Timedelta(minutes=5)

    # ---- asignación de roles
    n_tokens = 2000
    roles = ["dead"] * n_tokens
    migrated_idx = list(range(200))
    post_idx = migrated_idx[:180]
    winners_plan = (["w1m"] * 15 + ["esc"] * 5 + ["w10m"] * 17 + ["w50m"] * 4 + ["w100m"] * 4 + ["spike"] * 5)
    for i, role in enumerate(winners_plan):
        roles[i] = role
    for i in post_idx:
        if roles[i] == "dead":
            roles[i] = "mig_post"
    for i in migrated_idx[180:]:
        roles[i] = "mig_nopost"
    gap_token_i = winners_plan.index("w10m")  # el primer w10m tiene hueco en el cruce de 1M

    for i in range(n_tokens):
        mint = f"MINT{i:05d}" + "x" * 34
        # los ganadores se crean en los primeros 20 días para que terminen antes del final del corpus
        day_max = 20 if roles[i] not in ("dead",) else DAYS - 0.5
        created = START + pd.Timedelta(minutes=rnd.uniform(0, day_max * 1440))
        tokens.append({
            "mint": mint, "created_at": created, "creator": wallet(),
            "name": f"Token {i}", "symbol": f"T{i}",
            "twitter": ("https://x.com/t%d" % i) if rnd.random() < 0.3 else None,
            "telegram": ("https://t.me/t%d" % i) if rnd.random() < 0.15 else None,
            "website": None, "description": "desc" if rnd.random() < 0.6 else None,
        })
        role = roles[i]
        # ---- fase bonding curve
        if role == "dead":
            peak = rnd.uniform(5_000, 40_000)
            n = rnd.randint(5, 40)
        else:
            peak = BOUNDARY_MC
            n = rnd.randint(40, 120)
        life_min = rnd.uniform(10, 240)
        t_pts = sorted(rnd.uniform(0, life_min) for _ in range(n))
        path = []
        for k, m in enumerate(t_pts):
            frac = (k + 1) / n
            mc = 4_000 * (peak / 4_000) ** frac * rnd.uniform(0.98, 1.02)
            t = created + pd.Timedelta(minutes=m)
            path.append((t, mc))
            add_trade(mint, t, mc)
        if role == "dead":
            continue
        boundary = path[-1][0] + pd.Timedelta(seconds=5)
        migs.append({"mint": mint, "migrated_at": boundary, "pool": "POOL" + mint[4:12]})
        if role == "mig_nopost" or scenario == "no_post":
            add_snaps(mint, created, path)   # snapshots solo de la fase bonding curve
            continue
        # ---- fase post-migración
        if role == "mig_post":
            pk, rise_h, final_frac = rnd.uniform(80_000, 600_000), rnd.uniform(1, 12), 0.3
        elif role == "w1m":
            pk, rise_h, final_frac = rnd.uniform(1.5e6, 1.9e6), rnd.uniform(2, 12), 0.5
        elif role == "esc":
            pk, rise_h, final_frac = rnd.uniform(2.5e6, 5e6), rnd.uniform(2, 12), 0.1
        elif role == "w10m":
            pk, rise_h, final_frac = rnd.uniform(15e6, 40e6), rnd.uniform(6, 14), 0.5
        elif role == "w50m":
            pk, rise_h, final_frac = rnd.uniform(60e6, 90e6), rnd.uniform(8, 16), 0.5
        elif role == "w100m":
            pk, rise_h, final_frac = rnd.uniform(150e6, 400e6), rnd.uniform(10, 20), 0.5
        elif role == "spike":
            pk, rise_h, final_frac = 500_000, rnd.uniform(3, 8), 0.8
        truth["winners"][mint] = {"role": role, "peak": pk}
        t = boundary + pd.Timedelta(seconds=10)
        t_peak = t + pd.Timedelta(hours=rise_h)
        t_end = t_peak + pd.Timedelta(hours=48)
        spike_done = False
        post_path = []
        while t < t_end:
            if t <= t_peak:
                frac = (t - boundary).total_seconds() / (t_peak - boundary).total_seconds()
                mc = BOUNDARY_MC * (pk / BOUNDARY_MC) ** frac
                step = 30
            else:
                frac = (t - t_peak).total_seconds() / (t_end - t_peak).total_seconds()
                mc = pk * final_frac ** frac
                step = 120
            mc *= rnd.uniform(0.995, 1.005)
            skip = (i == gap_token_i and scenario != "no_gap" and 0.8e6 <= mc <= 1.5e6 and t <= t_peak)
            if not skip:
                if role == "spike" and not spike_done and t > t_peak:
                    add_trade(mint, t, 1_200_000, "buy")
                    spike_done = True
                    t += pd.Timedelta(seconds=step)
                    continue
                add_trade(mint, t, mc)
            post_path.append((t, mc))
            t += pd.Timedelta(seconds=step)
        # snapshots cada 5 min durante toda la vida (bonding + post), MC real
        add_snaps(mint, created, path + post_path)

    trades_df = pd.DataFrame(trades)
    # ---- defectos de calidad plantados
    dups = trades_df.sample(50, random_state=seed)
    orphans = trades_df.sample(30, random_state=seed + 1).assign(mint=lambda d: "ORPHAN" + d["mint"].str[6:])
    trades_df = pd.concat([trades_df, dups, orphans], ignore_index=True)
    tokens_df = pd.DataFrame(tokens)
    dup_tok = tokens_df.iloc[[1500]].copy()
    dup_tok["created_at"] = dup_tok["created_at"] + pd.Timedelta(hours=1)
    tokens_df = pd.concat([tokens_df, dup_tok], ignore_index=True)

    os.makedirs(outdir, exist_ok=True)
    tokens_df.to_parquet(f"{outdir}/tokens.parquet", index=False)
    trades_df.to_parquet(f"{outdir}/trades.parquet", index=False)
    pd.DataFrame(snaps).to_parquet(f"{outdir}/snapshots.parquet", index=False)
    pd.DataFrame(migs).to_parquet(f"{outdir}/migrations.parquet", index=False)
    sol.to_parquet(f"{outdir}/sol_price.parquet", index=False)
    with open(f"{outdir}/truth.json", "w") as f:
        json.dump(truth, f)
    cfg = {
        "tables": {
            "tokens": {"path": f"{outdir}/tokens.parquet",
                       "columns": {"mint": "mint", "created_at": "created_at", "creator": "creator", "name": "name",
                                   "symbol": "symbol", "description": "description", "twitter": "twitter",
                                   "telegram": "telegram", "website": "website"}},
            "trades": {"path": f"{outdir}/trades.parquet",
                       "columns": {"mint": "mint", "ts": "block_time", "signature": "tx", "wallet": "trader",
                                   "side": "type", "sol_amount": "lamports", "token_amount": "amount"}},
            "snapshots": {"path": f"{outdir}/snapshots.parquet",
                          "columns": {"mint": "mint", "ts": "ts_ms", "mc_usd": "market_cap",
                                      "liquidity_usd": "liquidity", "holders": "holder_count"}},
            "migrations": {"path": f"{outdir}/migrations.parquet",
                           "columns": {"mint": "mint", "ts": "migrated_at", "pool": "pool"}},
            "sol_price": {"path": f"{outdir}/sol_price.parquet", "columns": {"ts": "ts", "price_usd": "price_usd"}},
        },
        "timestamp_units": {"trades": "s", "snapshots": "ms"},
        "amount_scales": {"sol_amount": 1e-9, "token_amount": 1e-6},
    }
    if scenario == "no_migrations":
        del cfg["tables"]["migrations"]
    if scenario == "no_sol":
        del cfg["tables"]["sol_price"]
    with open(f"{outdir}/config.json", "w") as f:
        json.dump(cfg, f, indent=2)
    return cfg


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="synthetic")
    ap.add_argument("--scenario", default="base", choices=["base", "no_post", "no_migrations", "no_sol", "no_gap"])
    a = ap.parse_args()
    make(a.out, a.scenario)
    print("ok", a.out)

# Montar el radar en GitHub (≈15 min, se puede hacer desde el móvil)

Resultado: el radar se ejecuta **solo, gratis, cada 30 min** en GitHub y publica `report/SCAN.md`.
Cuando escribas **SCAN** en el chat con Claude, lee ese informe y te da las monedas.
No hace falta tener el ordenador encendido.

## 1 · Crear el repositorio
1. Entra en https://github.com (crea cuenta si no tienes).
2. **New repository** → nombre: `moonshot-radar` → **Public** → *Create repository*.
   (Público para que Claude pueda leer el informe. Tu API key NO será pública: va en un secreto.)

## 2 · Subir los archivos
1. En el repo: **uploading an existing file** (o *Add file → Upload files*).
2. Selecciona TODOS los archivos de esta carpeta descomprimida
   (`moonshot.py`, `scan.py`, `token_forensics.py`, `pump_discovery.py`, `scam_filter.py`,
   `moonshot_demo.py`, `requirements.txt`, `moonshot_config.json`, `smart_wallets.csv`,
   `wallets_to_add.txt`) → **Commit changes**.

## 3 · Crear el programador (el archivo que lo ejecuta cada 30 min)
1. **Add file → Create new file**.
2. En el nombre escribe exactamente: `.github/workflows/moonshot.yml`
3. Pega dentro el contenido del archivo `.github/workflows/moonshot.yml` de esta carpeta → **Commit changes**.

## 4 · Guardar tu API key (secreta)
1. **Settings → Secrets and variables → Actions → New repository secret**.
2. Name: `SOLANA_RPC` · Secret: tu URL de Helius (`https://mainnet.helius-rpc.com/?api-key=...`) → *Add secret*.

## 5 · Añadir tus top traders
1. Abre `wallets_to_add.txt` → icono del lápiz (editar).
2. Una línea por trader: `DIRECCIÓN,Nombre`   (ej. la de Solstice, sacada de su perfil de pump.fun)
3. **Commit changes** → esto lanza el radar: verifica cada wallet (≥ $1M de ganancia realizada, etc.),
   añade las que cumplen a `smart_wallets.csv` y deja el resultado en `report/wallet_checks.md`.
   Para añadir una que no cumple: `DIRECCIÓN,Nombre,force`.

## 6 · Primera ejecución
1. Pestaña **Actions** → si lo pide, *I understand my workflows, go ahead and enable them*.
2. **Moonshot Radar → Run workflow**. Tarda 1–5 min. Después se repite solo cada 30 min.
3. Resultado en `report/SCAN.md` (GitHub lo muestra bonito en el móvil).

## 7 · Dile a Claude tu repo
Escribe en el chat: `mi repo es TU_USUARIO/moonshot-radar`. Desde ese momento, **SCAN** = el último informe.

---
### Si algo falla
- **Actions en rojo "SOLANA_RPC"** → falta el secreto del paso 4 (el nombre debe ser exacto).
- **Error al hacer push (403)** → Settings → Actions → General → *Workflow permissions* → **Read and write** → Save.
- **"No hay compras"** → normal si tus traders no han comprado en 48 h; añade más traders.
- **Cambiar reglas** → edita `moonshot_config.json` (números) y haz commit.
- **Pausar** → Actions → Moonshot Radar → ⋯ → *Disable workflow*.

Reglas PROVISIONALES: el informe ordena qué mirar; no es una recomendación de compra.
